package com.nsdl.nppconnector.models.calculation;


public class ContributionDetailsDto {

	private Integer id;
	private String grade;
	private double contributionAmount;
	private double periodicRoi;
	private double rateOfInterest;
	private double annuityWithoutRopRate;
	private double flatRoi;
	private double annuityRopRate;
	private double longTermInflationRate;
	private double lumpSumPercentageRate;
	private double annuityPercentageRate;
	
	
	
	public double getAnnuityWithoutRopRate() {
		return annuityWithoutRopRate;
	}
	public void setAnnuityWithoutRopRate(double annuityWithoutRopRate) {
		this.annuityWithoutRopRate = annuityWithoutRopRate;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getGrade() {
		return grade;
	}
	public void setGrade(String grade) {
		this.grade = grade;
	}
	public double getContributionAmount() {
		return contributionAmount;
	}
	public void setContributionAmount(double contributionAmount) {
		this.contributionAmount = contributionAmount;
	}
	public double getPeriodicRoi() {
		return periodicRoi;
	}
	public void setPeriodicRoi(double periodicRoi) {
		this.periodicRoi = periodicRoi;
	}
	public double getRateOfInterest() {
		return rateOfInterest;
	}
	public void setRateOfInterest(double rateOfInterest) {
		this.rateOfInterest = rateOfInterest;
	}
	public double getFlatRoi() {
		return flatRoi;
	}
	public void setFlatRoi(double flatRoi) {
		this.flatRoi = flatRoi;
	}
	public double getAnnuityRopRate() {
		return annuityRopRate;
	}
	public void setAnnuityRopRate(double annuityRopRate) {
		this.annuityRopRate = annuityRopRate;
	}
	public double getLongTermInflationRate() {
		return longTermInflationRate;
	}
	public void setLongTermInflationRate(double longTermInflationRate) {
		this.longTermInflationRate = longTermInflationRate;
	}
	public double getLumpSumPercentageRate() {
		return lumpSumPercentageRate;
	}
	public void setLumpSumPercentageRate(double lumpSumPercentageRate) {
		this.lumpSumPercentageRate = lumpSumPercentageRate;
	}
	public double getAnnuityPercentageRate() {
		return annuityPercentageRate;
	}
	public void setAnnuityPercentageRate(double annuityPercentageRate) {
		this.annuityPercentageRate = annuityPercentageRate;
	}
	
	
}
