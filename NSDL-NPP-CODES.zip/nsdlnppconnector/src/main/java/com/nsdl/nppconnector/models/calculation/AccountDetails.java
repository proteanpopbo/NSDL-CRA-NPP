package com.nsdl.nppconnector.models.calculation;

public class AccountDetails {

    private Integer noOfyear;
    private String Year;
    private Integer openingBalance;
    private Integer contribution;
    private Integer closingBalance;

    public AccountDetails() {
    }

    public AccountDetails(Integer noOfyear, String year, Integer openingBalance, Integer contribution, Integer closingBalance) {
        this.noOfyear = noOfyear;
        Year = year;
        this.openingBalance = openingBalance;
        this.contribution = contribution;
        this.closingBalance = closingBalance;
    }

    public Integer getNoOfyear() {
        return noOfyear;
    }

    public void setNoOfyear(Integer noOfyear) {
        this.noOfyear = noOfyear;
    }

    public String getYear() {
        return Year;
    }

    public void setYear(String year) {
        Year = year;
    }

    public Integer getOpeningBalance() {
        return openingBalance;
    }

    public void setOpeningBalance(Integer openingBalance) {
        this.openingBalance = openingBalance;
    }

    public Integer getContribution() {
        return contribution;
    }

    public void setContribution(Integer contribution) {
        this.contribution = contribution;
    }

    public Integer getClosingBalance() {
        return closingBalance;
    }

    public void setClosingBalance(Integer closingBalance) {
        this.closingBalance = closingBalance;
    }
}
