package com.nsdl.nppconnector.models.calculation;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(value = JsonInclude.Include.NON_NULL)
public class MonthlyEmiRequest {

	private Double rateOfInterest;
	private Double periodicDeposit;
	private Double numberOfYearsContributingSince;
	private Double presentValue;
	private Double tenure;
	private Double pmt;
	private Double periodicRoi;
	private Double flatRoi;
	private Double lumpSumPercentageRate;
	private Double annuityPercentageRate;
	private Double annuityWithOutROPRate;
	private Double annuityWithROPRate;

	private String empolyeeDod;
	private String empolyeeDor;

	public String getEmpolyeeDod() {
		return empolyeeDod;
	}

	public void setEmpolyeeDod(String empolyeeDod) {
		this.empolyeeDod = empolyeeDod;
	}

	public String getEmpolyeeDor() {
		return empolyeeDor;
	}

	public void setEmpolyeeDor(String empolyeeDor) {
		this.empolyeeDor = empolyeeDor;
	}

	public Double getPmt() {
		return pmt;
	}

	public void setPmt(Double pmt) {
		this.pmt = pmt;
	}

	public Double getRateOfInterest() {
		return rateOfInterest;
	}

	public void setRateOfInterest(Double rateOfInterest) {
		this.rateOfInterest = rateOfInterest;
	}

	public Double getPeriodicDeposit() {
		return periodicDeposit;
	}

	public void setPeriodicDeposit(Double periodicDeposit) {
		this.periodicDeposit = periodicDeposit;
	}

	public Double getNumberOfYearsContributingSince() {
		return numberOfYearsContributingSince;
	}

	public void setNumberOfYearsContributingSince(Double numberOfYearsContributingSince) {
		this.numberOfYearsContributingSince = numberOfYearsContributingSince;
	}

	public Double getPresentValue() {
		return presentValue;
	}

	public void setPresentValue(Double presentValue) {
		this.presentValue = presentValue;
	}

	public Double getTenure() {
		return tenure;
	}

	public void setTenure(Double tenure) {
		this.tenure = tenure;
	}

	public Double getPeriodicRoi() {
		return periodicRoi;
	}

	public void setPeriodicRoi(Double periodicRoi) {
		this.periodicRoi = periodicRoi;
	}

	public Double getFlatRoi() {
		return flatRoi;
	}

	public void setFlatRoi(Double flatRoi) {
		this.flatRoi = flatRoi;
	}

	public Double getLumpSumPercentageRate() {
		return lumpSumPercentageRate;
	}

	public void setLumpSumPercentageRate(Double lumpSumPercentageRate) {
		this.lumpSumPercentageRate = lumpSumPercentageRate;
	}

	public Double getAnnuityPercentageRate() {
		return annuityPercentageRate;
	}

	public void setAnnuityPercentageRate(Double annuityPercentageRate) {
		this.annuityPercentageRate = annuityPercentageRate;
	}

	public Double getAnnuityWithOutROPRate() {
		return annuityWithOutROPRate;
	}

	public void setAnnuityWithOutROPRate(Double annuityWithOutROPRate) {
		this.annuityWithOutROPRate = annuityWithOutROPRate;
	}

	public Double getAnnuityWithROPRate() {
		return annuityWithROPRate;
	}

	public void setAnnuityWithROPRate(Double annuityWithROPRate) {
		this.annuityWithROPRate = annuityWithROPRate;
	}

}
