package com.nsdl.nppconnector.models.calculation;

public class AnnualContributionRequestV2 {

	private Integer empId;
	private String empGrade;
	private Double periodicDeposit;
	private String empolyeeDob;
	private String empolyeeDor;
	private String empolyeeDoj;
	private double monthlyPension;
	private double annuityPersent;
	
	private double periodicRoi;
	
	

	public double getPeriodicRoi() {
		return periodicRoi;
	}

	public void setPeriodicRoi(double periodicRoi) {
		this.periodicRoi = periodicRoi;
	}

	public Double getPeriodicDeposit() {
		return periodicDeposit;
	}

	public void setPeriodicDeposit(Double periodicDeposit) {
		this.periodicDeposit = periodicDeposit;
	}

	public Integer getEmpId() {
		return empId;
	}

	public void setEmpId(Integer empId) {
		this.empId = empId;
	}

	public String getEmpGrade() {
		return empGrade;
	}

	public void setEmpGrade(String empGrade) {
		this.empGrade = empGrade;
	}

	public String getEmpolyeeDob() {
		return empolyeeDob;
	}

	public void setEmpolyeeDob(String empolyeeDob) {
		this.empolyeeDob = empolyeeDob;
	}

	public String getEmpolyeeDor() {
		return empolyeeDor;
	}

	public void setEmpolyeeDor(String empolyeeDor) {
		this.empolyeeDor = empolyeeDor;
	}

	public String getEmpolyeeDoj() {
		return empolyeeDoj;
	}

	public void setEmpolyeeDoj(String empolyeeDoj) {
		this.empolyeeDoj = empolyeeDoj;
	}

	public double getMonthlyPension() {
		return monthlyPension;
	}

	public void setMonthlyPension(double monthlyPension) {
		this.monthlyPension = monthlyPension;
	}

	public double getAnnuityPersent() {
		return annuityPersent;
	}

	public void setAnnuityPersent(double annuityPersent) {
		this.annuityPersent = annuityPersent;
	}

}
