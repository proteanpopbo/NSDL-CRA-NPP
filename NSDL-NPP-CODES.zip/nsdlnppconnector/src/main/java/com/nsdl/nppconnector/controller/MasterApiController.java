package com.nsdl.nppconnector.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.nsdl.nppconnector.models.calculation.ContributionDetailsDto;
import com.nsdl.nppconnector.models.calculation.CurrentNpsCorpusDto;

@RestController
@CrossOrigin(origins = { "${app.settings.origins}" })
@RequestMapping("/api/masters/")
public class MasterApiController {

	@Autowired
	private RestTemplate template;

	@Value("${npp.base.url}")
	private String baseUrl;

	@Value("${npp.getAnnuityRate.url}")
	private String getAnnuityRate;

	@GetMapping("/getEmployeeContributionMst/{employeeId}/{grade}")
	public ResponseEntity<ContributionDetailsDto> getAnnuityRate(@PathVariable("employeeId") Integer employeeId,
			@PathVariable("grade") String grade) {

		String url = baseUrl.concat(String.format(getAnnuityRate, employeeId, grade));
		try {
			ContributionDetailsDto result = template.getForObject(url, ContributionDetailsDto.class);

			return ResponseEntity.ok(result);
		} catch (Exception e) {
			return ResponseEntity.ok(null);
		}
	}

}
