package com.nsdl.nppconnector.models.calculation;


public class MonthlyEmiResponse {

    private int currentNPSCorpus;
    private int npsCorpus;
    private int lumpSumCorpus;
    private int annuityCorpus;
    private int monthlyPensionWithRop;
    private int monthlyPensionWithOutRop;
    private int projectedContribution;

    public int getCurrentNPSCorpus() {
        return currentNPSCorpus;
    }

    public void setCurrentNPSCorpus(int currentNPSCorpus) {
        this.currentNPSCorpus = currentNPSCorpus;
    }

    public int getNpsCorpus() {
        return npsCorpus;
    }

    public void setNpsCorpus(int npsCorpus) {
        this.npsCorpus = npsCorpus;
    }

    public int getLumpSumCorpus() {
        return lumpSumCorpus;
    }

    public void setLumpSumCorpus(int lumpSumCorpus) {
        this.lumpSumCorpus = lumpSumCorpus;
    }

    public int getAnnuityCorpus() {
        return annuityCorpus;
    }

    public void setAnnuityCorpus(int annuityCorpus) {
        this.annuityCorpus = annuityCorpus;
    }

	public int getMonthlyPensionWithRop() {
		return monthlyPensionWithRop;
	}

	public void setMonthlyPensionWithRop(int monthlyPensionWithRop) {
		this.monthlyPensionWithRop = monthlyPensionWithRop;
	}

	public int getMonthlyPensionWithOutRop() {
		return monthlyPensionWithOutRop;
		
	}

	public void setMonthlyPensionWithOutRop(int monthlyPensionWithOutRop) {
		this.monthlyPensionWithOutRop = monthlyPensionWithOutRop;
	}

	public int getProjectedContribution() {
		return projectedContribution;
	}

	public void setProjectedContribution(int projectedContribution) {
		this.projectedContribution = projectedContribution;
	}

   
}
