package com.nsdl.nppconnector.models.calculation;

public class CurrentNpsCorpusRequest {

	private Integer employeeId;
	private String grade;
	private String startYear;
	private Integer avgYearlyContribution;

	public Integer getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(Integer employeeId) {
		this.employeeId = employeeId;
	}

	public String getGrade() {
		return grade;
	}

	public void setGrade(String grade) {
		this.grade = grade;
	}

	public String getStartYear() {
		return startYear;
	}

	public void setStartYear(String startYear) {
		this.startYear = startYear;
	}

	public Integer getAvgYearlyContribution() {
		return avgYearlyContribution;
	}

	public void setAvgYearlyContribution(Integer avgYearlyContribution) {
		this.avgYearlyContribution = avgYearlyContribution;
	}

}
