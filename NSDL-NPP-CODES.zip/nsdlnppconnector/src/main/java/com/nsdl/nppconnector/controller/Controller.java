package com.nsdl.nppconnector.controller;

import java.text.ParseException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.node.ObjectNode;
import com.nsdl.nppconnector.models.age.RetirmentYearRequest;
import com.nsdl.nppconnector.models.calculation.AnnualContributionRequest;
import com.nsdl.nppconnector.models.calculation.AnnualContributionRequestV2;
import com.nsdl.nppconnector.models.calculation.AnnualContributionResponse;
import com.nsdl.nppconnector.models.calculation.ContrbutionRequest;
import com.nsdl.nppconnector.models.calculation.CurrentNpsCorpusDto;
import com.nsdl.nppconnector.models.calculation.CurrentNpsCorpusRequest;
import com.nsdl.nppconnector.models.calculation.MonthlyEmiRequest;
import com.nsdl.nppconnector.models.calculation.MonthlyEmiResponse;
import com.nsdl.nppconnector.models.calculation.MonthlyPensionRequest;
import com.nsdl.nppconnector.models.calculation.MonthlyPensionRequiredRequest;
import com.nsdl.nppconnector.models.calculation.MonthlyPensionRequiredResponse;

@RestController
@CrossOrigin(origins = { "${app.settings.origins}" })
@RequestMapping("/api/calculator")
public class Controller {

	@Autowired
	private RestTemplate template;

	@Value("${npp.base.url}")
	private String baseUrl;

	@Value("${npp.getCurrentNpsCorpus.url}")
	private String getCurrentNpsCorpus;

	@Value("${npp.getCurrentNpsCorpusV2.url}")
	private String getCurrentNpsCorpusV2;

	@GetMapping("/testAPI")
	public ResponseEntity<?> testAPI() {

		return ResponseEntity.ok("Welcome");

	}

	@GetMapping("/getCurrentNpsCorpus/{employeeId}/{grade}/{startYear}")
	public ResponseEntity<CurrentNpsCorpusDto> getCurrentNpsCorpus(@PathVariable("employeeId") Integer employeeId,
			@PathVariable("grade") String grade, @PathVariable("startYear") String startYear) {

		String url = baseUrl.concat(String.format(getCurrentNpsCorpus, employeeId, grade, startYear));
		
		System.out.println(url);
		try {
			CurrentNpsCorpusDto result = template.getForObject(url, CurrentNpsCorpusDto.class);

			return ResponseEntity.ok(result);
		} catch (Exception e) {
			System.out.println(e.getMessage());
			return ResponseEntity.ok(null);
		}

	}

	@GetMapping("/getCurrentNpsCorpusV2/{employeeType}/{grade}/{startYear}")
	public ResponseEntity<?> getCurrentNpsCorpusNew(@PathVariable("employeeType") String employeeType,
			@PathVariable("grade") String grade, @PathVariable("startYear") String startYear) {

		String url = baseUrl.concat(String.format(getCurrentNpsCorpusV2, employeeType, grade, startYear));

		try {
			CurrentNpsCorpusDto result = template.getForObject(url, CurrentNpsCorpusDto.class);

			return ResponseEntity.ok(result);
		} catch (Exception e) {
			return ResponseEntity.ok(null);
		}
	}

	@PostMapping("/getCurrentNpsCorpusV3")
	public ResponseEntity<CurrentNpsCorpusDto> getCurrentNpsCorpusV3(
			@RequestBody CurrentNpsCorpusRequest currentNpsCorpusRequest) {

		ParameterizedTypeReference<CurrentNpsCorpusDto> type = new ParameterizedTypeReference<CurrentNpsCorpusDto>() {
		};

		String url = baseUrl.concat("/api/calculator/getCurrentNpsCorpusV3");

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);

		HttpEntity<CurrentNpsCorpusRequest> entity = new HttpEntity<>(currentNpsCorpusRequest, headers);

		try {
			ResponseEntity<CurrentNpsCorpusDto> res = template.exchange(url, HttpMethod.POST, entity, type);
			return ResponseEntity.ok(res.getBody());
		} catch (Exception e) {
			return ResponseEntity.ok(null);
		}

	}

	@PostMapping("/getMonthlyEmi")
	public ResponseEntity<?> getMonthlyEmi(@RequestBody MonthlyEmiRequest monthlyEmiRequest) {

		ParameterizedTypeReference<MonthlyEmiResponse> type = new ParameterizedTypeReference<MonthlyEmiResponse>() {
		};

		String url = baseUrl.concat("/api/calculator/getCurrentNpsCorpusV3");

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);

		HttpEntity<MonthlyEmiRequest> entity = new HttpEntity<>(monthlyEmiRequest, headers);

		try {
			ResponseEntity<MonthlyEmiResponse> res = template.exchange(url, HttpMethod.POST, entity, type);
			return ResponseEntity.ok(res.getBody());
		} catch (Exception e) {
			return ResponseEntity.ok(null);
		}

	}

	@PostMapping("/getMonthlyPension")
	public ResponseEntity<?> getMonthlyPension(@RequestBody MonthlyPensionRequest monthlyPensionRequest) {

		ParameterizedTypeReference<MonthlyEmiResponse> type = new ParameterizedTypeReference<MonthlyEmiResponse>() {
		};

		String url = baseUrl.concat("/api/calculator/getMonthlyPension");

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);

		HttpEntity<MonthlyPensionRequest> entity = new HttpEntity<>(monthlyPensionRequest, headers);

		try {
			ResponseEntity<MonthlyEmiResponse> res = template.exchange(url, HttpMethod.POST, entity, type);
			return ResponseEntity.ok(res.getBody());
		} catch (Exception e) {
			return ResponseEntity.ok(null);
		}

	}

	@PostMapping("/getAnnualContribution")
	public ResponseEntity<?> getAnnualContribution(@RequestBody AnnualContributionRequest annualContributionRequest) {

		ParameterizedTypeReference<AnnualContributionResponse> type = new ParameterizedTypeReference<AnnualContributionResponse>() {
		};

		String url = baseUrl.concat("/api/calculator/getAnnualContribution");

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);

		HttpEntity<AnnualContributionRequest> entity = new HttpEntity<>(annualContributionRequest, headers);

		try {
			ResponseEntity<AnnualContributionResponse> res = template.exchange(url, HttpMethod.POST, entity, type);
			return ResponseEntity.ok(res.getBody());
		} catch (Exception e) {
			return ResponseEntity.ok(null);
		}

	}

	@PostMapping("/getAnnualContributionV2")
	public ResponseEntity<?> getAnnualContributionV2(
			@RequestBody AnnualContributionRequestV2 annualContributionRequestV2) {

		ParameterizedTypeReference<AnnualContributionResponse> type = new ParameterizedTypeReference<AnnualContributionResponse>() {
		};

		String url = baseUrl.concat("/api/calculator/getAnnualContributionV2");

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);

		HttpEntity<AnnualContributionRequestV2> entity = new HttpEntity<>(annualContributionRequestV2, headers);

		try {
			ResponseEntity<AnnualContributionResponse> res = template.exchange(url, HttpMethod.POST, entity, type);
			return ResponseEntity.ok(res.getBody());
		} catch (Exception e) {
			return ResponseEntity.ok(null);
		}

	}

	@PostMapping("/getRetirementYear")
	public ResponseEntity<ObjectNode> getRetirementYear(@RequestBody RetirmentYearRequest retirmentYearRequest) {

		ParameterizedTypeReference<ObjectNode> type = new ParameterizedTypeReference<ObjectNode>() {
		};

		String url = baseUrl.concat("/api/calculator/getRetirementYear");

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);

		HttpEntity<RetirmentYearRequest> entity = new HttpEntity<>(retirmentYearRequest, headers);

		try {
			ResponseEntity<ObjectNode> res = template.exchange(url, HttpMethod.POST, entity, type);
			return ResponseEntity.ok(res.getBody());
		} catch (Exception e) {
			return ResponseEntity.ok(null);
		}

	}

	@PostMapping("/getMonthlyPensionRequired")
	public ResponseEntity<?> getMonthlyPensionRequired(
			@RequestBody MonthlyPensionRequiredRequest monthlyPensionRequiredRequest) {

		ParameterizedTypeReference<MonthlyPensionRequiredResponse> type = new ParameterizedTypeReference<MonthlyPensionRequiredResponse>() {
		};

		String url = baseUrl.concat("/api/calculator/getMonthlyPensionRequired");

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);

		HttpEntity<MonthlyPensionRequiredRequest> entity = new HttpEntity<>(monthlyPensionRequiredRequest, headers);

		try {
			ResponseEntity<MonthlyPensionRequiredResponse> res = template.exchange(url, HttpMethod.POST, entity, type);
			return ResponseEntity.ok(res.getBody());
		} catch (Exception e) {
			return ResponseEntity.ok(null);
		}

	}

	@PostMapping("/getContrbution")
	public ResponseEntity<?> getContrbution(@RequestBody ContrbutionRequest contrbutionRequest) {

		ParameterizedTypeReference<Double> type = new ParameterizedTypeReference<Double>() {
		};

		String url = baseUrl.concat("/api/calculator/getContrbution");

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);

		HttpEntity<ContrbutionRequest> entity = new HttpEntity<>(contrbutionRequest, headers);

		try {
			ResponseEntity<Double> res = template.exchange(url, HttpMethod.POST, entity, type);
			return ResponseEntity.ok((int) Math.round(res.getBody()));
		} catch (Exception e) {
			return ResponseEntity.ok(null);
		}
	}
}
