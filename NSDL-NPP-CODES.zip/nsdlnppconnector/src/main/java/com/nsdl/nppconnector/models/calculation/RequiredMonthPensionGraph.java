package com.nsdl.nppconnector.models.calculation;

public class RequiredMonthPensionGraph {

	private int year;
	private int amount;

	public RequiredMonthPensionGraph() {
	}

	public RequiredMonthPensionGraph(int year, int amount) {
		super();
		this.year = year;
		this.amount = amount;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

}
