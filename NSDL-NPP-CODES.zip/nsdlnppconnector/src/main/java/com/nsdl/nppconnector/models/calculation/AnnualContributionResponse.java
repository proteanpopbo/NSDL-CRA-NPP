package com.nsdl.nppconnector.models.calculation;

public class AnnualContributionResponse {

	private int currentNpsCorpus;
	private int annuityCorpus;
	private int lumpsumCorpus;
	private int newAnnualContribution;

	// private double currentPension;
	private int newPension;

	private int pensionWithRop;
	private int pensionWithOutRop;

	private int oldPensionWithRop;
	private int oldPensionWithOutRop;

	public int getCurrentNpsCorpus() {
		return currentNpsCorpus;
	}

	public void setCurrentNpsCorpus(int currentNpsCorpus) {
		this.currentNpsCorpus = currentNpsCorpus;
	}

	public int getAnnuityCorpus() {
		return annuityCorpus;
	}

	public void setAnnuityCorpus(int annuityCorpus) {
		this.annuityCorpus = annuityCorpus;
	}

	public int getLumpsumCorpus() {
		return lumpsumCorpus;
	}

	public void setLumpsumCorpus(int lumpsumCorpus) {
		this.lumpsumCorpus = lumpsumCorpus;
	}

	public int getNewAnnualContribution() {
		return newAnnualContribution;
	}

	public void setNewAnnualContribution(int newAnnualContribution) {
		this.newAnnualContribution = newAnnualContribution;
	}

	public int getNewPension() {
		return newPension;
	}

	public void setNewPension(int newPension) {
		this.newPension = newPension;
	}

	public int getPensionWithRop() {
		return pensionWithRop;
	}

	public void setPensionWithRop(int pensionWithRop) {
		this.pensionWithRop = pensionWithRop;
	}

	public int getPensionWithOutRop() {
		return pensionWithOutRop;
	}

	public void setPensionWithOutRop(int pensionWithOutRop) {
		this.pensionWithOutRop = pensionWithOutRop;
	}

	public int getOldPensionWithRop() {
		return oldPensionWithRop;
	}

	public void setOldPensionWithRop(int oldPensionWithRop) {
		this.oldPensionWithRop = oldPensionWithRop;
	}

	public int getOldPensionWithOutRop() {
		return oldPensionWithOutRop;
	}

	public void setOldPensionWithOutRop(int oldPensionWithOutRop) {
		this.oldPensionWithOutRop = oldPensionWithOutRop;
	}

}
