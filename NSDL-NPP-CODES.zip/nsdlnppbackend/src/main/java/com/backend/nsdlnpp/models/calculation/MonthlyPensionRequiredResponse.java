package com.backend.nsdlnpp.models.calculation;

import java.util.ArrayList;
import java.util.List;

public class MonthlyPensionRequiredResponse {

	private double pensionRequired;
	private List<List<?>> monthlyPensionList = new ArrayList<>();

	public double getPensionRequired() {
		return pensionRequired;
	}

	public void setPensionRequired(double pensionRequired) {
		this.pensionRequired = pensionRequired;
	}

	public List<List<?>> getMonthlyPensionList() {
		return monthlyPensionList;
	}

	public void setMonthlyPensionList(List<List<?>> monthlyPensionList) {
		this.monthlyPensionList = monthlyPensionList;
	}

	


}
