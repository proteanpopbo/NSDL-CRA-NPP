package com.backend.nsdlnpp.models.calculation;

public class ContributionResponse {
	
	private int totalContribution;
	private int avgYearleContribution;
	
	public int getTotalContribution() {
		return totalContribution;
	}
	public void setTotalContribution(int totalContribution) {
		this.totalContribution = totalContribution;
	}
	public int getAvgYearleContribution() {
		return avgYearleContribution;
	}
	public void setAvgYearleContribution(int avgYearleContribution) {
		this.avgYearleContribution = avgYearleContribution;
	}
	
	

}
