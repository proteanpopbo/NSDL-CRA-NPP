package com.backend.nsdlnpp.service.calculator;

import java.text.ParseException;

import com.backend.nsdlnpp.models.calculation.AnnualContributionRequest;
import com.backend.nsdlnpp.models.calculation.AnnualContributionRequestV2;
import com.backend.nsdlnpp.models.calculation.AnnualContributionResponse;
import com.backend.nsdlnpp.models.calculation.ContrbutionRequest;
import com.backend.nsdlnpp.models.calculation.ContributionResponse;
import com.backend.nsdlnpp.models.calculation.CurrentNpsCorpusDto;
import com.backend.nsdlnpp.models.calculation.CurrentNpsCorpusRequest;
import com.backend.nsdlnpp.models.calculation.MonthlyEmiRequest;
import com.backend.nsdlnpp.models.calculation.MonthlyEmiResponse;
import com.backend.nsdlnpp.models.calculation.MonthlyPensionRequest;
import com.backend.nsdlnpp.models.calculation.MonthlyPensionRequiredRequest;
import com.backend.nsdlnpp.models.calculation.MonthlyPensionRequiredResponse;
import com.backend.nsdlnpp.models.calculation.UserContributionRequest;

public interface Calculator {

	public CurrentNpsCorpusDto getCurrentNpsCorpus(UserContributionRequest userContributionRequest, String startYear);

	public CurrentNpsCorpusDto getCurrentNpsCorpusNew(UserContributionRequest userContributionRequest,
			String startYear);

	public MonthlyEmiResponse monthlyEmi(MonthlyEmiRequest monthlyEmiRequest);

	public MonthlyEmiResponse getMonthlyPension(MonthlyPensionRequest monthlyPensionRequest) throws ParseException;

	public AnnualContributionResponse annualContributionCal(AnnualContributionRequest annualContributionRequest);

	public CurrentNpsCorpusDto getCurrentNpsCorpusV2(CurrentNpsCorpusRequest currentNpsCorpusRequest);

	public AnnualContributionResponse annualContributionCalV2(AnnualContributionRequestV2 annualContributionRequestV2)
			throws ParseException;

	public MonthlyPensionRequiredResponse monthlyPensionRequiredCal(MonthlyPensionRequiredRequest monthlyPensionRequiredRequest);

	public ContributionResponse contrbutionCal(ContrbutionRequest contrbutionRequest);
}
