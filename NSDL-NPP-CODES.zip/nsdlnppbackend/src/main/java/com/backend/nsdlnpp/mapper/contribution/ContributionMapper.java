package com.backend.nsdlnpp.mapper.contribution;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.backend.nsdlnpp.entity.masters.ContributionDetailsEntity;
import com.backend.nsdlnpp.models.calculation.ContributionDetailsDto;

@Mapper(componentModel = "spring")
public interface ContributionMapper {
	
	ContributionMapper INSTANCE = Mappers.getMapper(ContributionMapper.class);
	
	
	ContributionDetailsDto contributioModelToDto(ContributionDetailsEntity contributionDetailsEntity);

}
