package com.backend.nsdlnpp.models.calculation;



public class EmployeeTypeDto {
	
	private Integer id;
	private String employeeType;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getEmployeeType() {
		return employeeType;
	}
	public void setEmployeeType(String employeeType) {
		this.employeeType = employeeType;
	}
	
	

}
