package com.backend.nsdlnpp.service.userservice;

import com.backend.nsdlnpp.adapter.UserAdapter;
import com.backend.nsdlnpp.entity.user.Users;
import com.backend.nsdlnpp.repo.user.UserRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class MyUserDetailsService implements UserDetailsService {

    @Autowired
    private UserRepo userRepo;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        Optional<Users> opUser = userRepo.findByUserName(username);

        if (opUser.isEmpty())
            throw new UsernameNotFoundException(username);

        return new UserAdapter(opUser.get());
    }
}
