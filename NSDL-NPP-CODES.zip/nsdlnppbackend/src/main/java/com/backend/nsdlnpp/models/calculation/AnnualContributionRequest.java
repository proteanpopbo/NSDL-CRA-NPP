package com.backend.nsdlnpp.models.calculation;

public class AnnualContributionRequest {

    private double tenure;
    private double targetValue;
    private double startIterationFrom;
    private double startDepositIterationFrom;
    private double rateOfInterest;
    private double flatRoi;
    private double periodicDeposit;
    private double numberOfYearsContributingSince;
    private double periodicRoi;

    public double getRateOfInterest() {
        return rateOfInterest;
    }

    public void setRateOfInterest(double rateOfInterest) {
        this.rateOfInterest = rateOfInterest;
    }

    public double getPeriodicDeposit() {
        return periodicDeposit;
    }

    public void setPeriodicDeposit(double periodicDeposit) {
        this.periodicDeposit = periodicDeposit;
    }

    public double getNumberOfYearsContributingSince() {
        return numberOfYearsContributingSince;
    }

    public void setNumberOfYearsContributingSince(double numberOfYearsContributingSince) {
        this.numberOfYearsContributingSince = numberOfYearsContributingSince;
    }

    public double getTenure() {
        return tenure;
    }

    public void setTenure(double tenure) {
        this.tenure = tenure;
    }

    public double getPeriodicRoi() {
        return periodicRoi;
    }

    public void setPeriodicRoi(double periodicRoi) {
        this.periodicRoi = periodicRoi;
    }

    public double getFlatRoi() {
        return flatRoi;
    }

    public void setFlatRoi(double flatRoi) {
        this.flatRoi = flatRoi;
    }

    public double getStartIterationFrom() {
        return startIterationFrom;
    }

    public void setStartIterationFrom(double startIterationFrom) {
        this.startIterationFrom = startIterationFrom;
    }

    public double getStartDepositIterationFrom() {
        return startDepositIterationFrom;
    }

    public void setStartDepositIterationFrom(double startDepositIterationFrom) {
        this.startDepositIterationFrom = startDepositIterationFrom;
    }

    public double getTargetValue() {
        return targetValue;
    }

    public void setTargetValue(double targetValue) {
        this.targetValue = targetValue;
    }
}
