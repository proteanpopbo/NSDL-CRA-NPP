package com.backend.nsdlnpp.repo.lan;

import org.springframework.data.jpa.repository.JpaRepository;

import com.backend.nsdlnpp.entity.lan.LanguageEntity;

public interface LanguageRepo extends JpaRepository<LanguageEntity, Integer> {

}
