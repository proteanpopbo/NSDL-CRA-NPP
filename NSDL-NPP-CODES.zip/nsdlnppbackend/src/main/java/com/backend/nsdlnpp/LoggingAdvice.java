package com.backend.nsdlnpp;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.servlet.http.HttpServletRequest;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

@Aspect
@Component
public class LoggingAdvice {

//	@Autowired
//	private UserServiceFeign userServiceFeign;

	@Pointcut(value = "execution(* com.backend.nsdlnpp.controller.*.*(..))")
	public void controllerPointcut() {
	}

	@Pointcut(value = "execution(* com.backend.nsdlnpp.service.*.*.*(..))")
	public void servicePointcut() {
	}

	@Pointcut(value = "execution(* com.backend.nsdlnpp.repo.*.*.*(..))")
	public void repositoryPointcut() {
	}

	@Around("controllerPointcut() || servicePointcut() || repositoryPointcut()")
	public Object applicationLogger(ProceedingJoinPoint pjp) throws Throwable {
		final Logger log = LoggerFactory.getLogger(pjp.getTarget().getClass());
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false);
		String methodName = pjp.getSignature().getName();

		Object[] args = pjp.getArgs();
		if (args.length > 0) {

			for (int i = 0; i < args.length; i++) {

				if (null != args[i]
						&& args[i].getClass().getPackageName().equals("org.springframework.security.web.servletapi")) {
					HttpServletRequest request = (HttpServletRequest) args[i];
					String methodArgs = Stream.of(args).collect(Collectors.toList()).toString();
					log.info("[Server IP : " + request.getRemoteHost()+" Client IP :" + request.getRemoteAddr() + " Remote User :" + request.getRemoteUser()+ " Session ID: " + request.getSession().getId()+"]" 
							+"\t Enter: >>> Method: " + methodName + "() with arguments : " + methodArgs);
				}else {
					String methodArgs = Stream.of(args).collect(Collectors.toList()).toString();
					log.info("Enter: >>> Method: " + methodName + "() with arguments : " + methodArgs);
				}
			}
		}

		Object object = pjp.proceed();
		log.info("Exit: <<< Method: " + methodName + "()");
		return object;
	}
}
