package com.backend.nsdlnpp.models.calculation;

public class CurrentNpsCorpusDto {

	private double averageAnnualContribution;
	private int currentNPSCorpus;
	
	public double getAverageAnnualContribution() {
		return averageAnnualContribution;
	}
	public void setAverageAnnualContribution(double averageAnnualContribution) {
		this.averageAnnualContribution = averageAnnualContribution;
	}
	public int getCurrentNPSCorpus() {
		return currentNPSCorpus;
	}
	public void setCurrentNPSCorpus(int currentNPSCorpus) {
		this.currentNPSCorpus = currentNPSCorpus;
	}
	
	
}
