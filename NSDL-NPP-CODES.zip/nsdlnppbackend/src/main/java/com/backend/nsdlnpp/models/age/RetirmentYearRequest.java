package com.backend.nsdlnpp.models.age;

public class RetirmentYearRequest {
	private String dob;
	private String retirementDate;
	
	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getRetirementDate() {
		return retirementDate;
	}

	public void setRetirementDate(String retirementDate) {
		this.retirementDate = retirementDate;
	}

}
