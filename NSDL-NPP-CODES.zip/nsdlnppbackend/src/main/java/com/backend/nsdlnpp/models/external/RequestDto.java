package com.backend.nsdlnpp.models.external;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

public class RequestDto {
	private String user_name;
	
	private String user_sector;
	
	@JsonFormat(pattern = "dd-MM-yyyy")
	private Date doj_nps;
	
	@JsonFormat(pattern = "dd-MM-yyyy")
	private Date date_of_birth;
	
	@JsonFormat(pattern = "dd-MM-yyyy")
	private Date date_of_retirement;
	
	private Double current_nps_balance;
	
	private Double total_contribution;

	public String getUser_name() {
		return user_name;
	}

	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}

	public String getUser_sector() {
		return user_sector;
	}

	public void setUser_sector(String user_sector) {
		this.user_sector = user_sector;
	}

	public Date getDoj_nps() {
		return doj_nps;
	}

	public void setDoj_nps(Date doj_nps) {
		this.doj_nps = doj_nps;
	}

	public Date getDate_of_birth() {
		return date_of_birth;
	}

	public void setDate_of_birth(Date date_of_birth) {
		this.date_of_birth = date_of_birth;
	}

	public Date getDate_of_retirement() {
		return date_of_retirement;
	}

	public void setDate_of_retirement(Date date_of_retirement) {
		this.date_of_retirement = date_of_retirement;
	}

	public Double getCurrent_nps_balance() {
		return current_nps_balance;
	}

	public void setCurrent_nps_balance(Double current_nps_balance) {
		this.current_nps_balance = current_nps_balance;
	}

	public Double getTotal_contribution() {
		return total_contribution;
	}

	public void setTotal_contribution(Double total_contribution) {
		this.total_contribution = total_contribution;
	}

}
