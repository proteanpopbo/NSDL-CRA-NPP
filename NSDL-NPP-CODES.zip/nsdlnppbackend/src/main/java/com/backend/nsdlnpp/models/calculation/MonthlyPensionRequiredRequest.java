package com.backend.nsdlnpp.models.calculation;

public class MonthlyPensionRequiredRequest {

	private int currentYear;
	private int retirementDate;
	private double inflationRate;
	private double expenses;
	private double retirement;

	

	public int getCurrentYear() {
		return currentYear;
	}

	public void setCurrentYear(int currentYear) {
		this.currentYear = currentYear;
	}

	public int getRetirementDate() {
		return retirementDate;
	}

	public void setRetirementDate(int retirementDate) {
		this.retirementDate = retirementDate;
	}

	public double getInflationRate() {
		return inflationRate;
	}

	public void setInflationRate(double inflationRate) {
		this.inflationRate = inflationRate;
	}

	public double getExpenses() {
		return expenses;
	}

	public void setExpenses(double expenses) {
		this.expenses = expenses;
	}

	public double getRetirement() {
		return retirement;
	}

	public void setRetirement(double retirement) {
		this.retirement = retirement;
	}

}
