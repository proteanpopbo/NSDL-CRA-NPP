package com.backend.nsdlnpp.controller;

import com.backend.nsdlnpp.models.calculation.ContributionDetailsDto;
import com.backend.nsdlnpp.models.calculation.EmployeeTypeDto;
import com.backend.nsdlnpp.models.calculation.UserContributionRequest;
import com.backend.nsdlnpp.service.lan.LanguageService;
import com.backend.nsdlnpp.service.mastersservice.MasterService;
import com.backend.nsdlnpp.translator.Translator;
import com.fasterxml.jackson.databind.node.ObjectNode;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/masters/")
public class MasterApiController {

	@Autowired
	private MasterService masterService;

	@Autowired
	private Translator translator;

	@Autowired
	private LanguageService languageService;

	@GetMapping("/startProject")
	public ResponseEntity<String> startProject() {
		return ResponseEntity.ok(translator.translate("good.morning.message"));
	}

	@GetMapping("/getEmployeeContributionMst/{employeeId}/{grade}")
	public ResponseEntity<?> getAnnuityRate(@PathVariable("employeeId") Integer employeeId,
			@PathVariable("grade") String grade) {

		UserContributionRequest userContributionRequest = new UserContributionRequest();
		userContributionRequest.setEmpGrade(grade);
		userContributionRequest.setEmployeeTypeId(employeeId);

		ContributionDetailsDto contributionDetailsDto = masterService.getUserContribution(userContributionRequest);
		if (contributionDetailsDto != null)
			return ResponseEntity.ok(contributionDetailsDto);

		return ResponseEntity.ok("Employee does not exist");
	}

	@GetMapping("/getEmployeeGradeMst/{employeeId}")
	public ResponseEntity<?> getEmployeeGradeMst(@PathVariable("employeeId") Integer employeeId) {

		List<String> empGradeList = masterService.getUserGrade(employeeId);

		if (!empGradeList.isEmpty())
			return ResponseEntity.ok(empGradeList);

		return ResponseEntity.ok("Employee does not exist");
	}

	@GetMapping("/getEmployeeTypeMst")
	public ResponseEntity<?> getEmployeeGradeMst() {

		List<EmployeeTypeDto> empTypeList = masterService.getEmpType();

		if (!empTypeList.isEmpty())
			return ResponseEntity.ok(empTypeList);

		return ResponseEntity.ok("Employee does not exist");
	}

	@GetMapping("/getHindiLanguage")
	public ResponseEntity<?> getHindiLanguage() {

		ObjectNode hindi = null;
		try {
			hindi = languageService.hindiLan();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

		return ResponseEntity.ok(hindi);
	}

	@GetMapping("/getEnglishLanguage")
	public ResponseEntity<?> getEnglishLanguage() {

		ObjectNode english = null;
		try {
			english = languageService.englisgLan();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

		return ResponseEntity.ok(english);
	}

}
