package com.backend.nsdlnpp.entity.masters;


import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name = "mst_contribution")
public class ContributionDetailsEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	@Column(name = "grade")
	private String grade;
	
	@Column(name = "contribution_amount", precision = 18, scale = 2)
	private BigDecimal contributionAmount;
	
	@Column(name = "periodic_roi", precision = 18, scale = 2)
	private BigDecimal periodicRoi;
	
	@Column(name = "rate_of_interest", precision = 18, scale = 2)
	private BigDecimal rateOfInterest;
	
	@Column(name = "flat_roi", precision = 18, scale = 2)
	private BigDecimal flatRoi;
	
	@Column(name = "annuity_rop_rate", precision = 18, scale = 2)
	private BigDecimal annuityRopRate;
	
	@Column(name = "annuity_without_rop_rate", precision = 18, scale = 2)
	private BigDecimal annuityWithoutRopRate;
	
	@Column(name = "long_term_nflation_rate", precision = 18, scale = 2)
	private BigDecimal longTermInflationRate;
	
	@Column(name = "lump_sum_percentage_rate", precision = 18, scale = 2)
	private BigDecimal lumpSumPercentageRate;
	
	@Column(name = "annuity_percentage_rate", precision = 18, scale = 2)
	private BigDecimal annuityPercentageRate;
	
	@ManyToOne
	@JoinColumn(name = "employee_type_id", nullable = false, referencedColumnName = "id")
	private EmployeeTypeEntity employeeTypeEntity;

	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "Asia/Kolkata")
	@Basic
	@Temporal(TemporalType.TIMESTAMP)
	@CreationTimestamp
	@Column(name = "created_date")
	private Date createdDate;

	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "Asia/Kolkata")
	@Basic
	@Temporal(TemporalType.TIMESTAMP)
	@UpdateTimestamp
	@Column(name = "last_modified_date")
	private Date lastModifiedDate;
	
	

	public BigDecimal getAnnuityWithoutRopRate() {
		return annuityWithoutRopRate;
	}

	public void setAnnuityWithoutRopRate(BigDecimal annuityWithoutRopRate) {
		this.annuityWithoutRopRate = annuityWithoutRopRate;
	}

	public BigDecimal getLumpSumPercentageRate() {
		return lumpSumPercentageRate;
	}

	public void setLumpSumPercentageRate(BigDecimal lumpSumPercentageRate) {
		this.lumpSumPercentageRate = lumpSumPercentageRate;
	}

	public BigDecimal getAnnuityPercentageRate() {
		return annuityPercentageRate;
	}

	public void setAnnuityPercentageRate(BigDecimal annuityPercentageRate) {
		this.annuityPercentageRate = annuityPercentageRate;
	}

	public BigDecimal getAnnuityRopRate() {
		return annuityRopRate;
	}

	public void setAnnuityRopRate(BigDecimal annuityRopRate) {
		this.annuityRopRate = annuityRopRate;
	}

	public BigDecimal getLongTermInflationRate() {
		return longTermInflationRate;
	}

	public void setLongTermInflationRate(BigDecimal longTermInflationRate) {
		this.longTermInflationRate = longTermInflationRate;
	}

	public BigDecimal getContributionAmount() {
		return contributionAmount;
	}

	public void setContributionAmount(BigDecimal contributionAmount) {
		this.contributionAmount = contributionAmount;
	}

	public BigDecimal getPeriodicRoi() {
		return periodicRoi;
	}

	public void setPeriodicRoi(BigDecimal periodicRoi) {
		this.periodicRoi = periodicRoi;
	}

	public BigDecimal getRateOfInterest() {
		return rateOfInterest;
	}

	public void setRateOfInterest(BigDecimal rateOfInterest) {
		this.rateOfInterest = rateOfInterest;
	}

	public BigDecimal getFlatRoi() {
		return flatRoi;
	}

	public void setFlatRoi(BigDecimal flatRoi) {
		this.flatRoi = flatRoi;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(Date lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getGrade() {
		return grade;
	}

	public void setGrade(String grade) {
		this.grade = grade;
	}


	public EmployeeTypeEntity getEmployeeTypeEntity() {
		return employeeTypeEntity;
	}

	public void setEmployeeTypeEntity(EmployeeTypeEntity employeeTypeEntity) {
		this.employeeTypeEntity = employeeTypeEntity;
	}
	
	

}
