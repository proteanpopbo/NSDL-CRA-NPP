package com.backend.nsdlnpp.models.calculation;

public class UserContributionRequest {

	private Integer employeeTypeId;
	private String empGrade;
	private String empType;
	private String startYear;
	private Integer avgYearlyContribution;

	public String getStartYear() {
		return startYear;
	}

	public void setStartYear(String startYear) {
		this.startYear = startYear;
	}

	public Integer getAvgYearlyContribution() {
		return avgYearlyContribution;
	}

	public void setAvgYearlyContribution(Integer avgYearlyContribution) {
		this.avgYearlyContribution = avgYearlyContribution;
	}

	public String getEmpType() {
		return empType;
	}

	public void setEmpType(String empType) {
		this.empType = empType;
	}

	public Integer getEmployeeTypeId() {
		return employeeTypeId;
	}

	public void setEmployeeTypeId(Integer employeeTypeId) {
		this.employeeTypeId = employeeTypeId;
	}

	public String getEmpGrade() {
		return empGrade;
	}

	public void setEmpGrade(String empGrade) {
		this.empGrade = empGrade;
	}

}
