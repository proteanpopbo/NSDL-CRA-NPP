package com.backend.nsdlnpp.service.external;

import com.backend.nsdlnpp.models.external.ExternalApiDto;
import com.backend.nsdlnpp.models.external.RequestDto;

public interface ExternalService {

	String saveApiData(ExternalApiDto externalApiDto, RequestDto requestDto);

	ExternalApiDto getApiData(String key);

}
