package com.backend.nsdlnpp.config.i18n;

import java.util.Locale;
import javax.servlet.http.HttpServletRequest;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.web.servlet.i18n.AcceptHeaderLocaleResolver;

@Configuration
public class I18nConfiguration {
	
	@Bean
	public AcceptHeaderLocaleResolver lanConfigurer() {
		return new AcceptHeaderLocaleResolver() {
			@Override
			public Locale resolveLocale(HttpServletRequest request) {
				String headerLang = request.getHeader("Accept-Language");
				return null == headerLang || headerLang.isEmpty() ? Locale.getDefault()
						: Locale.forLanguageTag(headerLang);
			}
		};

	}

//	@Bean
//	public LocaleResolver localeResolver() {
//		SessionLocaleResolver localeResolver = new SessionLocaleResolver();
//		localeResolver.setDefaultLocale(Locale.US);
//		return localeResolver;
//	}

	@Bean
	public ResourceBundleMessageSource messageSource() {
		ResourceBundleMessageSource messageSource = new ResourceBundleMessageSource();
		/* Passing basename sould match to the properties file basename */
		messageSource.setBasename("language");
	    messageSource.setDefaultEncoding("UTF-8");
		return messageSource;
	}
}

