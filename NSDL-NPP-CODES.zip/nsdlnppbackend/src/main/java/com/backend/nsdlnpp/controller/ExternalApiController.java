package com.backend.nsdlnpp.controller;

import java.text.SimpleDateFormat;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.backend.nsdlnpp.models.calculation.ContrbutionRequest;
import com.backend.nsdlnpp.models.calculation.ContributionResponse;
import com.backend.nsdlnpp.models.external.ExternalApiDto;
import com.backend.nsdlnpp.models.external.RequestDto;
import com.backend.nsdlnpp.service.calculator.Calculator;
import com.backend.nsdlnpp.service.external.ExternalService;
import com.fasterxml.jackson.databind.ObjectMapper;

@RestController
@RequestMapping("/api/external")
public class ExternalApiController {
	@Autowired
	private Calculator calculator;
	
	@Autowired
	private ExternalService externalService;
	
	SimpleDateFormat sdfFormat = new SimpleDateFormat("dd/MM/yyyy");
	
	@Value("${app.aes.secret.key}")
	private String secretKey;
	
	@Value("${app.ui.url}")
	private String uiURL;
	
	@GetMapping("/protean-npp")
	public ResponseEntity<String> getInformationFromApi(HttpServletRequest httpRequest,@RequestHeader Map<String, String> headers, HttpServletResponse response){
		try {
			String request = headers.get("requestdata");
			String id = "";
			if(request!=null && !request.isEmpty()) {
				ObjectMapper mapper = new ObjectMapper();
				RequestDto requestDto = mapper.readValue(request,RequestDto.class);
				ExternalApiDto externalApiDto = new ExternalApiDto();
				externalApiDto.setCallName(headers.get("callname"));
				externalApiDto.setChecksum(headers.get("checksum"));
				externalApiDto.setPran(headers.get("pran"));
				id = externalService.saveApiData(externalApiDto,requestDto);
				
			}
			//response.sendRedirect(uiURL+"/index.html?key"+id);
			//return ResponseEntity.ok(uiURL+"/API/index.html?key="+id);
			return ResponseEntity.ok(uiURL+"/index.html?key="+id);
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
			return ResponseEntity.ok(e.getMessage());
		}
	}
	
	@PostMapping("/protean-npp")
	public ResponseEntity<String> getPostInformationFromApi(HttpServletRequest httpRequest,@RequestHeader Map<String, String> headers, HttpServletResponse response){
		try {
			String request = headers.get("requestdata");
			String id = "";
			if(request!=null && !request.isEmpty()) {
				ObjectMapper mapper = new ObjectMapper();
				RequestDto requestDto = mapper.readValue(request,RequestDto.class);
				ExternalApiDto externalApiDto = new ExternalApiDto();
				externalApiDto.setCallName(headers.get("callname"));
				externalApiDto.setChecksum(headers.get("checksum"));
				externalApiDto.setPran(headers.get("pran"));
				id = externalService.saveApiData(externalApiDto,requestDto);
				
			}
			//response.sendRedirect(uiURL+"/index.html?key"+id);
			//return ResponseEntity.ok(uiURL+"/API/index.html?key="+id);
			return ResponseEntity.ok(uiURL+"/index.html?key="+id);
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
			return ResponseEntity.ok(e.getMessage());
		}	
	}
	
	@GetMapping("/getApiData")
	public ResponseEntity<?> getApiData(HttpServletRequest request,@RequestParam("key") String key) {
		try {
			ContrbutionRequest contrbutionRequest = new ContrbutionRequest();
			ExternalApiDto exdto = externalService.getApiData(key);
			contrbutionRequest.setEmpId(4);
			contrbutionRequest.setGrade("undefined");
			contrbutionRequest.setNpsCorPusVal(exdto.getCurrentNpsBalance());
			contrbutionRequest.setStartYear(sdfFormat.format(exdto.getDojNps()));
			ContributionResponse contributionResponse = calculator.contrbutionCal(contrbutionRequest);
			exdto.setAvgYearlyContribution(contributionResponse.getAvgYearleContribution());
			exdto.setEmpId(4);
			exdto.setGrade("undefined");
			return ResponseEntity.ok(exdto);
			
		}catch(Exception e) {
			e.printStackTrace();
			return ResponseEntity.ok(e.getMessage());
		}
	}

}