package com.backend.nsdlnpp.service.lan;

import com.fasterxml.jackson.databind.node.ObjectNode;

public interface LanguageService {

	public ObjectNode englisgLan();

	public ObjectNode hindiLan();

}
