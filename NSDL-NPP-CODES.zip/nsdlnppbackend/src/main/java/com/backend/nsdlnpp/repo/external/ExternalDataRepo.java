package com.backend.nsdlnpp.repo.external;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.backend.nsdlnpp.entity.external.ExternalDataEntity;

public interface ExternalDataRepo  extends JpaRepository<ExternalDataEntity,String>{
	Optional<ExternalDataEntity> findById(String id);
}
