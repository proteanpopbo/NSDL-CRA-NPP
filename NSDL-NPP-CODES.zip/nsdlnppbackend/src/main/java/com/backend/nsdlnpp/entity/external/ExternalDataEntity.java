package com.backend.nsdlnpp.entity.external;

import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name = "ext_data")
public class ExternalDataEntity {
	@Id
	@Column(name="id", length=100)
	private String id;
	
	private String pran;
	
	private String checksum;
	
	private String callName;
	
	private String userName;
	
	private String userSector;
	
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "Asia/Kolkata")
	@Basic
	@Temporal(TemporalType.TIMESTAMP)
	private Date dojNps;
	
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "Asia/Kolkata")
	@Basic
	@Temporal(TemporalType.TIMESTAMP)
	private Date dateOfBirth;
	
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "Asia/Kolkata")
	@Basic
	@Temporal(TemporalType.TIMESTAMP)
	private Date dateOfRetirement;
	
	private Double currentNpsBalance;
	
	private Double totalContribution;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getPran() {
		return pran;
	}

	public void setPran(String pran) {
		this.pran = pran;
	}

	public String getChecksum() {
		return checksum;
	}

	public void setChecksum(String checksum) {
		this.checksum = checksum;
	}

	public String getCallName() {
		return callName;
	}

	public void setCallName(String callName) {
		this.callName = callName;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserSector() {
		return userSector;
	}

	public void setUserSector(String userSector) {
		this.userSector = userSector;
	}

	public Date getDojNps() {
		return dojNps;
	}

	public void setDojNps(Date dojNps) {
		this.dojNps = dojNps;
	}

	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public Date getDateOfRetirement() {
		return dateOfRetirement;
	}

	public void setDateOfRetirement(Date dateOfRetirement) {
		this.dateOfRetirement = dateOfRetirement;
	}

	public Double getCurrentNpsBalance() {
		return currentNpsBalance;
	}

	public void setCurrentNpsBalance(Double currentNpsBalance) {
		this.currentNpsBalance = currentNpsBalance;
	}

	public Double getTotalContribution() {
		return totalContribution;
	}

	public void setTotalContribution(Double totalContribution) {
		this.totalContribution = totalContribution;
	}

}
