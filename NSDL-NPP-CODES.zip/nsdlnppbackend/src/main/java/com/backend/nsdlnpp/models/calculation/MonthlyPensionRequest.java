package com.backend.nsdlnpp.models.calculation;

public class MonthlyPensionRequest {

	private Integer empId;
	private String empGrade;
	private String empolyeeDod;
	private String empolyeeDor;
	private String empolyeeDoj;
	private double periodicDeposit;

	private double annuityPer;
	private double lumpsumPer;
	
	private double periodicRoi;
	
	
	public double getPeriodicRoi() {
		return periodicRoi;
	}

	public void setPeriodicRoi(double periodicRoi) {
		this.periodicRoi = periodicRoi;
	}

	public double getAnnuityPer() {
		return annuityPer;
	}

	public void setAnnuityPer(double annuityPer) {
		this.annuityPer = annuityPer;
	}

	public double getLumpsumPer() {
		return lumpsumPer;
	}

	public void setLumpsumPer(double lumpsumPer) {
		this.lumpsumPer = lumpsumPer;
	}

	public double getPeriodicDeposit() {
		return periodicDeposit;
	}

	public void setPeriodicDeposit(double periodicDeposit) {
		this.periodicDeposit = periodicDeposit;
	}

	public String getEmpolyeeDoj() {
		return empolyeeDoj;
	}

	public void setEmpolyeeDoj(String empolyeeDoj) {
		this.empolyeeDoj = empolyeeDoj;
	}

	public Integer getEmpId() {
		return empId;
	}

	public void setEmpId(Integer empId) {
		this.empId = empId;
	}

	public String getEmpGrade() {
		return empGrade;
	}

	public void setEmpGrade(String empGrade) {
		this.empGrade = empGrade;
	}

	public String getEmpolyeeDod() {
		return empolyeeDod;
	}

	public void setEmpolyeeDod(String empolyeeDod) {
		this.empolyeeDod = empolyeeDod;
	}

	public String getEmpolyeeDor() {
		return empolyeeDor;
	}

	public void setEmpolyeeDor(String empolyeeDor) {
		this.empolyeeDor = empolyeeDor;
	}

}
