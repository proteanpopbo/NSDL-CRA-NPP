package com.backend.nsdlnpp.models.calculation;

public class ContrbutionRequest {
	
	private int empId;
	private String grade;
	private String startYear;
	private double npsCorPusVal;
	
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getGrade() {
		return grade;
	}
	public void setGrade(String grade) {
		this.grade = grade;
	}
	public String getStartYear() {
		return startYear;
	}
	public void setStartYear(String startYear) {
		this.startYear = startYear;
	}
	public double getNpsCorPusVal() {
		return npsCorPusVal;
	}
	public void setNpsCorPusVal(double npsCorPusVal) {
		this.npsCorPusVal = npsCorPusVal;
	}

}
