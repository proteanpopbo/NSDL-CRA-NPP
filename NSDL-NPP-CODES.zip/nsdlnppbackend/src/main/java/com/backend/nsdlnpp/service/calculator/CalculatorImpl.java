package com.backend.nsdlnpp.service.calculator;

import com.backend.nsdlnpp.entity.masters.ContributionDetailsEntity;
import com.backend.nsdlnpp.entity.masters.EmployeeTypeEntity;
import com.backend.nsdlnpp.math.Formula;
import com.backend.nsdlnpp.models.calculation.AnnualContributionRequest;
import com.backend.nsdlnpp.models.calculation.AnnualContributionRequestV2;
import com.backend.nsdlnpp.models.calculation.AnnualContributionResponse;
import com.backend.nsdlnpp.models.calculation.ContrbutionRequest;
import com.backend.nsdlnpp.models.calculation.ContributionResponse;
import com.backend.nsdlnpp.models.calculation.CurrentNpsCorpusDto;
import com.backend.nsdlnpp.models.calculation.CurrentNpsCorpusRequest;
import com.backend.nsdlnpp.models.calculation.MonthlyEmiRequest;
import com.backend.nsdlnpp.models.calculation.MonthlyEmiResponse;
import com.backend.nsdlnpp.models.calculation.MonthlyPensionRequest;
import com.backend.nsdlnpp.models.calculation.MonthlyPensionRequiredRequest;
import com.backend.nsdlnpp.models.calculation.MonthlyPensionRequiredResponse;
import com.backend.nsdlnpp.models.calculation.RequiredMonthPensionGraph;
import com.backend.nsdlnpp.models.calculation.UserContributionRequest;
import com.backend.nsdlnpp.repo.masters.ContributionRepo;
import com.backend.nsdlnpp.repo.masters.EmployeeTypeRepo;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CalculatorImpl implements Calculator {

	@Autowired
	private ContributionRepo contributionRepo;

	@Autowired
	private EmployeeTypeRepo employeeTypeRepo;

	@Override
	public MonthlyEmiResponse monthlyEmi(MonthlyEmiRequest monthlyEmiRequest) {

		double pv = Formula.endFV(monthlyEmiRequest.getRateOfInterest(),
				monthlyEmiRequest.getNumberOfYearsContributingSince(), monthlyEmiRequest.getPeriodicDeposit(),
				monthlyEmiRequest.getPresentValue());

		double npsCorpusVal = Formula.npsCorpus(monthlyEmiRequest.getTenure(), pv, monthlyEmiRequest.getPmt(),
				monthlyEmiRequest.getFlatRoi(), monthlyEmiRequest.getPeriodicRoi());

		double lumpSumCorpus = Formula.interestCal(monthlyEmiRequest.getLumpSumPercentageRate(), npsCorpusVal);
		double annuityCorpus = Formula.interestCal(monthlyEmiRequest.getAnnuityPercentageRate(), npsCorpusVal);
		double monthlyPensionWithRop = Formula.monthlyPensionCal(monthlyEmiRequest.getAnnuityWithROPRate(),
				annuityCorpus);
		double monthlyPensionWithOutRop = Formula.monthlyPensionCal(monthlyEmiRequest.getAnnuityWithOutROPRate(),
				annuityCorpus);

		MonthlyEmiResponse monthlyEmiResponse = new MonthlyEmiResponse();
		monthlyEmiResponse.setCurrentNPSCorpus((int) Math.round(pv));
		monthlyEmiResponse.setMonthlyPensionWithRop((int) Math.round(monthlyPensionWithRop));
		monthlyEmiResponse.setMonthlyPensionWithOutRop((int) Math.round(monthlyPensionWithOutRop));
		monthlyEmiResponse.setAnnuityCorpus((int) Math.round(annuityCorpus));
		monthlyEmiResponse.setLumpSumCorpus((int) Math.round(lumpSumCorpus));
		monthlyEmiResponse.setNpsCorpus((int) Math.round(npsCorpusVal));

		return monthlyEmiResponse;
	}

	@Override
	public MonthlyEmiResponse getMonthlyPension(MonthlyPensionRequest monthlyPensionRequest) throws ParseException {

		Optional<ContributionDetailsEntity> contributionEntity = contributionRepo.findByGradeAndEmployeeTypeEntity_id(
				monthlyPensionRequest.getEmpGrade(), monthlyPensionRequest.getEmpId());

		if (contributionEntity.isPresent()) {
			MonthlyEmiResponse monthlyEmiResponse = new MonthlyEmiResponse();
			ContributionDetailsEntity contributionDetails = contributionEntity.get();

			double contributionSince = Formula.contributingSinceCal(monthlyPensionRequest.getEmpolyeeDoj());
			double tenure = Formula.remaningYear(monthlyPensionRequest.getEmpolyeeDod(),
					monthlyPensionRequest.getEmpolyeeDor());

			double pv = Formula.endFV(contributionDetails.getRateOfInterest().doubleValue(), contributionSince,
					monthlyPensionRequest.getPeriodicDeposit(), 0d);

			double npsCorpusVal = Formula.npsCorpus(tenure, pv, monthlyPensionRequest.getPeriodicDeposit(),
					contributionDetails.getFlatRoi().doubleValue(), monthlyPensionRequest.getPeriodicRoi());

			double projectedContributionVal = Formula.projectedContributionCal(tenure, pv,
					monthlyPensionRequest.getPeriodicDeposit(), contributionDetails.getFlatRoi().doubleValue(),
					monthlyPensionRequest.getPeriodicRoi(), contributionSince);

			double lumpSumCorpus = 0d;
			double annuityCorpus = 0d;
			// Lumpsum Persentage and Annuity Persentage changed to user Input
			if (tenure < 1) {
				// lumpSumCorpus =
				// Formula.interestCal(contributionDetails.getLumpSumPercentageRate().doubleValue(),
				// pv);
				// annuityCorpus =
				// Formula.interestCal(contributionDetails.getAnnuityPercentageRate().doubleValue(),
				// pv);
				lumpSumCorpus = Formula.interestCal(monthlyPensionRequest.getLumpsumPer(), pv);
				annuityCorpus = Formula.interestCal(monthlyPensionRequest.getAnnuityPer(), pv);

				monthlyEmiResponse.setNpsCorpus((int) Math.round(pv));
			} else {
				// lumpSumCorpus =
				// Formula.interestCal(contributionDetails.getLumpSumPercentageRate().doubleValue(),
				// npsCorpusVal);
				// annuityCorpus =
				// Formula.interestCal(contributionDetails.getAnnuityPercentageRate().doubleValue(),
				// npsCorpusVal);

				lumpSumCorpus = Formula.interestCal(monthlyPensionRequest.getLumpsumPer(), npsCorpusVal);
				annuityCorpus = Formula.interestCal(monthlyPensionRequest.getAnnuityPer(), npsCorpusVal);
				monthlyEmiResponse.setNpsCorpus((int) Math.round(npsCorpusVal));
			}

			double monthlyPensionWithRop = Formula
					.monthlyPensionCal(contributionDetails.getAnnuityRopRate().doubleValue(), annuityCorpus);
			double monthlyPensionWithOutRop = Formula
					.monthlyPensionCal(contributionDetails.getAnnuityWithoutRopRate().doubleValue(), annuityCorpus);

			monthlyEmiResponse.setCurrentNPSCorpus((int) Math.round(pv));
			monthlyEmiResponse.setMonthlyPensionWithRop((int) Math.round(monthlyPensionWithRop));
			monthlyEmiResponse.setMonthlyPensionWithOutRop((int) Math.round(monthlyPensionWithOutRop));
			monthlyEmiResponse.setAnnuityCorpus((int) Math.round(annuityCorpus));
			monthlyEmiResponse.setLumpSumCorpus((int) Math.round(lumpSumCorpus));

			monthlyEmiResponse.setProjectedContribution((int) Math.round(projectedContributionVal));

			return monthlyEmiResponse;
		}

		return null;

	}

	@Override
	public AnnualContributionResponse annualContributionCal(AnnualContributionRequest annualContributionRequest) {

		AnnualContributionResponse annualContributionResponse = new AnnualContributionResponse();

		double newAnnualContribution = Formula.GoalSeek(annualContributionRequest.getTenure(),
				annualContributionRequest.getTargetValue(), annualContributionRequest.getStartIterationFrom(),
				annualContributionRequest.getStartDepositIterationFrom(), annualContributionRequest.getRateOfInterest(),
				annualContributionRequest.getFlatRoi(), annualContributionRequest.getPeriodicRoi(),
				annualContributionRequest.getPeriodicDeposit(),
				annualContributionRequest.getNumberOfYearsContributingSince());

		annualContributionResponse.setNewAnnualContribution((int) Math.round(newAnnualContribution));

		return annualContributionResponse;

	}

	@Override
	public CurrentNpsCorpusDto getCurrentNpsCorpus(UserContributionRequest userContributionRequest, String startYear) {

		Optional<ContributionDetailsEntity> contributionEntity = contributionRepo.findByGradeAndEmployeeTypeEntity_id(
				userContributionRequest.getEmpGrade(), userContributionRequest.getEmployeeTypeId());
		int contributingSince = Formula.contributingSinceCal(startYear);
		double currentNPSCorpus = 0.0;
		CurrentNpsCorpusDto CurrentNpsCorpusDto = new CurrentNpsCorpusDto();
		if (contributionEntity.isPresent()) {
			ContributionDetailsEntity currentContributionDetailsEntity = contributionEntity.get();
			currentNPSCorpus = Formula.endFV(currentContributionDetailsEntity.getRateOfInterest().doubleValue(),
					contributingSince, currentContributionDetailsEntity.getContributionAmount().doubleValue(), 0d);

			CurrentNpsCorpusDto.setCurrentNPSCorpus((int) Math.round(currentNPSCorpus));
			CurrentNpsCorpusDto.setAverageAnnualContribution(
					currentContributionDetailsEntity.getContributionAmount().doubleValue());
		}

		return CurrentNpsCorpusDto;
	}

	@Override
	public CurrentNpsCorpusDto getCurrentNpsCorpusV2(CurrentNpsCorpusRequest currentNpsCorpusRequest) {

		Optional<ContributionDetailsEntity> contributionEntity = contributionRepo.findByGradeAndEmployeeTypeEntity_id(
				currentNpsCorpusRequest.getGrade(), currentNpsCorpusRequest.getEmployeeId());
		int contributingSince = Formula.contributingSinceCal(currentNpsCorpusRequest.getStartYear());

		double currentNPSCorpus = 0.0;
		CurrentNpsCorpusDto CurrentNpsCorpusDto = new CurrentNpsCorpusDto();
		if (contributionEntity.isPresent()) {
			ContributionDetailsEntity currentContributionDetailsEntity = contributionEntity.get();
			currentNPSCorpus = Formula.endFV(currentContributionDetailsEntity.getRateOfInterest().doubleValue(),
					contributingSince, currentNpsCorpusRequest.getAvgYearlyContribution().doubleValue(), 0d);

			double contributionSince = Formula.contributingSinceCal(currentNpsCorpusRequest.getStartYear());
			if (contributionSince < 1) {
				CurrentNpsCorpusDto
						.setCurrentNPSCorpus((int) Math.round(currentNpsCorpusRequest.getAvgYearlyContribution()));
			} else {
				CurrentNpsCorpusDto.setCurrentNPSCorpus((int) Math.round(currentNPSCorpus));
			}

			CurrentNpsCorpusDto
					.setAverageAnnualContribution(currentNpsCorpusRequest.getAvgYearlyContribution().doubleValue());
		}

		return CurrentNpsCorpusDto;
	}

	@Override
	public CurrentNpsCorpusDto getCurrentNpsCorpusNew(UserContributionRequest userContributionRequest,
			String startYear) {

		Optional<EmployeeTypeEntity> employeeTypeEntity = employeeTypeRepo
				.findByEmployeeType(userContributionRequest.getEmpType());

		if (employeeTypeEntity.isPresent()) {
			Optional<ContributionDetailsEntity> contributionEntity = contributionRepo
					.findByGradeAndEmployeeTypeEntity_id(userContributionRequest.getEmpGrade(),
							employeeTypeEntity.get().getId());

			int contributingSince = Formula.contributingSinceCal(startYear);
			double currentNPSCorpus = 0.0;
			CurrentNpsCorpusDto CurrentNpsCorpusDto = new CurrentNpsCorpusDto();
			if (contributionEntity.isPresent()) {
				ContributionDetailsEntity currentContributionDetailsEntity = contributionEntity.get();
				currentNPSCorpus = Formula.endFV(currentContributionDetailsEntity.getRateOfInterest().doubleValue(),
						contributingSince, currentContributionDetailsEntity.getContributionAmount().doubleValue(), 0d);

				CurrentNpsCorpusDto.setCurrentNPSCorpus((int) Math.round(currentNPSCorpus));
				CurrentNpsCorpusDto.setAverageAnnualContribution(
						currentContributionDetailsEntity.getContributionAmount().doubleValue());
			}
			return CurrentNpsCorpusDto;
		}

		return null;
	}

	@Override
	public AnnualContributionResponse annualContributionCalV2(AnnualContributionRequestV2 annualContributionRequestV2)
			throws ParseException {

		Optional<ContributionDetailsEntity> contributionEntity = contributionRepo.findByGradeAndEmployeeTypeEntity_id(
				annualContributionRequestV2.getEmpGrade(), annualContributionRequestV2.getEmpId());

		AnnualContributionResponse annualContributionResponse = new AnnualContributionResponse();
		double newAnnualContribution = 0d;
		if (contributionEntity.isPresent()) {
			ContributionDetailsEntity contribution = contributionEntity.get();
			double tenure = Formula.remaningYear(annualContributionRequestV2.getEmpolyeeDob(),
					annualContributionRequestV2.getEmpolyeeDor());

			double target = Formula.npsCorpusCal(annualContributionRequestV2.getMonthlyPension(),
					contribution.getAnnuityRopRate().doubleValue(), annualContributionRequestV2.getAnnuityPersent());

			double oldNpsCorpus = Formula.npsCorpusCal(annualContributionRequestV2.getPeriodicDeposit(),
					contribution.getAnnuityRopRate().doubleValue(), annualContributionRequestV2.getAnnuityPersent());
			double contributionSince = Formula.contributingSinceCal(annualContributionRequestV2.getEmpolyeeDoj());
			double currentNPSCorpus = Formula.endFV(contribution.getRateOfInterest().doubleValue(), contributionSince,
					annualContributionRequestV2.getPeriodicDeposit(), 0d);
			newAnnualContribution = Formula.GoalSeekV2(tenure, target, 0d, 0d, contribution.getFlatRoi().doubleValue(),
					annualContributionRequestV2.getPeriodicRoi(), currentNPSCorpus,
					annualContributionRequestV2.getPeriodicDeposit());

			double lumpSumRate = (100 - annualContributionRequestV2.getAnnuityPersent());

			double lumpSumCorpus = Formula.interestCal(lumpSumRate, target);
			double annuityCorpus = Formula.interestCal(annualContributionRequestV2.getAnnuityPersent(), target);

			double oldAnnuityCorpus = Formula.interestCal(annualContributionRequestV2.getAnnuityPersent(),
					oldNpsCorpus);

			double monthlyPensionWithRop = Formula.monthlyPensionCal(contribution.getAnnuityRopRate().doubleValue(),
					annuityCorpus);
			double monthlyPensionWithOutRop = Formula
					.monthlyPensionCal(contribution.getAnnuityWithoutRopRate().doubleValue(), annuityCorpus);

			double oldMonthlyPensionWithRop = Formula.monthlyPensionCal(contribution.getAnnuityRopRate().doubleValue(),
					oldAnnuityCorpus);
			double oldMonthlyPensionWithOutRop = Formula
					.monthlyPensionCal(contribution.getAnnuityWithoutRopRate().doubleValue(), oldAnnuityCorpus);

			annualContributionResponse.setNewAnnualContribution((int) Math.round(newAnnualContribution));
			annualContributionResponse.setCurrentNpsCorpus((int) Math.round(target));

			annualContributionResponse.setAnnuityCorpus((int) Math.round(annuityCorpus));
			annualContributionResponse.setLumpsumCorpus((int) Math.round(lumpSumCorpus));
			annualContributionResponse.setNewPension((int) Math.round(annualContributionRequestV2.getMonthlyPension()));
			annualContributionResponse.setPensionWithOutRop((int) Math.round(monthlyPensionWithOutRop));
			annualContributionResponse.setPensionWithRop((int) Math.round(monthlyPensionWithRop));

			annualContributionResponse.setOldPensionWithOutRop((int) Math.round(oldMonthlyPensionWithOutRop));
			annualContributionResponse.setOldPensionWithRop((int) Math.round(oldMonthlyPensionWithRop));

		}

		return annualContributionResponse;
	}

	@Override
	public MonthlyPensionRequiredResponse monthlyPensionRequiredCal(
			MonthlyPensionRequiredRequest monthlyPensionRequiredRequest) {

		double pensionRequired = (int) Math.round(Formula.endFVV2(monthlyPensionRequiredRequest.getInflationRate(),
				monthlyPensionRequiredRequest.getRetirement(), 0d, monthlyPensionRequiredRequest.getExpenses()));

		List<List<?>> monthlyPensionList = new ArrayList<>();
		int currentYear = monthlyPensionRequiredRequest.getCurrentYear();

		monthlyPensionList.add(Arrays.asList("Year", ""));
		double amount = monthlyPensionRequiredRequest.getExpenses();

		double retirementYear = 0d;
		for (int i = currentYear; i < monthlyPensionRequiredRequest.getRetirementDate(); i += 5) {

			String year = String.valueOf((int) Math.round(currentYear));
			// int amt = (int) Math.round(amount);
//			monthlyPensionList.add(new RequiredMonthPensionGraph(currentYear, (int) Math.round(amount)));

			amount = (int) Math.round(Formula.endFVV2(monthlyPensionRequiredRequest.getInflationRate(), retirementYear,
					0d, monthlyPensionRequiredRequest.getExpenses()));

			monthlyPensionList.add(Arrays.asList(year, amount));
			retirementYear += 5;

//			double newamount = amount;
//			double finalAmount = 0d;
//			for (int j = 0; j <= 5; j++) {
//				newamount = Formula.infaltionAmount(newamount, monthlyPensionRequiredRequest.getInflationRate());
//				finalAmount = newamount;
//			}
//			amount = finalAmount;
			currentYear += 5;
		}

		monthlyPensionList.add(Arrays.asList(monthlyPensionRequiredRequest.getRetirementDate(), pensionRequired));
		MonthlyPensionRequiredResponse monthlyPensionRequiredResponse = new MonthlyPensionRequiredResponse();

		monthlyPensionRequiredResponse.setPensionRequired(pensionRequired);
		monthlyPensionRequiredResponse.setMonthlyPensionList(monthlyPensionList);

		return monthlyPensionRequiredResponse;
	}

	@Override
	public ContributionResponse contrbutionCal(ContrbutionRequest contrbutionRequest) {
		ContributionResponse contributionResponse = new ContributionResponse();
		Optional<ContributionDetailsEntity> opContributionEntity = contributionRepo
				.findByGradeAndEmployeeTypeEntity_id(contrbutionRequest.getGrade(), contrbutionRequest.getEmpId());
		int contributingSince = Formula.contributingSinceCal(contrbutionRequest.getStartYear());
		double val = 0d;
		double totalContribution = 0d;
		if (opContributionEntity.isPresent()) {

			ContributionDetailsEntity contributionDetailsEntity = opContributionEntity.get();
			val = Formula.pmtV2(contributionDetailsEntity.getRateOfInterest().doubleValue(), contributingSince,
					contrbutionRequest.getNpsCorPusVal());

			totalContribution = val * contributingSince;

			contributionResponse.setAvgYearleContribution((int) Math.round(val));
			contributionResponse.setTotalContribution((int) Math.round(totalContribution));
		}

		return contributionResponse;
	}
}
