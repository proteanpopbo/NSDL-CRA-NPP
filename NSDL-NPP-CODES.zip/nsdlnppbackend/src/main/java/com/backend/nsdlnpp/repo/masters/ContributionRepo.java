package com.backend.nsdlnpp.repo.masters;

import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

import com.backend.nsdlnpp.entity.masters.ContributionDetailsEntity;

public interface ContributionRepo extends JpaRepository<ContributionDetailsEntity, Integer> {
	
	public Optional<ContributionDetailsEntity> findByGradeAndEmployeeTypeEntity_id(String grade, Integer employeeTypeEntityId);
	
	public List<ContributionDetailsEntity> findByEmployeeTypeEntity_id(Integer employeeTypeEntityId);
	
	

}
