package com.backend.nsdlnpp.service.lan;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.backend.nsdlnpp.entity.lan.LanguageEntity;
import com.backend.nsdlnpp.repo.lan.LanguageRepo;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

@Service
public class LanguageServiceImpl implements LanguageService {

	@Autowired
	private LanguageRepo languageRepo;

	@Override
	public ObjectNode englisgLan() {

		ObjectMapper objectMapper = new ObjectMapper();
		ObjectNode parentNode = objectMapper.createObjectNode();
		List<LanguageEntity> languageList = languageRepo.findAll();

		for (LanguageEntity languageEntity : languageList) {
			parentNode.put(languageEntity.getTextId(), languageEntity.getEnglish());
		}

		return parentNode;
	}

	@Override
	public ObjectNode hindiLan() {
		ObjectMapper objectMapper = new ObjectMapper();

		ObjectNode parentNode = objectMapper.createObjectNode();
		List<LanguageEntity> languageList = languageRepo.findAll();

		for (LanguageEntity languageEntity : languageList) {
			parentNode.put(languageEntity.getTextId(), languageEntity.getHindi());
		}

		return parentNode;
	}

}
