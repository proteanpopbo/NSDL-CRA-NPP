package com.backend.nsdlnpp.service.mastersservice;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.backend.nsdlnpp.entity.masters.ContributionDetailsEntity;
import com.backend.nsdlnpp.entity.masters.EmployeeTypeEntity;
import com.backend.nsdlnpp.mapper.contribution.ContributionMapper;
import com.backend.nsdlnpp.models.calculation.ContributionDetailsDto;
import com.backend.nsdlnpp.models.calculation.EmployeeTypeDto;
import com.backend.nsdlnpp.models.calculation.UserContributionRequest;
import com.backend.nsdlnpp.repo.masters.ContributionRepo;
import com.backend.nsdlnpp.repo.masters.EmployeeTypeRepo;

@Service
public class MasterServiceImpl implements MasterService {

	@Autowired
	private ContributionRepo contributionRepo;

	@Autowired
	private ContributionMapper contributionMapper;

	@Autowired
	private EmployeeTypeRepo employeeTypeRepo;

	@Override
	public ContributionDetailsDto getUserContribution(UserContributionRequest userContributionRequest) {

		Optional<ContributionDetailsEntity> contributionEntity = contributionRepo.findByGradeAndEmployeeTypeEntity_id(
				userContributionRequest.getEmpGrade(), userContributionRequest.getEmployeeTypeId());

		ContributionDetailsDto contributionDetailsDto = null;
		if (contributionEntity.isPresent()) {
			contributionDetailsDto = contributionMapper.contributioModelToDto(contributionEntity.get());
			return contributionDetailsDto;
		}

		return contributionDetailsDto;
	}

	@Override
	public List<String> getUserGrade(Integer empId) {
		List<ContributionDetailsEntity> contributionDetailsEntityList = contributionRepo
				.findByEmployeeTypeEntity_id(empId);

		List<String> gradeList = new ArrayList<>();
		for (ContributionDetailsEntity item : contributionDetailsEntityList) {
			gradeList.add(item.getGrade());
		}

		return gradeList;
	}

	@Override
	public List<EmployeeTypeDto> getEmpType() {
		
		List<EmployeeTypeEntity> employeeTypeEntityList = employeeTypeRepo.findAll();
		List<EmployeeTypeDto> employeeTypeDtoList = new ArrayList<>();
		
		for(EmployeeTypeEntity item : employeeTypeEntityList) {
			EmployeeTypeDto employeeTypeDto = new EmployeeTypeDto();
			employeeTypeDto.setEmployeeType(item.getEmployeeType());
			employeeTypeDto.setId(item.getId());
			employeeTypeDtoList.add(employeeTypeDto);
		}
		
		return employeeTypeDtoList;
	}

}
