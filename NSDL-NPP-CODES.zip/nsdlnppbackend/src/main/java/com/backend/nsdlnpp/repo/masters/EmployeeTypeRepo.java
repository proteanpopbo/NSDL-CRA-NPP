package com.backend.nsdlnpp.repo.masters;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import com.backend.nsdlnpp.entity.masters.EmployeeTypeEntity;

public interface EmployeeTypeRepo extends JpaRepository<EmployeeTypeEntity, Integer>{
	
	Optional<EmployeeTypeEntity> findByEmployeeType(String employeeType);

}
