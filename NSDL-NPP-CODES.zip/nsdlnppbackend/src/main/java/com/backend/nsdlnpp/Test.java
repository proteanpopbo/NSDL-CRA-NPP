package com.backend.nsdlnpp;

import com.backend.nsdlnpp.math.Formula;
import com.backend.nsdlnpp.models.calculation.MonthlyEmiResponse;
import com.backend.nsdlnpp.service.calculator.Calculator;

public class Test {

    public static void main(String[] args) {

//        double pv = Formula.endFV(9.10d, 11d, 60000d, 0d);
//        double npsCorpusVal = Formula.npsCorpus(22d, pv, 100000d, 8.00, 10d);
//        double lumpSumCorpus = Formula.interestCal(60,npsCorpusVal);
//        double annuityCorpus = Formula.interestCal(40,npsCorpusVal);
//        double monthlyEmi = Formula.monthlyEmiCal(5.5,annuityCorpus);
//
//        System.out.println("Current NPS Corpus" + "- " + (int) Math.round(pv));
//        System.out.println("NPS Corpus" + "- " + (int) Math.round(npsCorpusVal));
//        System.out.println("Lump-sum Corpus" + "- " + (int) Math.round(lumpSumCorpus));
//        System.out.println("Annuity Corpus" + "- " + (int) Math.round(annuityCorpus));
//        System.out.println("Monthly Emi" + "- " + (int) Math.round(monthlyEmi));

        //MonthlyEmiResponse monthlyEmiResponse = Calculator.monthlyEmi(monthlyEmiRequest);

//        double currentNPSCorpus = 1006851;
//        double targetValue = 65454545d;
//        double startValue = 0d;
//        double startDeposit = 0d;
//
//        for(startValue=0; startValue<=targetValue; startValue++){
//            startValue = Formula.npsCorpus(25d, currentNPSCorpus, startDeposit, 8.00, 10d);
//            startDeposit += 1;
//        }
//
//        System.out.println((int) Math.round(startDeposit));

//        double annualContribution = Formula.GoalSeek(25d, 43636364d,
//                0d, 0d,9.10d,8d,10d,100000d,
//                7d);
//        System.out.println((int) Math.round(annualContribution));
    	
    	System.out.println(Formula.contributingSinceCal("2011"));
    }


}
