package com.backend.nsdlnpp.controller;

import com.backend.nsdlnpp.math.Formula;
import com.backend.nsdlnpp.models.age.RetirmentYearRequest;
import com.backend.nsdlnpp.models.calculation.AnnualContributionRequest;
import com.backend.nsdlnpp.models.calculation.AnnualContributionRequestV2;
import com.backend.nsdlnpp.models.calculation.AnnualContributionResponse;
import com.backend.nsdlnpp.models.calculation.ContrbutionRequest;
import com.backend.nsdlnpp.models.calculation.ContributionResponse;
import com.backend.nsdlnpp.models.calculation.CurrentNpsCorpusDto;
import com.backend.nsdlnpp.models.calculation.CurrentNpsCorpusRequest;
import com.backend.nsdlnpp.models.calculation.MonthlyEmiRequest;
import com.backend.nsdlnpp.models.calculation.MonthlyEmiResponse;
import com.backend.nsdlnpp.models.calculation.MonthlyPensionRequest;
import com.backend.nsdlnpp.models.calculation.MonthlyPensionRequiredRequest;
import com.backend.nsdlnpp.models.calculation.MonthlyPensionRequiredResponse;
import com.backend.nsdlnpp.models.calculation.UserContributionRequest;
import com.backend.nsdlnpp.service.calculator.Calculator;
import com.backend.nsdlnpp.service.lan.LanguageService;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

import java.text.ParseException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/calculator")
public class CalculationApiController {

	@Autowired
	private Calculator calculator;

	@GetMapping("/getCurrentNpsCorpus/{employeeId}/{grade}/{startYear}")
	public ResponseEntity<?> getCurrentNpsCorpus(@PathVariable("employeeId") Integer employeeId,
			@PathVariable("grade") String grade, @PathVariable("startYear") String startYear) {

		UserContributionRequest userContributionRequest = new UserContributionRequest();
		userContributionRequest.setEmpGrade(grade);
		userContributionRequest.setEmployeeTypeId(employeeId);

		CurrentNpsCorpusDto currentNpsCorpusDto = calculator.getCurrentNpsCorpus(userContributionRequest, startYear);
		if (currentNpsCorpusDto != null)
			return ResponseEntity.ok(currentNpsCorpusDto);

		return ResponseEntity.ok("Employee does not exist");
	}

	@GetMapping("/getCurrentNpsCorpusV2/{employeeType}/{grade}/{startYear}")
	public ResponseEntity<?> getCurrentNpsCorpusNew(@PathVariable("employeeType") String employeeType,
			@PathVariable("grade") String grade, @PathVariable("startYear") String startYear) {

		UserContributionRequest userContributionRequest = new UserContributionRequest();
		userContributionRequest.setEmpGrade(grade);
		userContributionRequest.setEmpType(employeeType);

		CurrentNpsCorpusDto currentNpsCorpusDto = calculator.getCurrentNpsCorpusNew(userContributionRequest, startYear);
		if (currentNpsCorpusDto != null)
			return ResponseEntity.ok(currentNpsCorpusDto);

		return ResponseEntity.ok("Employee does not exist");
	}

	@PostMapping("/getCurrentNpsCorpusV3")
	public ResponseEntity<?> getCurrentNpsCorpusV3(@RequestBody CurrentNpsCorpusRequest currentNpsCorpusRequest) {

		if (currentNpsCorpusRequest.getAvgYearlyContribution() != null
				&& currentNpsCorpusRequest.getEmployeeId() != null && currentNpsCorpusRequest.getGrade() != null
				&& currentNpsCorpusRequest.getStartYear() != null) {
			CurrentNpsCorpusDto currentNpsCorpusDto = calculator.getCurrentNpsCorpusV2(currentNpsCorpusRequest);

			if (currentNpsCorpusDto != null)
				return ResponseEntity.ok(currentNpsCorpusDto);
		}

		return ResponseEntity.ok("Employee does not exist");
	}

	@PostMapping("/getMonthlyEmi")
	public ResponseEntity<?> getMonthlyEmi(@RequestBody MonthlyEmiRequest monthlyEmiRequest) {
		MonthlyEmiResponse monthlyEmiResponse = null;
		try {
			monthlyEmiResponse = calculator.monthlyEmi(monthlyEmiRequest);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return ResponseEntity.ok(monthlyEmiResponse);
	}

	@PostMapping("/getMonthlyPension")
	public ResponseEntity<?> getMonthlyPension(@RequestBody MonthlyPensionRequest monthlyPensionRequest) {
		MonthlyEmiResponse monthlyEmiResponse = null;
		try {
			monthlyEmiResponse = calculator.getMonthlyPension(monthlyPensionRequest);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return ResponseEntity.ok(monthlyEmiResponse);
	}

	@PostMapping("/getAnnualContribution")
	public ResponseEntity<?> getAnnualContribution(@RequestBody AnnualContributionRequest annualContributionRequest) {
		AnnualContributionResponse annualContributionRespons = null;
		try {
			annualContributionRespons = calculator.annualContributionCal(annualContributionRequest);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return ResponseEntity.ok(annualContributionRespons);
	}

	@PostMapping("/getAnnualContributionV2")
	public ResponseEntity<?> getAnnualContributionV2(
			@RequestBody AnnualContributionRequestV2 annualContributionRequestV2) {
		AnnualContributionResponse annualContributionRespons = null;
		try {
			annualContributionRespons = calculator.annualContributionCalV2(annualContributionRequestV2);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return ResponseEntity.ok(annualContributionRespons);
	}

	@PostMapping("/getRetirementYear")
	public ResponseEntity<?> getRetirementYear(@RequestBody RetirmentYearRequest retirmentYearRequest)
			throws ParseException {

		ObjectMapper objectMapper = new ObjectMapper();
		ObjectNode parentNode = objectMapper.createObjectNode();

		parentNode.put("retirementYear",
				Formula.remaningYear(retirmentYearRequest.getDob(), retirmentYearRequest.getRetirementDate()));
		parentNode.put("age", Formula.ageCal(retirmentYearRequest.getDob()));

		return ResponseEntity.ok(parentNode);
	}

	@PostMapping("/getMonthlyPensionRequired")
	public ResponseEntity<?> getMonthlyPensionRequired(
			@RequestBody MonthlyPensionRequiredRequest monthlyPensionRequiredRequest) {

		MonthlyPensionRequiredResponse monthlyPensionRequiredResponse = null;
		try {
			monthlyPensionRequiredResponse = calculator.monthlyPensionRequiredCal(monthlyPensionRequiredRequest);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

		return ResponseEntity.ok(monthlyPensionRequiredResponse);
	}

	@PostMapping("/getContrbution")
	public ResponseEntity<?> getContrbution(@RequestBody ContrbutionRequest contrbutionRequest) {

		ContributionResponse contributionResponse = new ContributionResponse();
		try {
			contributionResponse = calculator.contrbutionCal(contrbutionRequest);

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return ResponseEntity.ok(contributionResponse);
	}

}
