package com.backend.nsdlnpp.service.external;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.backend.nsdlnpp.entity.external.ExternalDataEntity;
import com.backend.nsdlnpp.models.external.ExternalApiDto;
import com.backend.nsdlnpp.models.external.RequestDto;
import com.backend.nsdlnpp.repo.external.ExternalDataRepo;


@Service
public class ExternalServiceImpl implements ExternalService{
	@Autowired
	private ExternalDataRepo externalDataRepo;

	SimpleDateFormat sdfFormat = new SimpleDateFormat("yyyy-MM-dd");
	
	@Override
	public String saveApiData(ExternalApiDto externalApiDto, RequestDto requestDto) {
		
		Optional<ExternalDataEntity> externalDataEntity = externalDataRepo.findById(externalApiDto.getPran());
		ExternalDataEntity extDataEntity = null;
		if(externalDataEntity.isEmpty()) {
			extDataEntity = new ExternalDataEntity();
			extDataEntity.setId(externalApiDto.getPran());
		}else {
			extDataEntity = externalDataEntity.get();
		}
		extDataEntity.setCallName(externalApiDto.getCallName());
		extDataEntity.setChecksum(externalApiDto.getChecksum());
		extDataEntity.setPran(externalApiDto.getPran());
		
		extDataEntity.setUserName(requestDto.getUser_name());
		extDataEntity.setUserSector(requestDto.getUser_sector());
		extDataEntity.setDateOfBirth(requestDto.getDate_of_birth());
		extDataEntity.setDateOfRetirement(requestDto.getDate_of_retirement());
		extDataEntity.setDojNps(requestDto.getDoj_nps());
		extDataEntity.setTotalContribution(requestDto.getTotal_contribution());
		extDataEntity.setCurrentNpsBalance(requestDto.getCurrent_nps_balance());
		
		extDataEntity = externalDataRepo.save(extDataEntity);
		return extDataEntity.getId();
	}

	@Override
	public ExternalApiDto getApiData(String key) {
		Optional<ExternalDataEntity> externalDataEntity = externalDataRepo.findById(key);
		ExternalDataEntity extDataEntity = null;
		if(!externalDataEntity.isEmpty()) {
			ExternalApiDto externalApiDto = new ExternalApiDto();
			extDataEntity = externalDataEntity.get();
//			externalApiDto.setId(extDataEntity.getPran());
			externalApiDto.setCallName(extDataEntity.getCallName());
			externalApiDto.setChecksum(extDataEntity.getChecksum());
			externalApiDto.setPran(extDataEntity.getPran());
			externalApiDto.setUserName(extDataEntity.getUserName());
			externalApiDto.setUserSector(extDataEntity.getUserSector());
			externalApiDto.setDateOfBirth(extDataEntity.getDateOfBirth());
			externalApiDto.setDateOfRetirement(extDataEntity.getDateOfRetirement());
			externalApiDto.setDojNps(extDataEntity.getDojNps());
			externalApiDto.setTotalContribution(extDataEntity.getTotalContribution());
			externalApiDto.setCurrentNpsBalance(extDataEntity.getCurrentNpsBalance());
			
			return externalApiDto;
		}
		else 
			return null;
		
	}

}
