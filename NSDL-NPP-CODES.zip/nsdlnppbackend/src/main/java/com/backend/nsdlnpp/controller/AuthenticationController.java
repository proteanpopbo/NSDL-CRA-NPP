package com.backend.nsdlnpp.controller;

import com.backend.nsdlnpp.models.auth.AuthenticationRequest;
import com.backend.nsdlnpp.models.auth.AuthenticationResponse;
import com.backend.nsdlnpp.service.userservice.MyUserDetailsService;
import com.backend.nsdlnpp.util.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.nio.charset.StandardCharsets;
import java.util.Base64;

@RestController
@RequestMapping("/api")
public class AuthenticationController {

    @Autowired
    AuthenticationManager authenticationManager;

    @Autowired
    JwtUtil jwtUtil;

    @Autowired
    MyUserDetailsService userDetailsService;

    @GetMapping("/hello")
    public String hello() {
        return "Hello.." + String.valueOf(SecurityContextHolder.getContext().getAuthentication().getPrincipal());
    }


    @PostMapping("/authenticate")
    public ResponseEntity<AuthenticationResponse> createAuthenticationToken(HttpServletRequest request) throws Exception {

        AuthenticationRequest authenticatationRequest = null;
        try {
            final String authorization = request.getHeader("Authorization");
            if (authorization != null && authorization.toLowerCase().startsWith("basic")) {
                // Authorization: Basic base64credentials
                String base64Credentials = authorization.substring("Basic".length()).trim();
                byte[] credDecoded = Base64.getDecoder().decode(base64Credentials);
                String credentials = new String(credDecoded, StandardCharsets.UTF_8);
                // credentials = username:password
                final String[] values = credentials.split(":", 2);
                authenticatationRequest = new AuthenticationRequest(values[0], values[1]);
            }

            authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(
                    authenticatationRequest.getUserName(), authenticatationRequest.getPassword()));

        } catch (BadCredentialsException e) {
            throw new Exception("Incorrect username or password", e);
        }

        final UserDetails userDetails = userDetailsService.loadUserByUsername(authenticatationRequest.getUserName());
        final String jwt = jwtUtil.generateToken(userDetails);
        return ResponseEntity.ok(new AuthenticationResponse(jwt));
    }

    @PostMapping("/check-token")
    public ResponseEntity<AuthenticationResponse> checkToken(HttpServletRequest request) throws Exception {

        final String authorizationHeader = request.getHeader("Authorization");
        String username = null;
        String jwt = null;

        if (StringUtils.hasText(authorizationHeader) && authorizationHeader.startsWith("Bearer ")) {
            jwt = authorizationHeader.substring(7);
            username = jwtUtil.extractUsername(jwt);
        }

        UserDetails userDetails = userDetailsService.loadUserByUsername(username);

        if (!jwtUtil.validateToken(jwt, userDetails))
            throw new BadCredentialsException("Token is not valid");

        if (jwtUtil.isTokenExpired(jwt))
            throw new BadCredentialsException("Token is not expired");

        return ResponseEntity.ok(new AuthenticationResponse(jwt));
    }
}
