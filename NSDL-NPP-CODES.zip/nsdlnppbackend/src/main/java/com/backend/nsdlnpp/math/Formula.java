package com.backend.nsdlnpp.math;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.apache.poi.ss.formula.functions.FinanceLib;
import org.joda.time.DateTime;
import org.joda.time.LocalDate;
import org.joda.time.LocalDateTime;
import org.joda.time.Years;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import com.backend.nsdlnpp.models.age.Age;

public class Formula {

	private Formula() {
	}

	public static double endFV(double rate, double nper, double periodicDeposit, double pv) {
		double r = rate / 100d;
		return FinanceLib.fv(r, nper, -periodicDeposit, pv, true);
	}

	public static double endFVV2(double rate, double nper, double periodicDeposit, double pv) {
		double r = rate / 100d;
		return FinanceLib.fv(r, nper, -periodicDeposit, -pv, true);
	}

	public static double beginingFV(double rate, double nper, double periodicDeposit, double pv) {
		double r = rate / 100d;
		return FinanceLib.fv(r, nper, -periodicDeposit, pv, false);
	}

	/**
	 * <p>
	 * Calculate pmt equivalent of xls pmt formula base is per lac
	 * <p>
	 *
	 * @param rate
	 * @param month
	 * @return
	 */
	public static double pmt(double rate, double month, double periodicDeposit) {

		double r = rate / 100d;
		return FinanceLib.pmt(r / 12d, month * 12, -periodicDeposit / 12d, 0d, true);
	}

	public static double pmtV2(double rate, double month, double periodicDeposit) {

		if (month == 0)
			return periodicDeposit;

		double r = rate / 100d;
		return FinanceLib.pmt(r, month, 0d, -periodicDeposit, true);
	}

	public static double npsCorpus(double tenure, double pv, double pmt, double rateOfInterest,
			double rateOfIncreasePmt) {
		double value = 0d;

		if (pv < 1)
			pv = pmt;

		for (int i = 1; i <= tenure; i++) {
			value = endFV(rateOfInterest, 1d, pmt, -pv);
			pmt = pmt + ((pmt * rateOfIncreasePmt) / 100d);
			pv = value;
		}

		return value;
	}

	public static double npsCorpusV2(double tenure, double pv, double pmt, double rateOfInterest,
			double rateOfIncreasePmt) {
		double value = 0d;

		for (int i = 1; i <= tenure; i++) {
			value = endFV(rateOfInterest, 1d, pmt, -pv);
			pmt = pmt + ((pmt * rateOfIncreasePmt) / 100d);
			pv = value;
		}

		return value;
	}

	public static double projectedContributionCal(double tenure, double pv, double pmt, double rateOfInterest,

			double rateOfIncreasePmt, double contributionSince) {
		double value = 0d;
		double pd = pmt;
		double pj = pmt;
		for (int i = 1; i < tenure; i++) {
			value = endFV(rateOfInterest, 1d, pmt, -pv);
			pmt = pmt + ((pmt * rateOfIncreasePmt) / 100d);

			pj += pmt;
			pv = value;
		}

		if (tenure < 1)
			return (int) Math.round(contributionSince * pd);

		return (int) Math.round(((contributionSince * pd) + pj));
	}

	public static double interestCal(double rate, double amount) {
		return (amount * rate) / 100d;
	}

	public static double monthlyPensionCal(double rate, double amount) {
		return ((amount * rate) / 100d) / 12d;
	}

	public static double targetValueCal(double lumpSumRate, double annuityRate, double amount) {
		return 0.0;
	}

	public static double GoalSeek(double tenure, double targetValue, double startIterationFrom,
			double startDepositIterationFrom, double rateOfInterest, double flatRoi, double periodicRoi,
			double periodicDeposit, double numberOfYearsContributingSince) {

		double currentNPSCorpus = endFV(rateOfInterest, numberOfYearsContributingSince, periodicDeposit, 0d);
		for (startIterationFrom = 0; startIterationFrom <= targetValue; startIterationFrom++) {
			startIterationFrom = npsCorpus(tenure, currentNPSCorpus, startDepositIterationFrom, flatRoi, periodicRoi);
			startDepositIterationFrom += 1;
		}

		return startDepositIterationFrom;
	}

	public static double GoalSeekV2(double tenure, double targetValue, double startIterationFrom,
			double startDepositIterationFrom, double flatRoi, double periodicRoi, double currentNPSCorpus,
			double PeriodicDeposit) {

		if (currentNPSCorpus < 1)
			currentNPSCorpus = PeriodicDeposit;
		for (startIterationFrom = 0; startIterationFrom <= targetValue; startIterationFrom++) {
			startIterationFrom = npsCorpus(tenure, currentNPSCorpus, startDepositIterationFrom, flatRoi, periodicRoi);
			startDepositIterationFrom += 1;
		}

		return startDepositIterationFrom;
	}

	/*
	 * New changes implemented after CR Implementation 12-0ct-2022 year increase by
	 * one when its greater then 6 mounth
	 */
	public static Integer contributingSinceCal(String year) {

//		DateTimeFormatter formatter = DateTimeFormat.forPattern("dd/mm/yyyy");
//		LocalDate now = new LocalDate();
//		DateTime from = formatter.parseDateTime(year);
//		LocalDate localFrom = from.toLocalDate();
//
//		Integer yearVal = Years.yearsBetween(localFrom, now).getYears();

//		System.out.println("yearVal" + "||" + yearVal + "||" + "year" + year);
//
//		System.out.println("now" + "||" + now + "||" + "localFrom" + localFrom);
		Date nowDate = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		Date joiningDate;
		try {
			joiningDate = sdf.parse(year);
			int yearCount = 0;
			Age yearVal = AgeCalculator.calculateAge(joiningDate, nowDate);

			yearCount = yearVal.getYears();

			if (yearVal.getMonths() >= 6)
				yearCount++;

			return yearCount;
		} catch (ParseException e) {
			e.printStackTrace();
		}

		return 0;

	}

	public static Integer remaningYear(String empDob, String retirementDate) throws ParseException {

		int userRetairment = 0;
		int userAge = 0;
		LocalDate now = new LocalDate();
		DateTimeFormatter formatter = DateTimeFormat.forPattern("dd/MM/yyyy");

		DateTime birthdate = formatter.parseDateTime(empDob);
		LocalDate localDob = birthdate.toLocalDate();

		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		Date dob = sdf.parse(empDob);
		Date dor = sdf.parse(retirementDate);
		Date nowDate = new Date();
		Age retirmrntAge = AgeCalculator.calculateAge(dob, dor);

		Age agell = AgeCalculator.calculateAge(dob, nowDate);
		Years age = Years.yearsBetween(localDob, now);

		// System.out.println(age);
		if (agell.getMonths() >= 6) {
			userAge = agell.getYears() + 1;
		} else {
			userAge = agell.getYears();
		}

		if (retirmrntAge.getMonths() >= 6) {
			userRetairment = retirmrntAge.getYears() + 1;
		} else {
			userRetairment = retirmrntAge.getYears();
		}

		return userRetairment - userAge;
	}

	public static Integer ageCal(String empDob) throws ParseException {

		int userAge = 0;
		LocalDate now = new LocalDate();
		DateTimeFormatter formatter = DateTimeFormat.forPattern("dd/MM/yyyy");
		DateTime birthdate = formatter.parseDateTime(empDob);
		LocalDate localDob = birthdate.toLocalDate();

		Years age = Years.yearsBetween(localDob, now);

		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		Date dob = sdf.parse(empDob);
		Date nowDate = new Date();

		Age agell = AgeCalculator.calculateAge(dob, nowDate);
		if (agell.getMonths() >= 6) {
			userAge = agell.getYears() + 1;
		} else {
			userAge = agell.getYears();
		}
		return userAge;
	}

	public static Integer retirementCal(Integer currentAge, Integer retirementAge) {
		return (retirementAge - currentAge);
	}

	public static Integer npsCorpusCal(double monthlyPension, double annuityRate, double annuityPersent) {

		double rate = annuityRate / 100d;
		double annuityCorpus = (monthlyPension / rate) * 12d;
		double ap = annuityPersent / 100d;
		return ((int) Math.round(annuityCorpus / ap));
	}

	public static Integer retirementYear(String year) {

		DateTimeFormatter formatter = DateTimeFormat.forPattern("dd/MM/yyyy");
		LocalDate now = new LocalDate();
		DateTime from = formatter.parseDateTime(year);
		LocalDate localFrom = from.toLocalDate();

		return Years.yearsBetween(localFrom, now).getYears();
	}

	public static double infaltionAmount(double expenses, double inflationRate) {
		double rate = inflationRate / 100d;

		double inflationAmount = (expenses * rate);

		return expenses + inflationAmount;
	}

}
