package com.backend.nsdlnpp.service.mastersservice;

import java.util.List;

import com.backend.nsdlnpp.models.calculation.ContributionDetailsDto;
import com.backend.nsdlnpp.models.calculation.EmployeeTypeDto;
import com.backend.nsdlnpp.models.calculation.UserContributionRequest;

public interface MasterService {
	
	public ContributionDetailsDto getUserContribution(UserContributionRequest userContributionRequest);  
	
	public List<String> getUserGrade(Integer empId);
	
	public List<EmployeeTypeDto> getEmpType();
}
