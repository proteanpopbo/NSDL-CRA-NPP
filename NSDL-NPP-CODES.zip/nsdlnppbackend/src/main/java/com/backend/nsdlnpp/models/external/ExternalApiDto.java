package com.backend.nsdlnpp.models.external;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;

public class ExternalApiDto {
	private String checksum;
	private String pran;
	private String callName;
	private String requestdata;
	
	private int empId;
	private String grade;
	
	
	private String userName;
	private String userSector;
	@JsonFormat(pattern = "dd/MM/yyyy")
	private Date dojNps;
	@JsonFormat(pattern = "dd/MM/yyyy")
	private Date dateOfBirth;
	@JsonFormat(pattern = "dd/MM/yyyy")
	private Date dateOfRetirement;
	private Double currentNpsBalance;
	private Double totalContribution;
	private Integer avgYearlyContribution;
	
	public String getChecksum() {
		return checksum;
	}
	public void setChecksum(String checksum) {
		this.checksum = checksum;
	}
	public String getPran() {
		return pran;
	}
	public void setPran(String pran) {
		this.pran = pran;
	}
	public String getCallName() {
		return callName;
	}
	public void setCallName(String callName) {
		this.callName = callName;
	}
	public String getRequestdata() {
		return requestdata;
	}
	public void setRequestdata(String requestdata) {
		this.requestdata = requestdata;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserSector() {
		return userSector;
	}
	public void setUserSector(String userSector) {
		this.userSector = userSector;
	}
	public Date getDojNps() {
		return dojNps;
	}
	public void setDojNps(Date dojNps) {
		this.dojNps = dojNps;
	}
	public Date getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public Date getDateOfRetirement() {
		return dateOfRetirement;
	}
	public void setDateOfRetirement(Date dateOfRetirement) {
		this.dateOfRetirement = dateOfRetirement;
	}
	public Double getCurrentNpsBalance() {
		return currentNpsBalance;
	}
	public void setCurrentNpsBalance(Double currentNpsBalance) {
		this.currentNpsBalance = currentNpsBalance;
	}
	public Double getTotalContribution() {
		return totalContribution;
	}
	public void setTotalContribution(Double totalContribution) {
		this.totalContribution = totalContribution;
	}
	public Integer getAvgYearlyContribution() {
		return avgYearlyContribution;
	}
	public void setAvgYearlyContribution(Integer avgYearlyContribution) {
		this.avgYearlyContribution = avgYearlyContribution;
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getGrade() {
		return grade;
	}
	public void setGrade(String grade) {
		this.grade = grade;
	}
	
}
