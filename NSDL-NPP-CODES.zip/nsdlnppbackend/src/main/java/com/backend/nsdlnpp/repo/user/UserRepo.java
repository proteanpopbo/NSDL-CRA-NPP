package com.backend.nsdlnpp.repo.user;

import com.backend.nsdlnpp.entity.user.Users;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface UserRepo extends JpaRepository<Users, Integer> {
    public Optional<Users> findByUserName(String username);
    public Optional<Users> findByEmail(String email);
}
