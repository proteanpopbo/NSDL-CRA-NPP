
// Backward Button Disabled
// $(document).ready(function () {
//     history.pushState(null, document.title, location.href);
// });



// Backward Button Disabled
// $(document).ready(function () {
//     history.pushState(null, document.title, location.href);

//  });

//  var x = window.location.hostname;
//  if(x == 'localhost'){
//      alert('ok');
//  }

//  console.log('sssssssss'+ x)
// var flag = JSON.parse(sessionStorage.getItem('isValidRedirection'));
// if(flag.contribution == 'Y' || flag.dontKnow == 'Y' || flag.howmuchDoiNeed == 'Y' || flaglag.pensionCalculation == 'Y' || flag.select_profile == 'Y' || flag.whatShouldiDo == 'Y'){
//     window.location.href = '../../index.html';
// }
// console.log(flag)

// contribution: ""
// dontKnow: ""
// howmuchDoiNeed: ""
// pensionCalculation: ""
// select_profile: ""
// whatShouldiDo: ""

;  



// if (x == "selectProfile.html || x == contribution.html || x == pensionCalculation.html || x == ") {
//     console.log(x);
// } else {
//     window.location.href = "index.html";
// };