const lngs = {
    en: {
        nativeName: 'English'
    },
    hi: {
        nativeName: 'हिन्दी'
    }
};

const rerender = () => {
    $('body').localize();
}

$(function () {
    i18next
        .use(i18nextHttpBackend)
        .use(i18nextBrowserLanguageDetector)
        .init({
            debug: true,
            useDataAttrOptions: true,
            fallbackLng: 'en',
            interpolation: {
                escapeValue: false,
              }
        }, (err, t) => {
            if (err) return console.error(err);

            jqueryI18next.init(i18next, $,{
                interpolation: {
                    escapeValue: false,
                  }
            });
            $('body').localize();

            Object.keys(lngs).map((lng) => {
                const opt = new Option(lngs[lng].nativeName, lng);
                if (lng === i18next.resolvedLanguage) {
                    opt.setAttribute("selected", "selected");
                }
                $('#languageSwitcher').append(opt);
                $('#languageSwitcher').change(function(){
                    // showLoader();
                    location.reload(true);
                    // hideLoader();
                })
            });

            $('#languageSwitcher').change((a, b, c) => {
                const chosenLng = $(this).find("option:selected").attr('value');
                i18next.changeLanguage(chosenLng, () => {
                    rerender();
                });
            });

            rerender();
        });
});



function showLoader() {
	$('body').addClass('notLoaded');
	$('.notLoaded').append('<div id="loader"><div><img class="loaderImage" src="../../assets/images/1488.gif"></div></div>');
	//console.log("ff")
}

function hideLoader() {
	$('body').removeClass('notLoaded');
	$('#loader').delay(600).fadeOut('slow', function () {
		$('.notLoaded').removeClass('notLoaded');
		$('body').find('div').remove('#loader');
		//console.log("ffsss")
	});
}







// $(function () {

//     var contibution = 110000;
//     var persent = 10;
//     var year = 2044;

//     i18next
//         .use(i18nextBrowserLanguageDetector)
//         .init({
//             debug: true,
//             fallbackLng: 'en',
//             resources: {
//                 en: {
//                     translation: {
//                         firstPage: {
//                             title: 'NPS Prosperity Planner',
//                             titleDesc: `Invest for your retirement & Save in taxes every year.`,
//                             cardTitle_1: "My Pension preparedness",
//                             cardSubTitle_1: "How ready am I ?",
//                             cardTitle_2: "My Pension Requirement",
//                             cardSubTitle_2: "How much do I need ?",
//                             cardTitle_3: "Recommended Action Steps",
//                             cardSubTitle_3: "What should I do ?",
//                             know_more: "Know More",
//                             start: "Start"
//                         },

//                         secondPage: {
//                             title: 'I am a',
//                             cardTitle_1: "Central Government",
//                             cardTitle_2: "State Government Employee",
//                             cardTitle_3: "All Citizen of India",
//                             cardTitle_4: "Corporate Sector Employee",
//                             title_2: "My grade is",
//                             gradeA: "Grade A",
//                             gradeB: "Grade B",
//                             gradeC: "Grade C",
//                             gradeD: "Grade D",
//                             start: "next"
//                         },

//                         thirdPage: {
//                             title: 'NPS Account Details',
//                             bodyText_1: "I have started my NPS account in",
//                             bodyText_2: "My average annual contribution is Rs",
//                             bodyText_3: "Based on the above data, my current NPS balance is",
//                             start: "next"
//                         },

//                         stepperHeader: {
//                             title_1: 'How ready am I ?',
//                             title_2: "How much do I need ?",
//                             title_3: "What should I do ?"
//                         },

//                         stepperFirstPage: {
//                             heading: `If I continue to contribute ₹ ${contibution} with ${persent}% increase in contribution every year Upto Retirement i.e. Year ${year}`,
//                             chartTitle_1: 'NPS at Maturity (in Rs cr)',
//                             chartTitle_2: "Monthly Pension Requirement",
//                             bodyText_1: "But , is your monthly pension going to be enough for you ?",
//                             check: "Check Now"
//                         },

//                         stepperSecondPage: {
//                             title_1: 'I don’t know my pension requirement',
//                             check: "Calculate Now",
//                         },

//                         testPage: {
//                             title_1: "My monthly living expenses in current cost is Rs",
//                             title_2: "I expect the rate of inflation to be"
//                         }

//                     }
//                 },
//                 hi: {
//                     translation: {
//                         firstPage: {
//                             title: "एनपीएस समृद्धि योजनाकार",
//                             titleDesc: "अपनी सेवानिवृत्ति के लिए निवेश करें और हर साल करों में बचत करें।",
//                             cardTitle_1: "मेरी पेंशन की तैयारी",
//                             cardSubTitle_1: "मैं कितना तैयार हूँ ?",
//                             cardTitle_2: "मेरी पेंशन आवश्यकता",
//                             cardSubTitle_2: "मुझे कितनी आवश्यकता है ?",
//                             cardTitle_3: "अनुशंसित कार्रवाई कदम",
//                             cardSubTitle_3: "मुझे क्या करना चाहिए ?",
//                             know_more: "ज्यादा जानें",
//                             start: "प्रारंभ"
//                         },

//                         secondPage: {
//                             title: 'मैं एक हूँ',
//                             cardTitle_1: "केन्द्रीय सरकार कर्मचारी",
//                             cardTitle_2: "राज्य सरकार कर्मचारी",
//                             cardTitle_3: "भारत के सभी नागरिक",
//                             cardTitle_4: "कॉर्पोरेट क्षेत्र के कर्मचारी",
//                             title_2: "मेरा ग्रेड है",
//                             gradeA: "ग्रेड ए",
//                             gradeB: "ग्रेड बी",
//                             gradeC: "ग्रेड सी",
//                             gradeD: "ग्रेड डी",
//                             next: "अगला"
//                         },

//                         thirdPage: {
//                             title: 'एनपीएस खाता विवरण',
//                             bodyText_1: "मैंने अपना एनपीएस खाता में शुरू किया है",
//                             bodyText_2: "मेरा औसत वार्षिक योगदान रु",
//                             bodyText_3: "मेरा औसत वार्षिक योगदान रु",
//                             start: "अगला"
//                         },

//                         stepperHeader: {
//                             title_1: 'मैं कितना तैयार हूँ ?',
//                             title_2: "मुझे कितनी आवश्यकता है ?",
//                             title_3: "मुझे क्या करना चाहिए ?"
//                         },

//                         stepperFirstPage: {
//                             heading: `अगर मैं योगदान देना जारी रखता हूं ₹ ${contibution} साथ ${persent}% हर साल सेवानिवृत्ति तक यानी साल में योगदान में वृद्धि ${year}`,
//                             chartTitle_1: 'परिपक्वता पर एनपीएस (करोड़ रुपये में)',
//                             chartTitle_2: "मासिक पेंशन आवश्यकता",
//                             bodyText_1: "लेकिन, क्या आपकी मासिक पेंशन आपके लिए पर्याप्त होगी ?",
//                             check: "अब जांचें"
//                         },

//                         stepperSecondPage: {
//                             title_1: 'मुझे अपनी पेंशन आवश्यकता का पता नहीं है',
//                             check: "अभी गणना करें",
//                         },

//                         testPage: {
//                             title_1: "वर्तमान लागत में मेरा मासिक रहने का खर्च रु है",
//                             title_2: "मुझे उम्मीद है कि मुद्रास्फीति की दर होगी"
//                         }

//                     }
//                 }
//             }
//         }, (err, t) => {
//             if (err) return console.error(err);
//             jqueryI18next.init(i18next, $, {
//                 useOptionsAttr: true
//             });

//             // fill language switcher
//             Object.keys(lngs).map((lng) => {
//                 const opt = new Option(lngs[lng].nativeName, lng);
//                 if (lng === i18next.resolvedLanguage) {
//                     opt.setAttribute("selected", "selected");
//                 }
//                 $('#languageSwitcher').append(opt);
//             });
//             $('#languageSwitcher').change((a, b, c) => {
//                 const chosenLng = $(this).find("option:selected").attr('value');
//                 i18next.changeLanguage(chosenLng, () => {
//                     rerender();
//                 });
//             });

//             rerender();
//         });
// });