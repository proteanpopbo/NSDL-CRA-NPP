google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['Year', ''],
          ['2013',  0],
          ['2014',  270],
          ['2015',  400],
          ['2016',  630],
          ['2017',  930],
          ['2018',  1030],
          ['2019',  1530],
          ['2020',  1830],
          ['2021',  3000]
        ]);
        
        var options = {
          colors: ['#3192D0','#F07E26', '#FFCD1C'],
          backgroundColor: { fill: "#F4F4F4" },
          legend: 'none',
          title: '',
          hAxis: {title: '',  titleTextStyle: {color: '#333',}},
          vAxis: {
            vAxis: {minValue: 0},
              gridlines: {
                  interval: 0,
                  // color: 'transparent'
              }
          },
          
        };

        var chart = new google.visualization.AreaChart(document.getElementById('chart_div'));
        chart.draw(data, options);
      }

      // function x(){
      //   $('#idStepperBody').empty();
      //   $('#idSecondCircle').removeClass('active');
      //   $('#idSecondTitle').removeClass('active');
      //   $('#idThirdCircle').addClass('active');
      //   $('#idThirdTitle').addClass('active');
      //   $('#idStepperBody').load('what_should_I_do.html');
      // }

      function x(){
       window.location.href = "../pages/whatShouldiDo.html";
      }