$("#div1").hide();
$("#div2").hide();
showLoader();

var rupeeSign = '<i class="fa-solid fa-indian-rupee-sign"></i>';
var employeeData = JSON.parse(sessionStorage.getItem('employeeData'));
var currentNpsCorpus = JSON.parse(sessionStorage.getItem('currentNpsCorpus'));



$(document).ready(function () {

  showLoader();
  // Pension Calculation text value population
  var employeeData = JSON.parse(sessionStorage.getItem('employeeData'));
  var currentNpsCorpus = JSON.parse(sessionStorage.getItem('currentNpsCorpus'));
  var monthlyPensionObj = JSON.parse(sessionStorage.getItem('monthlyPension'));
  var currentContrtibutionLan = (Number(currentNpsCorpus.yearlyContribution).toLocaleString('en-IN', {
    maximumFractionDigits: 0,
    // style: 'currency',
    currency: 'INR'
  }));
  //console.log("Hide button logic",currentNpsCorpus.remainingRetirementYear)


  var slider = new Slider("#range-slider", {
    tooltip: 'always',
    tooltip_position: 'bottom',
    formatter: function (value) {
      return value + ' %';
    }
  });

  var slider2 = new Slider("#range-slider2", {
    tooltip: 'always',
    tooltip_position: 'bottom',
    formatter: function (value) {
      return value + '%';
    }
  });

  $("#div1").show();
  $("#div2").show();

  if (monthlyPensionObj != null) {
    //Slider code 
    //console.log("first", monthlyPensionObj.periodicRoi)

    slider.setValue(String(monthlyPensionObj.periodicRoi));
    slider2.setValue(String(monthlyPensionObj.annuityPer));
    // $('#range-slider').attr("value","15"); 
    // $('#range-slider').attr("data-slider-value","15");
    // $('#range-slider').attr("data-value","15"); 

  } else {
    slider.setValue("10");
    slider2.setValue("100");
  }

  $('#range-slider').change(function () {
    var x = $('#range-slider').val();
    if (x == 0) {
      $('.c-range-slider__label--min').hide();
    } else {
      $('.c-range-slider__label--min').show();
    }
    if (x == 20) {
      $('.c-range-slider__label--max').hide();
    } else {
      $('.c-range-slider__label--max').show();
    }
  })

  function minMaxShow() {
    var x = $('#range-slider').val();
    if (x == 0) {
      $('.c-range-slider__label--min').hide();
    } else {
      $('.c-range-slider__label--min').show();
    }
    if (x == 20) {
      $('.c-range-slider__label--max').hide();
    } else {
      $('.c-range-slider__label--max').show();
    }
  }


  $('#range-slider2').change(function () {
    var x = $('#range-slider2').val();
    if (x == 40) {
      $('.c-range-slider__label--min2').hide();
    } else {
      $('.c-range-slider__label--min2').show();
    }
    if (x == 100) {
      $('.c-range-slider__label--max2').hide();
    } else {
      $('.c-range-slider__label--max2').show();
    }
  })

  function minMaxShow2() {
    var x = $('#range-slider2').val();
    if (x == 40) {
      $('.c-range-slider__label--min2').hide();
    } else {
      $('.c-range-slider__label--min2').show();
    }
    if (x == 100) {
      $('.c-range-slider__label--max2').hide();
    } else {
      $('.c-range-slider__label--max2').show();
    }
  }
  if (Number(currentNpsCorpus.remainingRetirementYear) < 1) {
    $('#submmit_btn').hide();
    $('#submmit_div').hide();
    $('#header_div').hide();

    //Hide button logic
    //console.log("Hide button logic")
  }

  // $('#idPeriodicRoi').text(employeeData.periodicRoi);
  // var onlyYear = currentNpsCorpus.retirementYearOnly;

  setTimeout(() => {
    //$('#idContibutionAmount').html(i18next.t("NSDL_NPP_LAN_33" , {value})); 
    // $('#idCurrentContribution').html(i18next.t('NSDL_NPP_LAN_40', {
    //   value: i18next.format(currentContrtibutionLan, 'uppercase'),
    //   value2: i18next.format(employeeData.periodicRoi, 'uppercase'),
    //   value3: i18next.format(currentNpsCorpus.retirementYearOnly, 'uppercase'),
    //   value4: i18next.format(currentContrtibutionLan, 'uppercase')
    // }));

    $('#monthlyPensionOnwards').html(i18next.t('NSDL_NPP_LAN_48', {
      value: i18next.format(currentNpsCorpus.retirementYearOnly, 'uppercase')
    }));

  }, 700);

  setTimeout(() => {
    $('#jlifeROP').html(i18next.t('NSDL_NPP_LAN_126', {
      escapeInterpolation: true
    }));
    $('#jlifewROP').html(i18next.t('NSDL_NPP_LAN_127', {
      escapeInterpolation: true
    }));
  }, 800);

  // setTimeout(() => {
  //   $('#monthlyPensionOnwards').html(i18next.t('NSDL_NPP_LAN_48', { value: i18next.format(currentContrtibutionLan, 'uppercase')})); 

  // }, 700);

  // Lumpsum Corpus / Annuity Corpus Value population
  var employeeData = JSON.parse(sessionStorage.getItem('employeeData'));
  $('#idLumpsumCorpus').text(employeeData.lumpSumPercentageRate + ' %');
  $('#idAnnuityCorpus').text(employeeData.annuityPercentageRate + ' %');

  //  NPS corpus details Population
  var empid = JSON.parse(sessionStorage.getItem('externalApiRespons')).empId;

  var pensionData = sessionStorage.getItem('monthlyPension');
  var pensionObj = JSON.parse(pensionData);




  // console.log('test gggggg ' + pensionObj.periodicRoi);




  var requireData = {
    "empGrade": employeeData.grade,
    "empId": Number(empid),
    "empolyeeDod": (currentNpsCorpus.dateOfBirth).toString(),
    "empolyeeDoj": (currentNpsCorpus.dateOfJoining).toString(),
    "empolyeeDor": (currentNpsCorpus.dateOfRetirement).toString(),
    "periodicDeposit": Number(currentNpsCorpus.yearlyContribution),
    "periodicRoi": (pensionObj == null ? Number(10) : pensionObj.periodicRoi),
    "lumpsumPer": (pensionObj == null ? Number(100 - Number(document.getElementById('range-slider2').value)) : pensionObj.lumpsumPer),
    "annuityPer": (pensionObj == null ? Number(document.getElementById('range-slider2').value) : pensionObj.annuityPer),
  }

  var myData = JSON.stringify(requireData);

  // showLoader();
  nppApiRequest('POST', myData, 'api/calculator/getMonthlyPension', onNpsCorpus);

  function onNpsCorpus(data) {
    if (data == 'null') {
      hideLoader();

      alert('Data Not Found');
    } else {
      var charHeadingAmount = (((data.npsCorpus) / 10000000).toLocaleString('en-IN', {
        maximumFractionDigits: 2,
        // style: 'currency',
        currency: 'INR'
      }));

      // setTimeout(() => {
      //   $('#paiHeading').html(i18next.t('NSDL_NPP_LAN_113', {
      //     value: i18next.format(charHeadingAmount, 'uppercase')
      //   }));
      // }, 700);

      $('#corpusRetirement').html(rupeeSign + " " + charHeadingAmount + ' cr');

      $('#idWithRopValue').text(data.monthlyPensionWithRop.toLocaleString('en-IN', {
        maximumFractionDigits: 0,
        // style: 'currency',
        currency: 'INR'
      }));

      $('#idWithOutRopValue').text(data.monthlyPensionWithOutRop.toLocaleString('en-IN', {
        maximumFractionDigits: 0,
        // style: 'currency',
        currency: 'INR'
      }));

      var oldPensionObj = {
        "periodicRoi": Number(10),
        "lumpsumPer": Number(Number(100 - Number(document.getElementById('range-slider2').value))),
        "annuityPer": Number(Number(document.getElementById('range-slider2').value)),
        "oldPensionWithOutRop": Number(data.monthlyPensionWithOutRop),
        "oldPensionWithRop": Number(data.monthlyPensionWithRop)
      }

      var stringObj = JSON.stringify(oldPensionObj);
      sessionStorage.setItem('monthlyPension', stringObj);

      paichartDraw(data.annuityCorpus, data.lumpSumCorpus, Number(10));

      var projectedContribution = (Number(data.projectedContribution / 10000000).toLocaleString('en-IN', {
        maximumFractionDigits: 2,
        // style: 'currency',
        currency: 'INR'
      }));

      setTimeout(() => {
        //$('#idContibutionAmount').html(i18next.t("NSDL_NPP_LAN_33" , {value})); 
        $('#idCurrentContribution').html(i18next.t('NSDL_NPP_LAN_40', {
          value: i18next.format(rupeeSign + " " + currentContrtibutionLan, 'uppercase'),
          value2: i18next.format(employeeData.periodicRoi, 'uppercase'),
          value3: i18next.format(currentNpsCorpus.retirementYearOnly, 'uppercase'),
          value4: i18next.format(projectedContribution, 'uppercase')
        }));

      }, 400);


      $('#projectedContribution').html(rupeeSign + " " + projectedContribution + ' cr');

      // hideLoader();

    }
  }

  minMaxShow();
  minMaxShow2();

  hideLoader();

})




function contributionToHowready() {
  // window.location.href = '../pages/howMuchDoiNeed.html';
  window.location.href = '../pages/dontKnow.html';
}

//   Chart
function paichartDraw(annuity, lumpsum) {
  google.charts.load("current", {
    packages: ["corechart"]
  });
  google.charts.setOnLoadCallback(drawChart);
  var x = (lumpsum / 10000000);
  var y = (annuity / 10000000);

  // (x).toLocaleString('en-IN', {
  //   maximumFractionDigits: 0,
  //   style: 'currency',
  //   currency: 'INR'
  // })
  // (y).toLocaleString('en-IN', {
  //   maximumFractionDigits: 0,
  //   style: 'currency',
  //   currency: 'INR'
  // })




  function drawChart() {
    setTimeout(() => {

      var data = google.visualization.arrayToDataTable([
        ['Task', 'Hours per Day'],
        [i18next.t('NSDL_NPP_LAN_47'), x],
        [i18next.t('NSDL_NPP_LAN_46'), y],

        // i18next.t('Annuity Corpussssssssss')

        //   [`Annuity Corpus ${x.toLocaleString('en-IN', {
        //           maximumFractionDigits: 0,
        //           style: 'currency',
        //           currency: 'INR'
        //         })}`, x],
        //   [`Lumpsum Corpus ${y.toLocaleString('en-IN', {
        //           maximumFractionDigits: 0,
        //           style: 'currency',
        //           currency: 'INR'
        //         })}`, y],
      ]);

      var formatter = new google.visualization.NumberFormat({
        negativeColor: 'red',
        negativeParens: true,
        pattern: '₹#,##,##,##,###0.00 cr'
      });
      formatter.format(data, 1);

      var options = {
        // enableInteractivity: false,
        backgroundColor: {
          fill: "#FFF"
        },
        colors: ['#F58232', '#F9CF7D'],
        title: '',
        // height: 360,
        // width: 360,
        pieHole: 0,
        showLables: 'true',
        pieSliceText: 'value',
        pieSliceText: 'percentage',
        pieSliceTextStyle: {
          color: 'black',
          fontSize: 14,
          bold: true
        },
        legend: {
          labeledValueText: 'both',
          // labeledValueText: 'percentage',
          position: "right",
          alignment: 'center',
          textStyle: {
            color: 'black',
            fontSize: 13,
            bold: true,
          }
        },
        // bold: true,
        // fontSize: 2,

        tooltip: {
          text: "both",
          // text: 'percentage',
          trigger: true,
          // trigger: 'selection',
        },
        chartArea: {
          left: "0",
          right: "20",
          top: 20,
          // width: '100%', 
          // height: '65%'
        },
        pieSliceText: 'value',
        pieStartAngle: 100,
        isStacked: true,
        is3D: true,
      };

      var chart = new google.visualization.PieChart(document.getElementById('donutchart'));
      chart.draw(data, options);

    }, 700);


  }
}
showLoader();

let back = () => {
  window.location.href = '../pages/contribution.html';
  // window.history.back();
  //window.history.go(-1);
}


function calculate() {
  var empid = JSON.parse(sessionStorage.getItem('externalApiRespons')).empId;
  var contribution = document.getElementById('range-slider').value;
  var annuity = document.getElementById('range-slider2').value;

  var requireData = {
    "empGrade": employeeData.grade,
    "empId": Number(empid),
    "empolyeeDod": (currentNpsCorpus.dateOfBirth).toString(),
    "empolyeeDoj": (currentNpsCorpus.dateOfJoining).toString(),
    "empolyeeDor": (currentNpsCorpus.dateOfRetirement).toString(),
    "periodicDeposit": Number(currentNpsCorpus.yearlyContribution),
    "lumpsumPer": (100 - Number(annuity)),
    "annuityPer": Number(annuity),
    "periodicRoi": Number(contribution)

  }

  // contribution

  // console.log('sssss' + requireData);
  var myData = JSON.stringify(requireData);

  // console.log('sssss' + myData);

  nppApiRequest('POST', myData, 'api/calculator/getMonthlyPension', onNpsCorpus);

  function onNpsCorpus(data) {
    //console.log("kkkkkkkkkkk"+data);

    var oldPensionObj = {
      "lumpsumPer": (100 - Number(annuity)),
      "annuityPer": Number(annuity),
      "periodicRoi": Number(contribution),
      "oldPensionWithOutRop": Number(data.monthlyPensionWithOutRop),
      "oldPensionWithRop": Number(data.monthlyPensionWithRop)
    }

    var stringObj = JSON.stringify(oldPensionObj);
    sessionStorage.setItem('monthlyPension', stringObj);

    var projectedContribution = (Number(data.projectedContribution / 10000000).toLocaleString('en-IN', {
      maximumFractionDigits: 2,
      // style: 'currency',
      currency: 'INR'
    }));
    $('#projectedContribution').html(rupeeSign + " " + projectedContribution + ' cr');


    var charHeadingAmount = (((data.npsCorpus) / 10000000).toLocaleString('en-IN', {
      maximumFractionDigits: 2,
      // style: 'currency',
      currency: 'INR'
    }));
    $('#corpusRetirement').html(rupeeSign + " " + charHeadingAmount + ' cr');

    $('#idWithRopValue').text(data.monthlyPensionWithRop.toLocaleString('en-IN', {
      maximumFractionDigits: 0,
      // style: 'currency',
      currency: 'INR'
    }));

    $('#idWithOutRopValue').text(data.monthlyPensionWithOutRop.toLocaleString('en-IN', {
      maximumFractionDigits: 0,
      // style: 'currency',
      currency: 'INR'
    }));

    paichartDraw(data.annuityCorpus, data.lumpSumCorpus);

  }
}

