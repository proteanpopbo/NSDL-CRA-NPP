showLoader();
$(document).ready(function () {
  sessionStorage.clear();
  $('input[type="radio"]:checked').prop('checked', false);

  // $('#idStateGovernment').prop('checked', false);
  // $('#idCitizen').prop('checked', false);
  // $('#idCorporateEmployee').prop('checked', false);
  // $('#idGradeA').prop('checked', false);
  // $('#idGradeB').prop('checked', false);
  // $('#idGradeC').prop('checked', false);
  // $('#idGradeD').prop('checked', false);

  $('.government').change(function () {
    $('.grade-input-element').prop('checked',false);
    if ((this.value) == '1' || (this.value) == '2') {
      $('#idCentralGrade').show();
      // $('#idGradeA').prop('checked',true);
    } else {
      $('#idCentralGrade').hide();
      $('.button_area').css('margin-top', '0');
      $('.grade-input-element').prop('checked', false);
    }
    console.log(this.value);
  })
  $('#idCentralGrade').hide();
})
hideLoader();


function selectProfile() {
  var validateProfile = $('input[name="profile"]:checked');
  var validateGrade = $('input[name="grade"]:checked');
  var selectedCategory = $('input[name="profile"]:checked').val();
  var selectedGrade = $('input[name="grade"]:checked').val();


  var isValid;

  if (selectedCategory == '1' || selectedCategory == '2') {
    if (validateProfile.length == 0 || validateGrade.length == 0) {
        swal({
          title: i18next.t('NSDL_NPP_LAN_82'),
          button: i18next.t('NSDL_NPP_LAN_87')
        });   
      isValid = false;
    } else {
      isValid = true;
    }
  }

  if (selectedCategory == '3' || selectedCategory == '4') {
    if (validateProfile.length == 0) {
      swal({
        title: i18next.t('NSDL_NPP_LAN_11'),
        button: i18next.t('NSDL_NPP_LAN_87')
      });
      isValid = false;
    } else {
      isValid = true;
    }
  }

  if (validateProfile.length == 0) {
    // swal(
    //     {title: i18next.t('NSDL_NPP_LAN_11')} //Category
    //     ); 

    swal({
        title: i18next.t('NSDL_NPP_LAN_11'),
        button: i18next.t('NSDL_NPP_LAN_87')
      });

    isValid = false;
  }

  console.log('isValid = ' + isValid);

  // console.log('category  ' + selectedCategory, 'grade  ' + selectedGrade);

  if (isValid) {
    showLoader(); 
    nppApiRequest('GET', '', 'api/masters/getEmployeeContributionMst/' + selectedCategory + '/' + selectedGrade, onSelectProfile);

    function onSelectProfile(data) {
      if (data == 'null') {
        hideLoader();
        alert('Invalid Selection')
      } else {
        sessionStorage.setItem('employeeData', JSON.stringify(data));
        sessionStorage.setItem('employeeId', selectedCategory);
        window.location.href = '../pages/contribution.html';
        hideLoader();
      }
    }
  }
}

let back = () => {
  window.location.href = '../../index.html';
  // window.history.back();
  // window.history.go(-1)
}