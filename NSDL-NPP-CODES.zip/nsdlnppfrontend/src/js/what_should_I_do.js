
showLoader();
var externalApiRespons = JSON.parse(sessionStorage.getItem('externalApiRespons'));
var pranNo = externalApiRespons.pran;

console.log("pran  "+externalApiRespons.pran)


var content1;
var content2;
var lanValue = localStorage.getItem('i18nextLng');
// showLoader();
$('.pension_left_section').hide();
$('.pension_status').hide();
$('.projected_main').hide();
// showLoader();

if (lanValue == "en" || lanValue == "en-IN" || lanValue == "en-US") {
  $('#idGrapgImg').prop('src', '../../assets/images/second.png');
} else if (lanValue == "hi") {
  $('#idGrapgImg').prop('src', '../../assets/images/second_hindi.png');
}

// Unblock
var rupeeSign = '<i class="fa-solid fa-indian-rupee-sign rupee_icons"></i>';

var npsCorpus = JSON.parse(sessionStorage.getItem('currentNpsCorpus'));
var employeeData = JSON.parse(sessionStorage.getItem('employeeData'));
var pension = JSON.parse(sessionStorage.getItem('monthlyPension'));
// var employeeId = sessionStorage.getItem('employeeId');
var employeeId = JSON.parse(sessionStorage.getItem('externalApiRespons')).empId;
var clientRequiredPension = sessionStorage.getItem('clientInputPension');
var checkBoxValue = 'withRop';

$('.radio_btn').click(function () {
  checkBoxValue = this.value;
})


$(document).ready(function () {
  // showLoader();
  // console.log('Current NPS Corpus From Session Storage ' + npsCorpus);
  // console.log('Employee Data From Session Storage ' + employeeData.grade);
  // console.log('Employee ID From Session Storage ' + employeeId);
  // console.log('Client Required Pension From Session Storage ' + clientRequiredPension);

  // Unblock
  var newPensionRequirmentObj = JSON.parse(sessionStorage.getItem('newPensionRequirmentObj'));
  var monthlyPensionObj = JSON.parse(sessionStorage.getItem('monthlyPension'));
  // Change Annuity Range Slider Start here

  var slider = new Slider("#range-slider", {
    tooltip: 'always',
    tooltip_position: 'bottom',
    formatter: function (value) {
      return value + '%';
    }
  });

  $('.pension_left_section').show();
  $('.pension_status').show();
  $('.projected_main').show();


  if (newPensionRequirmentObj != null) {
    //Slider code 
    //console.log("first", monthlyPensionObj.periodicRoi)

    slider.setValue(String(newPensionRequirmentObj.annuity));


  } else {
    slider.setValue(monthlyPensionObj.annuityPer);
  }



  $('#range-slider').change(function () {
    var x = $('#range-slider').val();
    if (x == 40) {
      $('.c-range-slider__label--min').hide();
    } else {
      $('.c-range-slider__label--min').show();
    }
    if (x == 100) {
      $('.c-range-slider__label--max').hide();
    } else {
      $('.c-range-slider__label--max').show();
    }
  })

  function minMaxShow() {
    var x = $('#range-slider').val();
    if (x == 40) {
      $('.c-range-slider__label--min').hide();
    } else {
      $('.c-range-slider__label--min').show();
    }
    if (x == 100) {
      $('.c-range-slider__label--max').hide();
    } else {
      $('.c-range-slider__label--max').show();
    }
  }
  //Change Annuity Range Slider End here

  $('#idPension').val(clientRequiredPension);

  // showLoader();

  getAnnualContribution();
  // hideLoader();
  setTimeout(() => {
    $('#yearView').html(i18next.t('NSDL_NPP_LAN_121', {
      value: i18next.format(npsCorpus.retirementYearOnly, 'uppercase')
    }));

    if (checkBoxValue == "withRop" && (lanValue == "en" || lanValue == "en-IN" || lanValue == "en-US")) {
      content1 = "(Joint life with ROP)"
    } else if (checkBoxValue == "withRop" && lanValue == "hi") {
      content1 = "( संयुक्त जीवन के साथ आर.ओ.पी. )"
    } else if (checkBoxValue == "withOutRop" && (lanValue == "en" || lanValue == "en-IN" || lanValue == "en-US")) {
      content1 = "(Joint life without ROP)"
    } else if (checkBoxValue == "withOutRop" && lanValue == "hi") {
      content1 = "( संयुक्त जीवन आर.ओ.पी. के बिना )"
    }

    $('#chartPensionCurrentContribution').html(i18next.t('NSDL_NPP_LAN_73', {
      value: i18next.format(npsCorpus.retirementYearOnly, 'uppercase'),
      value2: i18next.format(content1, 'uppercase')
    }));


  }, 800);


})






function getAnnualContribution() {
  showLoader();
  let modifyedPensionAmount = document.getElementById('idPension').value;
  let modifyedAnnuityPersent = document.getElementById('range-slider').value;

  // $('#contibutionPersent').text(employeeData.periodicRoi + '%');


  setTimeout(() => {
    $('#contibutionPersent').html(i18next.t('NSDL_NPP_LAN_64', {
      value: i18next.format(employeeData.periodicRoi, 'uppercase')
    }));

    $('#annuityCriteria').html(i18next.t('NSDL_NPP_LAN_66', {
      value: i18next.format(employeeData.annuityRopRate, 'uppercase')
    }));

    $('#annuityStatus2').html(i18next.t('NSDL_NPP_LAN_67', {
      value: i18next.format(employeeData.annuityWithoutRopRate, 'uppercase')
    }));

  }, 700);


  // $('#jlwrop').text(employeeData.annuityRopRate + '%');
  // $('#jlworop').text(employeeData.annuityWithoutRopRate + '%')
  var num = parseFloat(modifyedPensionAmount.replace(/,/g, ''));
  let objBody = {
    "annuityPersent": Number(modifyedAnnuityPersent),
    "empGrade": employeeData.grade,
    "empId": Number(employeeId),
    "empolyeeDob": npsCorpus.dateOfBirth,
    "empolyeeDoj": npsCorpus.dateOfJoining,
    "empolyeeDor": npsCorpus.dateOfRetirement,
    "monthlyPension": num,
    "periodicRoi": pension.periodicRoi,
    "periodicDeposit": Number(npsCorpus.yearlyContribution)
  }
  let postData = JSON.stringify(objBody);

  nppApiRequest('POST', postData, 'api/calculator/getAnnualContributionV2', onGetAnnualContribution);

  function onGetAnnualContribution(data) {
    // console.log(data);
    // console.log('New API Request ' + postData)
    if (data == 'null') {
      alert('Data Not Found')
    } else {

      let annuityCorpus = data.annuityCorpus;
      let lumpSumCorpus = data.lumpsumCorpus
      // console.log(data.currentNpsCorpus);

      var corpusRetirementValue = (((data.currentNpsCorpus) / 10000000).toLocaleString('en-IN', {
        maximumFractionDigits: 2,
        // style: 'currency',
        currency: 'INR'
      }))

      var currentContribution = npsCorpus.yearlyContribution;
      //console.log("gggggggggggg"+currentContribution)
      var currentContributionString = (((currentContribution)).toLocaleString('en-IN', {
        maximumFractionDigits: 0,
        // style: 'currency',
        currency: 'INR'
      }))

      $('#idAcceleratedYearlyContribution').html(rupeeSign + " " + corpusRetirementValue + " cr");

      $('#contribution').html(currentContributionString)


      // $('#chartPensionCurrentContribution').html(i18next.t('NSDL_NPP_LAN_122', {
      //   value: i18next.format(corpusRetirementValue, 'uppercase')
      // }));


      // console.log(checkBoxValue)
      // drawPieChart(annuityCorpus, lumpSumCorpus);

      var pensionWithRop = data.pensionWithRop;
      var pensionWithOutRop = data.pensionWithOutRop;
      var oldPensionWithRop = pension.oldPensionWithRop;
      var oldPensionWithOutRop = pension.oldPensionWithOutRop;

      if (checkBoxValue == 'withRop') {
        drawColumnChart(oldPensionWithRop, pensionWithRop);
        // console.log("first")
      } else if (checkBoxValue == 'withOutRop') {
        drawColumnChart(oldPensionWithOutRop, pensionWithOutRop);
        // console.log('second')
      }

      
      if (checkBoxValue == "withRop" && (lanValue == "en" || lanValue == "en-IN" || lanValue == "en-US")) {
        content2 = "(Joint life with ROP)";
      }
      else if (checkBoxValue == "withRop" && lanValue == "hi") {
        content2 = "( संयुक्त जीवन के साथ आर.ओ.पी. )";
      } 
      else if (checkBoxValue == "withOutRop" && (lanValue == "en" || lanValue == "en-IN" || lanValue == "en-US")) {
        content2 = "(Joint life without ROP)";
      } 
      else if (checkBoxValue == "withOutRop" && lanValue == "hi") {
        content2 = "( संयुक्त जीवन आर.ओ.पी. के बिना )";
      }

      $('#chartPensionCurrentContribution').html(i18next.t('NSDL_NPP_LAN_73', {
        value: i18next.format(npsCorpus.retirementYearOnly, 'uppercase'),
        value2: i18next.format(content2, 'uppercase')
      }));


      // drawNewColumnChart(pensionWithRop, pensionWithOutRop, oldPensionWithRop, oldPensionWithOutRop)

      var acceleratedContribution = (((data.newAnnualContribution)).toLocaleString('en-IN', {
        maximumFractionDigits: 0,
        // style: 'currency',
        currency: 'INR'
      }));

      // console.log("test "+acceleratedContribution);

      $('#acceleratedContribution').html(acceleratedContribution)
      $('#idMonthlyPensionNeeded').text(data.newPension.toLocaleString('en-IN', {
        maximumFractionDigits: 0,
        style: 'currency',
        currency: 'INR'
      }));
      $('#idMonthlyAnnuityWithRop').text(data.pensionWithRop.toLocaleString('en-IN', {
        maximumFractionDigits: 0,
        style: 'currency',
        currency: 'INR'
      }));
      $('#idMonthlyAnnuityWithoutRop').text(data.pensionWithOutRop.toLocaleString('en-IN', {
        maximumFractionDigits: 0,
        style: 'currency',
        currency: 'INR'
      }));
    }
  }

  var pensionObj = {
    "annuity": modifyedAnnuityPersent,
  }

  var pensionJson = JSON.stringify(pensionObj);
  sessionStorage.setItem('newPensionRequirmentObj', pensionJson);

  hideLoader();
}

// Incriment / Decrement
const incriment = (number) => {
  if (isNaN(number)) {
    number = 0;
  }
  //console.log('number',number)
  var x = parseInt(number) + 1000;
  var stringValue = x.toLocaleString('en-IN', {
    maximumFractionDigits: 0,
    currency: 'INR'
  });
  return stringValue;
}

const decrement = (number) => {
  if (isNaN(number)) {
    number = 0;
  }
  var x = parseInt(number) - 1000;
  var stringValue = x.toLocaleString('en-IN', {
    maximumFractionDigits: 0,
    currency: 'INR'
  });
  return stringValue;
  //return number > 1000 ? number - 1000 : number;
}


let plusButton = document.getElementById('idPensionPlus');
let minusButton = document.getElementById('idPensionMinus');
const incrimentAnnuity = (number) => {
  return number < 100 ? number + 1 : number;
}

const decrementAnnuity = (number) => {
  return number > 40 ? number - 1 : number;
}

let balancePlusButton = document.getElementById('idAnnuityMinus');

let balanceMinusButton = document.getElementById('idAnnuityPlus');

function format(input) {
  var x = input.value;
  x = x.toString();
  var lastThree = x.substring(x.length - 3);
  var otherNumbers = x.substring(0, x.length - 3);
  if (otherNumbers != '')
    lastThree = ',' + lastThree;
  var res = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ",") + lastThree;

  input.value = res;
}

// Draw Column Chart
function drawColumnChart(currentPension, requiredPensio) {
  google.load('visualization', '1', {
    packages: ['corechart', 'bar']
  });

  google.charts.setOnLoadCallback(drawChartt);

  function drawChartt() {
    var formatter = new google.visualization.NumberFormat({
      prefix: '<del>&#2352;</del>'
    });
    var data = google.visualization.arrayToDataTable([
      ['Year', i18next.t('NSDL_NPP_LAN_115'), i18next.t('NSDL_NPP_LAN_116')],
      [i18next.t(''), currentPension, requiredPensio],
      // [i18next.t('NSDL_NPP_LAN_99'), oldPensionWithRop, oldPensionWithOutRop],
    ]);

    // i18next.t('NSDL_NPP_LAN_47')

    var formatter = new google.visualization.NumberFormat({
      negativeColor: 'red',
      negativeParens: true,
      pattern: '₹#,##,##,##,###'
    });
    formatter.format(data, 1);
    var formatter = new google.visualization.NumberFormat({
      negativeColor: 'red',
      negativeParens: true,
      pattern: '₹#,##,##,##,###'
    });
    formatter.format(data, 2);

    var view = new google.visualization.DataView(data);
    view.setColumns([0, 1,
      {
        calc: "stringify",
        sourceColumn: 1,
        type: "string",
        role: "annotation"
      },
      2,
      {
        calc: "stringify",
        sourceColumn: 2,
        type: "string",
        role: "annotation"
      },
    ]);

    var options = {
      bar: {
        groupWidth: '30%'
      },
      legend: {
        position: "none"
      },
      // bar: {groupWidth: '80%'},
      backgroundColor: {
        fill: "#fff"
      },
      colors: ['#EFA26D', '#FEB526'],
      legend: {
        labeledValueText: 'both',
        position: "bottom",
        alignment: 'center',
        textStyle: {
          color: 'black',
          // fontSize: 12,
          bold: true,
        }
      },
      chartArea: {
        left: 20,
        right: 20,
        top: 20,
        // width: '100%', 
        // height: '65%'
      },
      vAxis: {
        minValue: 0,
        textPosition: 'none',
        title: '',
        ticks: [0, .3, .6, .9, 1],
        baselineColor: '#fff',
        gridlineColor: '#fff',

        // maxValue: 100,
        // minValue: -100,
        gridlines: {
          count: 0
        },
        gridlines: {
          count: 0,
          color: 'transparent',
          textPosition: 'none'
        }
      },

      // hAxis: {slantedText: true},
      annotations: {
        stemColor: 'black',
        textStyle: {
          fontSize: 16,
          strokeColor: 'black',
          bold: true,
          color: 'black',
          // auraColor: 'white',
          // opacity: 0.8
        }
      },
      tooltip: {
        text: "both",
        // text: 'percentage',
        // trigger: true,
        trigger: 'none',
        // trigger: 'selection',
      }
    };

    var chart = new google.visualization.ColumnChart(document.getElementById('columnchart_values'));
    chart.draw(view, options);
  }
}


function showModal() {
  $('#assumptionModal').modal('show');
}

var redirectPath = JSON.parse(sessionStorage.getItem('redirectionFrom'));

function back() {
  window.location.href = '../pages/dontKnow.html';
}


hideLoader();


function generateDynamicUrl(){
  //window.open('https://enps.nsdl.com/eNPS/NPPInitialExistingUser.html?p=' + pranNo, '_blank');
  window.open('https://121.240.64.230/eNPS/NPPInitialExistingUser.html?p=' + pranNo, '_blank');
}