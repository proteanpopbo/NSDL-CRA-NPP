
var serviceIP = "https://testing.finlabsindia.org";
var ClientServiceUrl = serviceIP + "/clientservice/";



function nppApiRequest(method, jsondata, path, callbackSuccess) {

    if (method == "GET") {
        $.ajax({
            async: true,
            url: ClientServiceUrl + path,
            method: method,
            dataType: 'json',
            beforeSend: function(xhr) {
                xhr.setRequestHeader('Authorization', "Bearer" + sessionStorage.getItem("sessionID"));
            },
            contentType: "application/json; charset=utf-8",
            success: callbackSuccess,
            error: function(jqXHR, exception) {
                var msg = '';
                if (jqXHR.status === 0) {
                    msg = 'Could not connect to the server, please contact System Administrator.';
                } else if (jqXHR.status == 400) {
                    msg = 'There is some problem in the server, please contact System Administrator.\n';
                } else if (jqXHR.status == 401) {
                    var error, error_description;
                    error = jqXHR.responseJSON.error_description;
                    error_description = "Access token expired: " + sessionStorage.getItem("sessionID");
                    if (error === error_description) {
                        msg = "Your session has expired.Please log in again",
                            bootbox.alert({
                                message: msg,
                                callback: function() {
                                    window.location = "../index.html";
                                }
                            })
                    }
                    if (error === "unauthorized") {
                        msg = "Full authentication is required to access this resource",
                            bootbox.alert({
                                message: msg
                            })
                    }
                } else if (jqXHR.status == 403) {
                    msg = 'you don’t have permission to access ‘/’ on this server.';
                } else if (jqXHR.status == 404) {
                    msg = 'Requested service url not found.';
                } else if (jqXHR.status == 500) {
                    msg = 'There is some problem in the server, please contact System Administrator.\n';
                } else if (exception === 'parsererror') {
                    msg = 'Failed to get result.';
                } else if (exception === 'timeout') {
                    msg = 'Timed Out!';
                } else if (exception === 'abort') {
                    msg = 'Request aborted.';
                } else {
                    msg = 'Something went wrong, could not connect to the server, please contact System Administrator.\n';
                }
                if (JSON.parse(jqXHR.responseText).errorMessage != null || JSON.parse(jqXHR.responseText).errorMessage != undefined || JSON.parse(jqXHR.responseText).errorMessage != "") {
                    sessionStorage.removeItem("MSG");
                    sessionStorage.setItem("MSG", JSON.parse(jqXHR.responseText).errorMessage);
                }

                if (msg != "" || JSON.parse(jqXHR.responseText).errorMessage != null || JSON.parse(jqXHR.responseText).errorMessage != "undefined" || JSON.parse(jqXHR.responseText).errorMessage != "") {
                    sessionStorage.removeItem("MSG");
                    sessionStorage.setItem("MSG", JSON.parse(jqXHR.responseText).errorMessage + '\n' + msg);
                }

                if (JSON.parse(jqXHR.responseText).errorMessage == undefined) {
                    sessionStorage.removeItem("MSG");
                    sessionStorage.setItem("MSG", msg);
                }
                /*if (msg != "") {
                    sessionStorage.removeItem("MSG");
                    sessionStorage.setItem("MSG", JSON.parse(jqXHR.responseText).errorMessage +'\n'+msg);
                }*/

            }
        });


    } else {

        $.ajax({
            async: true,
            url: ClientServiceUrl + path,
            method: method,
            data: jsondata,
            dataType: 'json',
            beforeSend: function(xhr) {
                xhr.setRequestHeader('Authorization', "Bearer " + sessionStorage.getItem("sessionID"));
            },
            contentType: "application/json; charset=utf-8",
            success: callbackSuccess,
            error: function(jqXHR, exception) {

                var msg = '';
                if (jqXHR.status === 0) {
                    msg = 'Could not connect to the server, please contact System Administrator.';
                } else if (jqXHR.status == 400) {
                    msg = 'There is some problem in the server, please contact System Administrator.\n';
                } else if (jqXHR.status == 401) {
                    var error, error_description;
                    error = jqXHR.responseJSON.error_description;
                    error_description = "Access token expired: " + sessionStorage.getItem("sessionID");
                    if (error === error_description) {
                        msg = "Your session has expired.Please log in again"
                        bootbox.alert({
                            message: msg,
                            callback: function() {
                                window.location = "../index.html";
                            }
                        })
                    }
                    if (error === "unauthorized") {
                        msg = "Full authentication is required to access this resource",
                            bootbox.alert({
                                message: msg
                            })
                    }
                } else if (jqXHR.status == 403) {
                    msg = 'you don’t have permission to access ‘/’ on this server.';
                } else if (jqXHR.status == 404) {
                    msg = 'Requested service url not found.';
                } else if (jqXHR.status == 405) {
                    msg = 'Could not connect to the server, please contact System Administrator.\n';
                } else if (jqXHR.status == 500) {
                    msg = 'There is some problem in the server, please contact System Administrator.\n';
                } else if (exception === 'parsererror') {
                    msg = 'Failed to get result.';
                } else if (exception === 'timeout') {
                    msg = 'Timed Out!';
                } else if (exception === 'abort') {
                    msg = 'Request aborted.';
                } else {
                    msg = 'Something went wrong, could not connect to the server, please contact System Administrator.\n';
                }
                if (JSON.parse(jqXHR.responseText).errorMessage != null || JSON.parse(jqXHR.responseText).errorMessage != undefined || JSON.parse(jqXHR.responseText).errorMessage != "") {
                    sessionStorage.removeItem("MSG");
                    sessionStorage.setItem("MSG", JSON.parse(jqXHR.responseText).errorMessage);
                }

                if (msg != "" || JSON.parse(jqXHR.responseText).errorMessage != null || JSON.parse(jqXHR.responseText).errorMessage != "undefined" || JSON.parse(jqXHR.responseText).errorMessage != "") {
                    sessionStorage.removeItem("MSG");
                    sessionStorage.setItem("MSG", JSON.parse(jqXHR.responseText).errorMessage + '\n' + msg);
                }

                if (JSON.parse(jqXHR.responseText).errorMessage == undefined) {
                    sessionStorage.removeItem("MSG");
                    sessionStorage.setItem("MSG", msg);
                }
                /*if (msg != "") {
                    sessionStorage.removeItem("MSG");
                    sessionStorage.setItem("MSG", JSON.parse(jqXHR.responseText).errorMessage +'\n'+msg);
                }*/

            }
        });
    }
}




 //BusinessServiceUrl = serviceIP + "/BusinessService/";
 var ClientServiceUrl = serviceIP + "/clientservice/";
 //alert("service loaded");
 function getToken(method, jsondata, path, callbackSuccess, username, password) {

     var auth = "";
     auth = btoa("testjwtclientid:XY7kmzoNzl100");
     if (method == "POST") {
         $.ajax({
             url: ClientServiceUrl + path,
             type: method,
             dataType: "json",
             data: "username=" + username + "&password=" + encodeURIComponent(password) + "&grant_type=password",
             beforeSend: function(request) {
                 request.setRequestHeader('Authorization', "Basic " + auth);
                 request.setRequestHeader('Content-Type', "application/x-www-form-urlencoded");
             },
             xhrFields: {
                 withCredentials: false
             },
             success: callbackSuccess,
             error: function(jqXHR, exception) {

                 var msg = '';
                 if (jqXHR.status === 0) {
                     msg = 'Could not connect to the server, please contact System Administrator.';
                 } else if (jqXHR.status == 400) {
                     msg = 'There is some problem in the server, please contact System Administrator.\n';
                     bootbox.alert("username or password invalid.\n");
                 } else if (jqXHR.status == 401) {
                     msg = "user not found.\n";
                     bootbox.alert("username or password invalid.\n");
                 } else if (jqXHR.status == 404) {
                     msg = 'Requested service url not found.';
                 } else if (jqXHR.status == 500) {
                     msg = 'There is some problem in the server, please contact System Administrator.\n';
                 } else if (exception === 'parsererror') {
                     msg = 'Failed to get result.';
                 } else if (exception === 'timeout') {
                     msg = 'Timed Out!';
                 } else if (exception === 'abort') {
                     msg = 'Request aborted.';
                 } else {
                     msg = 'Something went wrong, could not connect to the server, please contact System Administrator.\n';
                 }
                 //$('#post').html(msg);
                 /*var alertBox = bootbox.alert("Message: " + msg, function(){ 
                     ////console.log('This was logged in the callback!'); 
                     $("#idClient").load("resources/errorPage.html");
                 });*/
                 // alert("Error Msg : \n" + ClientServiceUrl + path +"\n "+ msg);
                 /*setTimeout(function() {
                     alertBox.modal('hide');
                     $("#idClient").load("resources/errorPage.html");
                 }, 3000);*/
                 if (JSON.parse(jqXHR.responseText).errorMessage != null || JSON.parse(jqXHR.responseText).errorMessage != undefined || JSON.parse(jqXHR.responseText).errorMessage != "") {
                     sessionStorage.removeItem("MSG");
                     sessionStorage.setItem("MSG", JSON.parse(jqXHR.responseText).errorMessage + '\n' + msg);
                 }

                 if (msg != "" || JSON.parse(jqXHR.responseText).errorMessage != null || JSON.parse(jqXHR.responseText).errorMessage != "undefined" || JSON.parse(jqXHR.responseText).errorMessage != "") {
                     sessionStorage.removeItem("MSG");
                     sessionStorage.setItem("MSG", JSON.parse(jqXHR.responseText).errorMessage + '\n' + msg);
                 }

                 if (JSON.parse(jqXHR.responseText).errorMessage == undefined) {
                     sessionStorage.removeItem("MSG");
                     sessionStorage.setItem("MSG", msg);
                 }
                 /*if (msg != "") {
                     sessionStorage.removeItem("MSG");
                     sessionStorage.setItem("MSG", JSON.parse(jqXHR.responseText).errorMessage +'\n'+msg);
                 }*/
                 $("#idClient").load("resources/errorPage.html");
                 $("#idBusiness").load("resources/errorPage.html");
                 $("#idBuinessMasters").load("resources/errorPage.html");
             }
         });


     }
 }






function logIn() {
    getToken("POST", "", "oauth/token", onGetToken, username, password);

    function onGetToken(msg) {
        sessionStorage.setItem("sessionID", JSON.parse(JSON.stringify(msg)).access_token);
        if (loginFlag == "Y") {
            getClientData("GET", "", "findLastLoginTime?username=" + username + "&password=" + encodeURIComponent(password),
                onGetSuccessLogIn);

            function onGetSuccessLogIn(getData) {
                if (getData.errorCode === "NOT_FOUND") {
                    $('#MegModal').modal('show');


                    $("#meg").text("Please enter Email and Password");
                    // alert(getData.errorMessage);
                } else {
                    if (getData.newUser === "Y") {
                        //  //console.log("FirstLogin of user" + getData.emailID);
                        sessionStorage.setItem("LOGGED_EMAIL_ID", getData.emailID);
                        window.location = "changePasswordUser.html";
                    } else if (getData.lastLoginTime != null) {
                        getClientData("POST", jsondata, "login", onSuccess);

                        function onSuccess(data) {
                            if (data.errorCode === "NOT_FOUND") {
                                alert(data.errorMessage);
                            } else {
                                rememberMe();
                                sessionStorage.setItem("LOGGED_IN_USER", JSON.stringify(data));
                                //window.location = "advisordashboard.html";
                                var loggedUser = JSON.parse(sessionStorage.getItem(
                                    "LOGGED_IN_USER"));
                                if (data.role == "Admin") {
                                    sessionStorage.setItem("Super_Admin", "Active");
                                    var loggedAdmin = sessionStorage.getItem("LOGGED_IN_USER");
                                    //alert(loggedAdmin.id);
                                    sessionStorage.setItem("Logged_Admin", loggedAdmin);
                                    //var loggedAdmin1 = JSON.parse(sessionStorage.getItem("Logged_Admin"));
                                    //alert(loggedAdmin1.id);
                                    window.location = "MyClient/adminDashboard.html";
                                } else {
                                    sessionStorage.setItem("Super_Admin", "deactive");

                                    window.location = "MyClient/myclientDashboard.html";
                                }
                            }


                        }
                    }
                }
            }
        } else {
            getClientData("GET", "", "findLastLoginTimeForClient?username=" + username + "&password=" + encodeURIComponent(password),
                onGetSuccessLogIn);

            function onGetSuccessLogIn(getData) {
                if (getData.errorCode === "NOT_FOUND") {
                    alert(getData.errorMessage);
                } else {
                    if (getData.newClient === "Y") {
                        //console.log("FirstLogin of user" + getData.id);
                        sessionStorage.removeItem("CLIENT_LOGIN_ID");
                        sessionStorage.setItem("CLIENT_LOGIN_ID", getData.id);
                        sessionStorage.setItem("LOGGED_EMAIL_ID", getData.emailId);
                        window.location = "changePasswordClient.html";
                    } else if (getData.lastLoginTime != null) {
                        sessionStorage.setItem("Super_Admin", "deactive");
                        getClientData("POST", jsondata, "loginForClient", onSuccess);

                        function onSuccess(data) {
                            if (data.errorCode === "NOT_FOUND") {
                                alert(data.errorMessage);
                            } else {
                                rememberMe();
                                //console.log(data);
                                sessionStorage.setItem("LOGGED_IN_CLIENT", JSON.stringify(data));
                                sessionStorage.setItem("SELECTED_CLIENT_ID", data.id);
                                //window.location = "advisordashboard.html";
                                window.location = "MyClient/myclientDashboard.html";
                            }

                        }
                    }
                }
            }

        }

    }
}