function processToPlan() {
    window.location.href = '../plan/plan_home.html';
}