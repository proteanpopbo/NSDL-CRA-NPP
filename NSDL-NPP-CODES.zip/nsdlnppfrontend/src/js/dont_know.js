$('.inner_card').hide();
$('.graph_area').hide();
showLoader();

var comRequiredPension;

var lanValue = localStorage.getItem('i18nextLng');
console.log(lanValue);
  if(lanValue == "en"){
      $('#idGrapgImg').prop('src','../../assets/images/First.png');
  }
  else if(lanValue == "hi"){
      $('#idGrapgImg').prop('src','../../assets/images/first_hindi.png');
  }

var currentNpsCorpus = JSON.parse(sessionStorage.getItem('currentNpsCorpus'));
var pensionData = JSON.parse(sessionStorage.getItem('monthlyPension'));
var empData = JSON.parse(sessionStorage.getItem('employeeData'));

var rupeeSign = '<i class="fa-solid fa-indian-rupee-sign"></i>';

$('document').ready(function(){
  showLoader();
  var monthlyLivingExpensesVal = sessionStorage.getItem('monthlyLivingExpens');
  var rate = sessionStorage.getItem('inflationRate');
  

   if(monthlyLivingExpensesVal !== null && rate !== null){
      var monthlyLivingExpenses = (monthlyLivingExpensesVal).toLocaleString('en-IN', {
         maximumFractionDigits: 0,
         currency: 'INR'
       });
       $('#monthlyLivingExpenses').val(monthlyLivingExpenses);

       $('#rateOfInflution').val(rate);
   }

  // range-slider
  

  var slider = new Slider("#range-slider", {
    tooltip: 'always',
    tooltip_position: 'bottom',
    formatter: function(value) {
          return   value + '%';
      }
  });

  $('.inner_card').show();
  $('.graph_area').show();

  if(rate != null){
    //console.log("rate", rate)
    slider.setValue(rate)
  }else{
    //console.log("rat vgvhgcv")
    slider.setValue("5")
  }
  $('#range-slider').change(function(){
    var x = $('#range-slider').val();
    if(x == 0){
      $('#idNuzeImage').hide();
      $('.c-range-slider__label--min').hide();
    }else{
      $('#idNuzeImage').show();
      $('.c-range-slider__label--min').show();
    }
    if(x == 10){
      $('.c-range-slider__label--max').hide();
    }else{
      $('.c-range-slider__label--max').show();
    }
  })
  
  function minMaxShow(){
    var x = $('#range-slider').val();
    if(x == 0){
      $('#idNuzeImage').hide();
      $('.c-range-slider__label--min').hide();
    }else{
      $('#idNuzeImage').show();
      $('.c-range-slider__label--min').show();
    }
    if(x == 10){
      $('.c-range-slider__label--max').hide();
    }else{
      $('.c-range-slider__label--max').show();
    }
  }

   if(rate != null){
    //Slider code 
   }

   setTimeout(() => {
    calculatePensionRequirement();
  }, 600);
  
  // calculatePensionRequirement();

  minMaxShow();

  function loadText(){
    $('#pensionRequireYear').html(i18next.t('NSDL_NPP_LAN_117', {
      value: i18next.format(currentNpsCorpus.retirementYearOnly, 'uppercase')
   }));

   $('#chartTitle').html(i18next.t('NSDL_NPP_LAN_129', {
     value: i18next.format(currentNpsCorpus.retirementYearOnly, 'uppercase')
  }));

  var currentInputCont = document.getElementById('range-slider')
   $('#increasePension').html(i18next.t('NSDL_NPP_LAN_118', {
     value: i18next.format(pensionData.periodicRoi, 'uppercase')
  }));
   }

  setTimeout(() => {
   loadText();
 }, 600);

var incContribution = pensionData.oldPensionWithOutRop;
 var increaseContribution = (incContribution).toLocaleString('en-IN', {
  maximumFractionDigits: 0,
  currency: 'INR'
});
 $('#contributionWithIncrease').html(rupeeSign +" "+ increaseContribution);
//  drawColumnChart(pensionData.oldPensionWithOutRop,500);

// Compare Pension

})

// Incriment / Decrement
const incriment = (number) => {
  if (isNaN(number)){
    number=0;
  }
  //console.log('number',number)
  var x = parseInt(number) + 1000;
  var stringValue = x.toLocaleString('en-IN', {
    maximumFractionDigits: 0,
    currency: 'INR'
  });
  return stringValue;
}

const decrement = (number) => {
  if (isNaN(number)){
    number=0;
  }
  var x = parseInt(number) - 1000;
  var stringValue = x.toLocaleString('en-IN', {
    maximumFractionDigits: 0,
    currency: 'INR'
  });
  return stringValue;
  //return number > 1000 ? number - 1000 : number;
}


let plusButton = document.getElementById('plus');
let minusButton = document.getElementById('minus');
const incrimentInflation = (number) => {
  return number < 20 ? number + 1 : number;
}
const decrementInflation = (number) => {
  return number > 1 ? number - 1 : number;
}

let balancePlusButton = document.getElementById('inflationPlus');
let balanceMinusButton = document.getElementById('inflationMinus');

// api Call
var calculatedPensionRespons;
function calculatePensionRequirement() {


  showLoader();
  var livingExpenses = document.getElementById('monthlyLivingExpenses').value;
  var inflationRate = document.getElementById('range-slider').value;
  var currentDate = new Date();
  var newYear = currentDate.getFullYear();
  var num = parseFloat(livingExpenses.replace(/,/g, ''));
  var inflationObj = {
    "currentYear": Number(newYear),
    "expenses": num,
    "inflationRate": Number(inflationRate),
    "retirement": Number(currentNpsCorpus.remainingRetirementYear),
    "retirementDate": Number(currentNpsCorpus.retirementYearOnly)
  }
  var stringInflationObj = JSON.stringify(inflationObj);

  nppApiRequest('POST', stringInflationObj , 'api/calculator/getMonthlyPensionRequired', getPensionRequirement);

  function getPensionRequirement(data) {
    if (data == 'null') {
      hideLoader();
      alert('Data Not Found')
    } else {
      calculatedPensionRespons = data.pensionRequired;
      comRequiredPension = data.pensionRequired;
      $('#idMonthlyPensionRequirement').html(rupeeSign +" "+ (data.pensionRequired).toLocaleString('en-IN', {
        maximumFractionDigits: 0,
        // style: 'currency',
        currency: 'INR'
      }));

      var sts = data.pensionRequired.toLocaleString('en-IN', { maximumFractionDigits: 0,
        currency: 'INR'
      })

      calculatedPensionRespons = sts;
      // $('#idRetirementYear').text(currentNpsCorpus.retirementYearOnly);

      setTimeout(() => {
        $('#idRetirementYear').html(i18next.t('NSDL_NPP_LAN_74', {
           value: i18next.format(currentNpsCorpus.retirementYearOnly, 'uppercase')
        }));
        
     }, 700);
      // drawAreaChart(data.monthlyPensionList);
      drawColumnChart(pensionData.oldPensionWithOutRop,data.pensionRequired);
      pensionRateCompare(pensionData.oldPensionWithOutRop,data.pensionRequired)
      hideLoader();
    }
  }


function pensionRateCompare(roundrequiredPension,roundCurrentPension){
  if(roundrequiredPension > roundCurrentPension){
    $('#redirectBtn').hide();
    $('#idDynamicMessage').show();
    $('.btn_area').css('margin-top','25px');
    // alert('ok');
  }else{
    $('#redirectBtn').show();
    $('#idDynamicMessage').hide();
    $('.btn_area').css('margin-top','inherit');
  }
}



// console.log('dddddd'+ comRequiredPension)
// console.log("ffffff"+Number(roundCurrentPension))


}

function format(input) {
  var x=input.value;
  x=x.toString();
  var lastThree = x.substring(x.length-3);
  var otherNumbers = x.substring(0,x.length-3);
  if(otherNumbers != '')
      lastThree = ',' + lastThree;
  var res = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ",") + lastThree;
  input.value =res;
}


function redirectToShouldDoPage(){
  // console.log("kkkkkkkkkk"+calculatedPensionRespons);

  sessionStorage.setItem('clientInputPension', calculatedPensionRespons);
  let contribution = document.getElementById('monthlyLivingExpenses').value;
  let rate = document.getElementById('range-slider').value;
  sessionStorage.setItem('monthlyLivingExpens', contribution);
  sessionStorage.setItem('inflationRate', rate);
  window.location.href = "../pages/whatShouldiDo.html";

  var redirectionObject = {
    "redirectionFrom" : 'dontKnow'
  }
  sessionStorage.setItem('redirectionFrom', JSON.stringify(redirectionObject))
}

let back = () => {
  // window.location.href = '../pages/howMuchDoiNeed.html';
  window.location.href = '../pages/pensionCalculation.html';
  // window.history.go(-1);
}


// Draw Column Chart
function drawColumnChart(pensionWithRop, pensionWithOutRop) {
  google.load('visualization', '1', {
    packages: ['corechart', 'bar']
  });

  google.charts.setOnLoadCallback(drawChartt);

  function drawChartt() {
    var formatter = new google.visualization.NumberFormat({
      prefix: '<del>&#2352;</del>'
    });
    var data = google.visualization.arrayToDataTable([
      ['Year', i18next.t('NSDL_NPP_LAN_119'), i18next.t('NSDL_NPP_LAN_120')],
      [i18next.t(''), pensionWithRop, pensionWithOutRop],
      // [i18next.t('NSDL_NPP_LAN_99'), oldPensionWithRop, oldPensionWithOutRop],
    ]);

    // i18next.t('NSDL_NPP_LAN_47')

    var formatter = new google.visualization.NumberFormat({
      negativeColor: 'red',
      negativeParens: true,
      pattern: '₹#,##,##,##,###'
    });
    formatter.format(data, 1);
    var formatter = new google.visualization.NumberFormat({
      negativeColor: 'red',
      negativeParens: true,
      pattern: '₹#,##,##,##,###'
    });
    formatter.format(data, 2);

    var view = new google.visualization.DataView(data);
    view.setColumns([0, 1,
      {
        calc: "stringify",
        sourceColumn: 1,
        type: "string",
        role: "annotation"
      },
      2,
      {
        calc: "stringify",
        sourceColumn: 2,
        type: "string",
        role: "annotation"
      },
    ]);

    var options = {
      bar: { groupWidth: '40%' },
      legend: { position: "none" },
      // bar: {groupWidth: '80%'},
      backgroundColor: {
        fill: "#fff"
      },
      colors: ['#EFA26D', '#FEB526'],
      legend: {
        labeledValueText: 'both',
        position: "bottom",
        alignment: 'center',
        textStyle: {
          color: 'black',
          // fontSize: 12,
          bold: true,
        }
      },
      chartArea: {
        left:110,
        right:45,
        top: 20,
        // width: '100%', 
        // height: '65%'
      },
      vAxis: {
        minValue: 0,
        textPosition: 'none',
        title: '',
        ticks: [0, .3, .6, .9, 1],
        baselineColor: '#fff',
         gridlineColor: '#fff',
         
        // maxValue: 100,
        // minValue: -100,
        gridlines: { count: 0 },
        gridlines: {
          count: 0,
              color: 'transparent',
              textPosition: 'none'
            }
      },
      // hAxis: {baselineColor: 'none'},
      // hAxis: {slantedText: true},
      annotations: {
        stemColor: 'black',
        textStyle: {
          fontSize: 16,
          strokeColor: 'black',
          bold: true,
          color: 'black',
          // auraColor: 'white',
          // opacity: 0.8
        }
      },
      tooltip: {
        text: "both",
        // text: 'percentage',
        // trigger: true,
        trigger: 'none',
        // trigger: 'selection',
      }
    };

    var chart = new google.visualization.ColumnChart(document.getElementById('columnchart_values'));
    chart.draw(view, options);
  }
}

