// function redireToDontKnowPage(){
//     window.location.href = "../pages/dontKnow.html";
// }

$(document).ready(function () {
   var currentNpsCorpus = JSON.parse(sessionStorage.getItem('currentNpsCorpus'));
   var clientInputPension = JSON.parse(sessionStorage.getItem('redirectionFrom'));

   if(clientInputPension !== null){
      // var clientInputPensionVal = (clientInputPension.pension).toLocaleString('en-IN', {
      //    maximumFractionDigits: 0,
      //    currency: 'INR'
      //  });
     // console.log("inputPension",clientInputPension)
       $('#inputPension').val(clientInputPension.pension);
   }

   setTimeout(() => {
      $('#requiredPensionCalculation').html(i18next.t('NSDL_NPP_LAN_53', {
         value: i18next.format(currentNpsCorpus.retirementYearOnly, 'uppercase')
      }));

      $('#requiredPensionCalculation').html(i18next.t('NSDL_NPP_LAN_53', {
         value: i18next.format(currentNpsCorpus.retirementYearOnly, 'uppercase')
      }));
      

   }, 700);
})

function requiredPension() {
   var inputValue = document.getElementById('inputPension').value;
   if (inputValue == '') {

      swal({
         title: i18next.t('NSDL_NPP_LAN_86'),
         button: i18next.t('NSDL_NPP_LAN_87')
       }); 

      // swal(
      //    {title: i18next.t('NSDL_NPP_LAN_86')} //Grade
      //    );
      // swal('Please Enter Required Pension Amount');
   } else {
      var inputPension = document.getElementById('inputPension').value;
      sessionStorage.setItem('clientInputPension', inputPension);
      window.location.href = "../pages/whatShouldiDo.html";

      // Redirect Path
      var redirectionObject = {
         "redirectionFrom" : 'howMuchDoiNeed',
         "pension" : inputPension
       }
       sessionStorage.setItem('redirectionFrom', JSON.stringify(redirectionObject))
   }
}

function format(input) {
   var x=input.value;
   x=x.toString();
   var lastThree = x.substring(x.length-3);
   var otherNumbers = x.substring(0,x.length-3);
   if(otherNumbers != '')
       lastThree = ',' + lastThree;
   var res = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ",") + lastThree;
 
   input.value =res;
 }

function redirection() {
   window.location.href = "../pages/dontKnow.html";
}

let back = () => {
   window.location.href = '../pages/pensionCalculation.html';
   // window.history.go(-1);
 }

 