$(document).ready(function(){
    $('#idStepperBody').empty();
    $('#idHeader').load('header.html');
    $('#idStepperHeader').load('stepper_header.html');
    // $('.circle_inner.active').removeClass('active'); 
    // $('.title.active').removeClass('active');
    $('#idStepperBody').load('how_ready_ami.html');
})

// function redirectToIneedPage(){
//     $('#idStepperBody').empty();
//     $('#idFirstCircle').removeClass('active');
//     $('#idFirstTitle').removeClass('active');
//     $('#idSecondCircle').addClass('active');
//     $('#idSecondTitle').addClass('active');
//     $('#idStepperBody').load('how_much_do_I_need.html');
// }

function redirectToIneedPage(){
   window.location.href = '../../src/pages/howMuchDoiNeed.html';
}



// function redirectToShouldDoPage(){
//     $('#idStepperBody').empty();
//     $('#idSecondCircle').removeClass('active');
//     $('#idSecondTitle').removeClass('active');
//     $('#idThirdCircle').addClass('active');
//     $('#idThirdTitle').addClass('active');
//     $('#idStepperBody').load('what_should_I_do.html');
// }

// Back Page
function redirectToHowReadyPage(){
    $('#idStepperHeader').empty();
    $('#idStepperBody').empty();
    $('#idHeader').load('header.html');
    $('#idStepperHeader').load('stepper_header.html');
    $('#idStepperBody').load('how_ready_ami.html'); 
    // $('#iDButtonSecond').addClass('active'); 
}
function redirectToDoNeedPage(){
    $('#idStepperBody').empty();
    $('#idStepperBody').load('how_much_do_I_need.html');
    $('#idThirdCircle').removeClass('active');
    $('#idThirdTitle').removeClass('active');
    $('#idSecondCircle').addClass('active');
    $('#idSecondTitle').addClass('active');
}

// Idont Know Page Redirection
// function redireToDontKnowPage(){
//     window.location.href = "../pages/dontKnow.html";
// }
// function redireToDontKnowPage(){
//     $('#idStepperBody').empty();
//     $('#idThirdCircle').removeClass('active');
//     $('#idThirdTitle').removeClass('active');
//     $('#idSecondCircle').addClass('active');
//     $('#idSecondTitle').addClass('active');
//     $('#idStepperBody').load('dont_know.html');
// }

// Back to how much do i need page - Back
function redireToHowMuchDoiNeedPage(){
    $('#idStepperBody').empty();
    $('#idStepperBody').load('how_much_do_I_need.html');
    $('#idThirdCircle').removeClass('active');
    $('#idThirdTitle').removeClass('active');
    $('#idSecondCircle').addClass('active');
    $('#idSecondTitle').addClass('active');
}