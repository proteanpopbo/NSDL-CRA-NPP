google.charts.load("current", {
  packages: ["corechart"]
});
google.charts.setOnLoadCallback(drawChart);

var x = Math.round(80);
var y = Math.round(20);

// (x).toLocaleString('en-IN', {
//   maximumFractionDigits: 0,
//   style: 'currency',
//   currency: 'INR'
// })
// (y).toLocaleString('en-IN', {
//   maximumFractionDigits: 0,
//   style: 'currency',
//   currency: 'INR'
// })

function drawChart() {
  var data = google.visualization.arrayToDataTable([
    ['Task', 'Hours per Day'],
    ['Annuity Corpus', x],
    ['Lumpsum Corpus', y],
    // [`Annuity Corpus ${x.toLocaleString('en-IN', {
    //         maximumFractionDigits: 0,
    //         style: 'currency',
    //         currency: 'INR'
    //       })}`, x],
    // [`Lumpsum Corpus ${y.toLocaleString('en-IN', {
    //         maximumFractionDigits: 0,
    //         style: 'currency',
    //         currency: 'INR'
    //       })}`, y],
  ]);

  var options = {
    // enableInteractivity: false,
    backgroundColor: {
      fill: "#F4F4F4"
    },
    colors: ['#3192D0', '#F07E26', '#FFCD1C'],
    title: '',
    // height: 360,
    // width: 360,
    pieHole: 0.4,
    showLables: 'true',
    pieSliceText: 'value',
    pieSliceText: 'percentage',
    pieSliceTextStyle: {
      color: 'black',
      fontSize: 16
    },
    legend: {
      labeledValueText: 'both',
      position: "bottom",
      alignment: 'center',
      textStyle: {
        color: 'black',
        fontSize: 15,
        // bold: true,
      }
    },
    tooltip: {
      // text: "both",
      // text: 'percentage',
      // trigger:false,
      trigger: 'selection',
    },
    chartArea: {
      left: "",
      top: 40,
      // width: '100%', 
      // height: '65%'
    },
    // pieSliceText: 'label',
    // title: 'Swiss Language Use (100 degree rotation)',
    pieStartAngle: 100,
    // is3D: true,
  };

  var chart = new google.visualization.PieChart(document.getElementById('donutchart'));
  chart.draw(data, options);
}




function drawChartt() {
  var data = google.visualization.arrayToDataTable([
    ['Year', 'With ROP', 'Without ROP'],
    ['Pension as per current contribution', 1000, 400],
    ['Pension as per current new contribution', 670, 360],
  ]);

  var view = new google.visualization.DataView(data);
  view.setColumns([0, 1,
    {
      calc: "stringify",
      sourceColumn: 1,
      type: "string",
      role: "annotation"
    },
    2,
    {
      calc: "stringify",
      sourceColumn: 2,
      type: "string",
      role: "annotation"
    },
  ]);

  var options = {
    backgroundColor: {
      fill: "#F4F4F4"
    },
    colors: ['#3192D0', '#F07E26', '#FFCD1C'],
    legend: {
      labeledValueText: 'both',
      position: "bottom",
      alignment: 'center',
      textStyle: {
        color: 'black',
        fontSize: 14
      }
    },
    chartArea: {
      left: "",
      top: 40,
      // width: '100%', 
      // height: '65%'
    },
    vAxis: {
      gridlines: {
        color: 'transparent',
        interval: 0
      }
    },
    annotations: {
        stemColor : 'none',
        textStyle: {
        //   fontName: 'Times-Roman',
          fontSize: 15,
        //   strokeColor: 'black',
          // bold: true,
        //   italic: true,
          color: 'black',
          auraColor: 'black',
        //   opacity: 0.8
        }
      },
      tooltip: {
        // text: "both",
        // text: 'percentage',
        // trigger:false,
        trigger: 'selection',
      }
  };

  var chart = new google.visualization.ColumnChart(document.getElementById('columnchart_values'));
  chart.draw(view, options);
}
google.load('visualization', '1', {
  packages: ['corechart'],
  callback: drawChartt
});





//   google.charts.load("current", {packages:['corechart']});
//   google.charts.setOnLoadCallback(drawChartt);
//   function drawChartt() {
//     var data = google.visualization.arrayToDataTable([
//       ["Element", "", { role: "style" } ],
//       ["Required* Projected pension - Joint Life with ROP", 100000, "#039ee8"],
//       // ["Current Preparedness", 300000, "#7bc043"],
//       // ["Gap", 200000, "#f37736"],
//       // ["Platinum", 21.45, "color: #e5e4e2"]
//     ]);

//     var view = new google.visualization.DataView(data);
//     view.setColumns([0, 1,
//                      { calc: "stringify",
//                        sourceColumn: 1,
//                        type: "string",
//                        role: "annotation" },
//                      2]);

//     // var paddingHeight = 100;
//     // var rowHeight = data.getNumberOfRows() * 50;
//     // var chartHeight = rowHeight + paddingHeight;                 

//     var options = {
//       legend: true,
//       backgroundColor: { 
//         fill: "#F4F4F4",
//       },
//       colors: ['transparent'],
//       title: "",
//       titleTextStyle: {
//           // color: '#FF0000',
//         },
//         // colors: ['#3192D0','#F07E26', '#FFCD1C'],
//       bar: {groupWidth: "95%"},
//       bar: {width: "25%"},
//       vAxis: {
//         colors: ['#3192D0','#F07E26', '#FFCD1C'],
//           gridlines: {
//               interval: 0
//               // color: 'transparent'
//           }
//       },
//       annotations: {
//           stemColor : 'none',
//           textStyle: {
//           //   fontName: 'Times-Roman',
//             fontSize: 16,
//           //   strokeColor: 'black',
//             bold: true,
//           //   italic: true,
//             color: 'black',
//             auraColor: 'transparent',
//           //   opacity: 0.8
//           }
//         },
//     };

//     var chart = new google.visualization.ColumnChart(document.getElementById("columnchart_values"));
//     chart.draw(view, options);
// }