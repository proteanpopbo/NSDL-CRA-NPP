// showLoader();
var employeeData = JSON.parse(sessionStorage.getItem('employeeData'));
// var employeeId = sessionStorage.getItem('employeeId');
var onlyYear;
let inextLngs = localStorage.getItem("i18nextLng");
var validateDtae = new Date("01/01/2004")
var currentNpsCorpus = JSON.parse(sessionStorage.getItem('externalApiRespons'));

var externalRespons = JSON.parse(sessionStorage.getItem('externalApiRespons'));
var employeeId = externalRespons.empId;





$(document).ready(function () {
  $('#idToolTip').hide();

  $('#idDob').val(externalRespons.dateOfBirth).trigger('change');
  $('#idDateOfJoining').val(externalRespons.dojNps).trigger('change');
  $('#idDateOfRetirement').val(externalRespons.dateOfRetirement).trigger('change');

  retirementYearPopulation(externalRespons.dateOfBirth, externalRespons.dateOfRetirement);

  if (externalRespons !== null) {
    var npsBalance = (externalRespons.currentNpsBalance).toLocaleString('en-IN', {
      maximumFractionDigits: 0,
      currency: 'INR'
    });

    var totalContribution = (externalRespons.totalContribution).toLocaleString('en-IN', {
      maximumFractionDigits: 0,
      currency: 'INR'
    });
    $('#idNpsBalance').val(npsBalance);
    $('#idTotalContribution').val(totalContribution);

    setTimeout(() => {
      if (externalRespons.empId == 1 || externalRespons.empId == 2) {
        $('#idTotalContributionStatement').html(i18next.t('NSDL_NPP_LAN_144', {
          value: i18next.format(totalContribution, 'uppercase')
        }));
      }
    }, 500);



    // const currentEmpDod = new Date(currentNpsCorpus.dateOfBirth);

    const currentEmpDod = new Date(currentNpsCorpus.dateOfBirth);
    var empDob = moment(currentNpsCorpus.dateOfBirth).format('DD/MM/YYYY');
    var retirementDate = moment(currentNpsCorpus.dateOfRetirement, 'DD/MM/YYYY');
    let DateOfJoining = currentNpsCorpus.dojNps;
    var resDateOfJoining = DateOfJoining.split("/");
    var ressDateOfJoining = resDateOfJoining[2] + '/' + resDateOfJoining[1] + '/' + resDateOfJoining[0]
    var restDateOfDoj = new Date(ressDateOfJoining);
    var dateOfJoining = moment(ressDateOfJoining).format('DD/MM/YYYY');

    let DateOfDob = currentNpsCorpus.dateOfBirth;
    var resdateOfDob = DateOfDob.split("/");
    var ressdateOfDob = resdateOfDob[2] + '/' + resdateOfDob[1] + '/' + resdateOfDob[0]
    var restDateOfDob = new Date(ressdateOfDob);

    //var dobYear =Number(resdateOfDob[2]);
    var dobMonth = resdateOfDob[1];
    var dobDate = resdateOfDob[0];
    ////console.log("dob" +dobDate + '/' + dobMonth + '/' + dobYear)

    var sy = Number(resdateOfDob[2]) + 50;
    var ey = Number(resdateOfDob[2]) + 75;

    var retairmentMinRange = dobMonth + '/' + dobDate + '/' + sy
    var retairmentMaxRange = dobMonth + '/' + dobDate + '/' + ey
    $("#idDob").val(moment(restDateOfDob).format('DD/MM/YYYY'));
    $("#idDateOfJoining").val(moment(restDateOfDoj).format('DD/MM/YYYY'));
    $("#idDateOfRetirement").val(moment(retirementDate).format('DD/MM/YYYY'));
    $('#uiDateOfJoining').text(moment(restDateOfDoj).format('DD/MM/YYYY'));
    $('#uiDateOfRetirement').text(moment(retirementDate).format('DD/MM/YYYY'));
    // $('#idDob').datepicker({
    //   // autoClose: true,
    //   format: 'dd/mm/yyyy',
    //   maxDate: new Date(),
    //   yearRange: 100,
    //   setDefaultDate: true,
    //   defaultDate: restDateOfDob,
    //   setDefaultDate: restDateOfDob,
    // });
    $("#idDob").on('change', function () {
      selecteddatas = $("#idDob").val()

      // 
      var reg = /^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((19|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((19|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((19|[2-9]\d)\d{2}))|(29\/02\/((1[6-9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(([1][26]|[2468][048]|[3579][26])00))))$/g;


      let regval = reg.test(selecteddatas)
      if (regval === true) {
        Dobdata()
      } else {
        $("#idDob").val("")
        $("#idDateOfRetirement").val("")
        $("#uiDateOfRetirement").val("")
        $("#idRetirementYear").val("")

      }


    })
    $("#idDobIcon").datepicker({
      format: "dd/mm/yyyy",
      todayHighlight: false,
      todayBtn: false,
      setDefaultDate: true,
      //minDate: new Date("01/01/1957"),
      // autoclose: true,
      yearRange: 100,
      maxDate: new Date(),
      //language: inextLngs,
      // todayBtn: "linked",
    }).on('change', function () {
      selecteddatas = $(this).val()
      //console.log(selecteddatas)
      $("#idDob").empty()

      $("#idDob").val(selecteddatas);
      Dobdata()

      // selecteddata(selecteddatas)


    })
    testLoad()
    $("#idDateOfRetirement").on('change', function () {
      let newrestDateOfRetirements = $("#idDateOfRetirement").val()
      // 
      var reg = /^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((19|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((19|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((19|[2-9]\d)\d{2}))|(29\/02\/((1[6-9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(([1][26]|[2468][048]|[3579][26])00))))$/g;
      let currentinput = new Date(moment(newrestDateOfRetirements, 'DD/MM/YYYY'));
      let newcurrentinput = moment(currentinput).format("YYYY")
      let inputretairmentMinRange = moment(retairmentMinRange).format("YYYY")
      let inputretairmentMaxRange = moment(retairmentMaxRange).format("YYYY")
      let regval = reg.test(newrestDateOfRetirements)
      if (regval === true) {
        if (newcurrentinput >= inputretairmentMinRange && newcurrentinput <= inputretairmentMaxRange) {
          RetirementDatefun()
        } else {
          $('#uiDateOfJoining').text('');
          $('#uiDateOfRetirement').text('');
          $('#idRetirementYear').text('');
          $("#idDateOfRetirement").val("")
          swal({
            title: i18next.t('NSDL_NPP_LAN_132'),
            button: i18next.t('NSDL_NPP_LAN_87')
          });
        }
      } else {
        $('#uiDateOfJoining').text('');
        $('#uiDateOfRetirement').text('');
        $('#idRetirementYear').text('');
        $("#idDateOfRetirement").val("")

        swal({
          title: i18next.t('NSDL_NPP_LAN_132'),
          button: i18next.t('NSDL_NPP_LAN_87')
        });
      }

    })

    $('#idDorIcon').datepicker({
      // autoClose: true,
      yearRange: 100,
      format: 'dd/mm/yyyy',
      minDate: new Date(retairmentMinRange),
      maxDate: new Date(retairmentMaxRange),
      //minDate: new Date(),
      setDefaultDate: true,
      defaultDate: restDateOfRetirement,
      setDefaultDate: restDateOfRetirement,
    }).on('change', function () {
      newrestDateOfRetirement = $(this).val()
      $("#idDateOfRetirement").val(newrestDateOfRetirement);
      //   //console.log(newJoiningDateform)
      RetirementDatefun()
      //   let newJoiningDate = new Date(newJoiningDateform);

    })
    let DateOfRetirement = currentNpsCorpus.dateOfRetirement;
    var resDateOfRetirement = DateOfRetirement.split("/");
    var ressDateOfRetirement = resDateOfRetirement[2] + '/' + resDateOfRetirement[1] + '/' + resDateOfRetirement[0]
    var restDateOfRetirement = new Date(ressDateOfRetirement);
    var joiningMinRange;
    var jy = Number(resdateOfDob[2]) + 18;
    if (jy < 2004) {
      joiningMinRange = "01/01/2004";
    } else {
      joiningMinRange = dobMonth + '/' + dobDate + '/' + jy
    }

    // $('#idDateOfJoining').datepicker({
    //   yearRange: 100,
    //   selectYears: 18,
    //   minDate: new Date(joiningMinRange),
    //   setDefaultDate: true,
    //   maxDate: new Date(),
    //   format: 'dd/mm/yyyy',
    //   defaultDate: restDateOfDoj,
    //   setDefaultDate: restDateOfDoj,
    // });


    // $('#idDateOfRetirement').datepicker({
    //   // autoClose: true,
    //   yearRange: 100,
    //   format: 'dd/mm/yyyy',
    //   minDate: new Date(retairmentMinRange),
    //   maxDate: new Date(retairmentMaxRange),
    //   setDefaultDate: true,
    //   defaultDate: restDateOfRetirement,
    //   setDefaultDate: restDateOfRetirement,
    // });

    //document.getElementById('idDateOfJoining').value = dateOfJoining;
    // var remainingYear = sessionStorage.getItem('remainingRetirementYear');
    // console.log('remaining Year ' + remainingYear);
    setTimeout(() => {
      var remainingYear = sessionStorage.getItem('remainingRetirementYear');
      console.log('remaining Year ' + remainingYear);
      // $('#idRetirementYear').html(i18next.t('NSDL_NPP_LAN_31', {
      //   value: i18next.format(remainingYear, 'uppercase')
      // }));
      // console.log('remaining Year ' + remainingYear);

      if (remainingYear === 1) {
        $('#idRetirementYear').html(i18next.t('NSDL_NPP_LAN_111', {
          value: i18next.format(remainingYear, 'uppercase')
        }));

        // //console.log("years should be year")

      } else if (Number(remainingYear) < 1) {
        $('#idRetirementYear').html(i18next.t('NSDL_NPP_LAN_112', {
          value: i18next.format(remainingYear, 'uppercase')
        }));

        // //console.log("You are already Retaired")

      } else {
        $('#idRetirementYear').html(i18next.t('NSDL_NPP_LAN_31', {
          value: i18next.format(remainingYear, 'uppercase')
        }));
      }
    }, 400);

    

    var ContibutionAmountWithOutSymbol = externalRespons.avgYearlyContribution.toLocaleString('en-IN', {
      maximumFractionDigits: 0,
      currency: 'INR'
    })
    var ecb = currentNpsCorpus.currentNpsBalance.toLocaleString('en-IN', {
      maximumFractionDigits: 0,
      currency: 'INR'
    })
    //$('#idAnnualContribution').val(employeeData.contributionAmount);

    $('#idAnnualContribution').val(ContibutionAmountWithOutSymbol);

    $('#idNpsBalance').val(ecb);

    let uiJoiningValue = $('#idDateOfJoining').val();
    $('#uiDateOfJoining').text(uiJoiningValue);


    var estimatedNpsBalance = (currentNpsCorpus.currentNpsBalance).toLocaleString('en-IN', {
      maximumFractionDigits: 0,
      currency: 'INR'
    });

    setTimeout(() => {
      $('#estimatedNpsBalance').show();

      if (employeeId == 1 || employeeId == 2) {
        //ADD Message
        $('#estimatedNpsBalance').html(i18next.t('NSDL_NPP_LAN_35', {
          value: i18next.format(estimatedNpsBalance, 'value'),
          value2: i18next.format(employeeData.rateOfInterest, 'value2') //not found
        }));
      } else {
        //ADD Message

        //Remove Text
        // $('#estimatedNpsBalance').html(i18next.t('NSDL_NPP_LAN_130'));

        //text remove
        // $('#idContibutionAmount').html(i18next.t('NSDL_NPP_LAN_131'));
        // $('#idTotalContributionStatement').html(i18next.t('NSDL_NPP_LAN_131'));

        // $('#idTotalContributionStatement').html(i18next.t('NSDL_NPP_LAN_145', {
        //   value: i18next.format(45544, 'uppercase')
        // }));
        // $('#estimatedNpsBalance').html(i18next.t('NSDL_NPP_LAN_35', {
        //   value: i18next.format(estimatedNpsBalance, 'value'),
        //   value2: i18next.format(employeeData.rateOfInterest, 'value2')
        // }));
      }


    }, 500);

    if (restDateOfDob == null || restDateOfDoj == null || restDateOfRetirement == null) {
      $('#idToolTip').hide();
    } else {
      $('#idToolTip').show();
    }
    // $('#estimatedNpsBalance').show();
  } else {
    var ContibutionAmt = externalRespons.avgYearlyContribution.toLocaleString('en-IN', {
      maximumFractionDigits: 0,
      currency: 'INR'
    })
    //$('#idAnnualContribution').val(employeeData.contributionAmount);
    $('#idAnnualContribution').val(ContibutionAmt);
  }



  var ContibutionAmount = employeeData.contributionAmount.toLocaleString('en-IN', { //not found
    maximumFractionDigits: 0,
    // style: 'currency',
    currency: 'INR'
  })



  setTimeout(() => {
    //$('#idContibutionAmount').html(i18next.t("NSDL_NPP_LAN_33" , {value}));
    if (employeeId == 1 || employeeId == 2) {
      //ADD Message
      $('#idContibutionAmount').html(i18next.t('NSDL_NPP_LAN_33', {
        value: i18next.format(ContibutionAmount, 'uppercase')
      }));

    } else {
      //ADD Message
      // $('#idContibutionAmount').html(i18next.t('NSDL_NPP_LAN_33', {
      //   value: i18next.format(ContibutionAmount, 'uppercase')
      // }));
    }


  }, 500);
  // Rate of Interest Population
  $('#rateOfInterest').text(employeeData.rateOfInterest + '%');
  // calculateBtnDisable()

  document.getElementById('nextBtn').disabled = true;
  $('#nextBtn').css({
    "background-color": "#cccccc",
    "color": "#666666"
  });

  // hideNextBtn();
  showNextBtn();
})

function back() {
  window.location.href = '../../index.html';
}

function format(input) {
  var x = input.value;
  x = x.toString();
  var lastThree = x.substring(x.length - 3);
  var otherNumbers = x.substring(0, x.length - 3);
  if (otherNumbers != '')
    lastThree = ',' + lastThree;
  var res = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ",") + lastThree;

  input.value = res;

  //ADD Message
  //remove text
  // $('#estimatedNpsBalance').html(i18next.t('NSDL_NPP_LAN_130'));

  //text remove
  // $('#idContibutionAmount').html(i18next.t('NSDL_NPP_LAN_131'));
  $('#idTotalContributionStatement').hide();

}
//========================= Date of Birth =============================== 

// .datepicker('remove');
//Remove by me
// var uiDob = document.getElementById('idDob').value;
// let retirementDate;
// let selecteddatas;
// $("#idDob").on('change', function () {
//   selecteddatas = $("#idDob").val()

//   // 
//   var reg = /^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((19|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((19|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((19|[2-9]\d)\d{2}))|(29\/02\/((1[6-9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(([1][26]|[2468][048]|[3579][26])00))))$/g;


//   let regval = reg.test(selecteddatas)
//   if (regval === true) {
//     Dobdata()
//   } else {
//     $("#idDob").val("")
//     $("#idDateOfRetirement").val("")
//     $("#uiDateOfRetirement").val("")
//     $("#idRetirementYear").val("")

//     swal({
//       title: i18next.t('NSDL_NPP_LAN_132'),
//       button: i18next.t('NSDL_NPP_LAN_87')
//     });

//   }

// })


//Remove by me
// $("#idDobIcon").datepicker({
//   format: "dd/mm/yyyy",
//   todayHighlight: false,
//   todayBtn: false,
//   setDefaultDate: true,
//   //minDate: new Date("01/01/1957"),
//   // autoclose: true,
//   yearRange: 100,
//   maxDate: new Date(),
//   //language: inextLngs,
//   // todayBtn: "linked",
// }).on('change', function () {
//   selecteddatas = $(this).val()
//   //console.log(selecteddatas)
//   $("#idDob").empty()

//   $("#idDob").val(selecteddatas);
//   Dobdata()

//   // selecteddata(selecteddatas)


// })
let newrestDateOfRetirement

function Dobdata() {
  let newDobnewDob = $("#idDob").val();
  var newDob = moment(newDobnewDob, 'DD/MM/YYYY');
  //console.log('newDobnewDobnewDobnewDobnewDob+' + newDob)
  // let newDob = new Date(newDobnewDob);
  var dob = moment(newDob).format('DD/MM/YYYY');
  var newDate = moment(newDob).date();
  var newMonth = moment(newDob).month() + 1;
  var newYear = moment(newDob).year();
  let retirementYear = moment(newDob).add(60, 'years').format('YYYY');
  // retirementDate = moment(newDob).add(60, 'years').format('DD/MM/YYYY');

  retirementDate = externalRespons.dateOfRetirement;

  joiningRange = moment(newDob).add(18, 'years').format('DD/MM/YYYY');
  let retirementDateui = moment(newDob).add(60, 'years').format('DD/MM/YYYY');

  // retairmentMinRange = moment(newDob).subtract(50, 'years').format('DD/MM/YYYY');
  // retairmentMaxRange = moment(newDob).add(75, 'years').format('DD/MM/YYYY');

  // $('#idDateOfRetirement').datepicker('setDate', retirementDate);
  var resDateOfRetirement = retirementDateui.split("/");
  var ressDateOfRetirement = resDateOfRetirement[2] + '/' + resDateOfRetirement[1] + '/' + resDateOfRetirement[0]
  var restDateOfRetirement = new Date(ressDateOfRetirement);

  var sy = moment(newDob).year() + 50;
  var ey = moment(newDob).year() + 75;

  var retairmentMinRange = newMonth + '/' + newDate + '/' + sy
  var retairmentMaxRange = newMonth + '/' + newDate + '/' + ey
  //console.log("retairmentMinRange", retairmentMinRange)
  //console.log("retairmentMaxRange", retairmentMaxRange)
  ;

  //remove by me
  // $("#idDateOfRetirement").val(moment(restDateOfRetirement).format('DD/MM/YYYY'));
  // $("#idDateOfRetirement").on('change', function () {
  //   newrestDateOfRetirement = $("#idDateOfRetirement").val()

  //   // 
  //   var reg = /^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((19|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((19|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((19|[2-9]\d)\d{2}))|(29\/02\/((1[6-9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(([1][26]|[2468][048]|[3579][26])00))))$/g;
  //   let currentinput = new Date(moment(newrestDateOfRetirement, 'DD/MM/YYYY'));
  //   let newcurrentinput = moment(currentinput).format("YYYY")
  //   let inputretairmentMinRange = moment(retairmentMinRange).format("YYYY")
  //   let inputretairmentMaxRange = moment(retairmentMaxRange).format("YYYY")
  //   let regval = reg.test(newrestDateOfRetirement)
  //   if (regval === true) {
  //     if (newcurrentinput >= inputretairmentMinRange && newcurrentinput <= inputretairmentMaxRange) {
  //       RetirementDatefun()
  //     } else {
  //       $('#uiDateOfJoining').text('');
  //       $('#uiDateOfRetirement').text('');
  //       $('#idRetirementYear').text('');
  //       $("#idDateOfRetirement").val("")


  //       swal({
  //         title: i18next.t('NSDL_NPP_LAN_132'),
  //         button: i18next.t('NSDL_NPP_LAN_87')
  //       });
  //     }
  //   } else {
  //     $('#uiDateOfJoining').text('');
  //     $('#uiDateOfRetirement').text('');
  //     $('#idRetirementYear').text('');
  //     $("#idDateOfRetirement").val("")


  //     swal({
  //       title: i18next.t('NSDL_NPP_LAN_132'),
  //       button: i18next.t('NSDL_NPP_LAN_87')
  //     });
  //   }

  // })

  //remove by me
  // $('#idDorIcon').datepicker({
  //   // autoClose: true,
  //   yearRange: 100,
  //   format: 'dd/mm/yyyy',
  //   minDate: new Date(retairmentMinRange),
  //   maxDate: new Date(retairmentMaxRange),
  //   //minDate: new Date(),
  //   setDefaultDate: true,
  //   defaultDate: restDateOfRetirement,
  //   setDefaultDate: restDateOfRetirement,
  // }).on('change', function () {
  //   newrestDateOfRetirement = $(this).val()
  //   $("#idDateOfRetirement").val(newrestDateOfRetirement);
  //   //   //console.log(newJoiningDateform)
  //   RetirementDatefun()
  //   //   let newJoiningDate = new Date(newJoiningDateform);

  // })

  //$('#idDateOfRetirement').val(retirementDateui); // set #outDate date to #returnDate
  $('#uiDateOfRetirement').text(retirementDateui);

  var dateRange = newYear + 18;

  //remove by me
  // if (dateRange < 2004) {
  //   validateDtae = new Date("01/01/2004");
  //   document.getElementById('idDateOfJoining').value = '';
  //   document.getElementById('idNpsBalance').value = '0';
  //   testLoad();
  // } else {
  //   var ressdateOfDob = newMonth + '/' + newDate + '/' + dateRange
  //   validateDtae = new Date(ressdateOfDob);
  //   document.getElementById('idDateOfJoining').value = '';
  //   document.getElementById('idNpsBalance').value = '0';
  //   testLoad();
  // }

  retirementYearPopulation(dob, retirementDate)

  showHideToolTip();

  $('#uiDateOfJoining').text('');
}

function showHideToolTip() {
  let userDob = document.getElementById('idDob').value;
  let userDoj = document.getElementById('idDateOfJoining').value;
  let userDor = document.getElementById('idDateOfRetirement').value;

  if (userDob === "" || userDoj === "" || userDor === "") {
    $('#idToolTip').hide();
  } else {
    $('#idToolTip').show();
  }
}

var remainingRetirementYear;

function retirementYearPopulation(dob, retirementDate) {
  // //console.log("retirementDate 55555555555555 "+retirementDate)
  var objectForRetirementYear = {
    "dob": dob,
    "retirementDate": retirementDate
  }
  var stringObjectForRetirementYear = JSON.stringify(objectForRetirementYear);

  // showLoader();
  nppApiRequest('POST', stringObjectForRetirementYear, 'api/calculator/getRetirementYear', getRetirementYear);

  //remove by me
  // function getRetirementYear(data) {
  //   if (data == 'null') {
  //     // hideLoader();
  //     alert('No Data Found')
  //   } else {

  //     if (data.age < 18) {
  //       $('#uiDateOfJoining').text('');
  //       $('#uiDateOfRetirement').text('');
  //       $('#idRetirementYear').text('');

  //       swal({
  //         title: i18next.t('NSDL_NPP_LAN_105'),
  //         button: i18next.t('NSDL_NPP_LAN_87')
  //       });
  //       // alert("Age Cannot Be Less Than 18 Years");

  //       document.getElementById('idDob').value = '';
  //       document.getElementById('idDateOfRetirement').value = '';

  //     } else if (data.age > 80) {

  //       $('#uiDateOfJoining').text('');
  //       $('#uiDateOfRetirement').text('');
  //       $('#idRetirementYear').text('');

  //       swal({
  //         title: i18next.t('NSDL_NPP_LAN_114'),
  //         button: i18next.t('NSDL_NPP_LAN_87')
  //       });

  //       // alert("Age Cannot Be Less Than 18 Years");

  //       document.getElementById('idDob').value = '';
  //       document.getElementById('idDateOfRetirement').value = '';

  //       $('#uiDateOfJoining').text('');
  //       $('#uiDateOfRetirement').text('');
  //       $('#idRetirementYear').text('');

  //     } else {
  //       remainingRetirementYear = data.retirementYear;
  //       // if(remainingRetirementYear < 0){
  //       //   $('#uiDateOfRetirement').text('');
  //       //   document.getElementsByName('inputDateForm')[0].reset();;
  //       //   swal({
  //       //     title: i18next.t('NSDL_NPP_LAN_110'),
  //       //     button: i18next.t('NSDL_NPP_LAN_87')
  //       //   });
  //       // }else{
  //       sessionStorage.setItem('remainingRetirementYear', data.retirementYear)
  //       ////console.log('kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk' + data);
  //       // $('#idRetirementYear').html(i18next.t('NSDL_NPP_LAN_31', {data}));
  //       ////console.log("rrrrrrrrrrrrrrrrr",data.retirementYear)

  //       if (data.retirementYear === 1) {
  //         $('#idRetirementYear').html(i18next.t('NSDL_NPP_LAN_111', {
  //           value: i18next.format(data.retirementYear, 'uppercase')
  //         }));

  //         // //console.log("years should be year")

  //       } else if (Number(data.retirementYear) < 1) {
  //         $('#idRetirementYear').html(i18next.t('NSDL_NPP_LAN_112', {
  //           value: i18next.format(data.retirementYear, 'uppercase')
  //         }));

  //         // //console.log("You are already Retaired")

  //       } else {
  //         $('#idRetirementYear').html(i18next.t('NSDL_NPP_LAN_31', {
  //           value: i18next.format(data.retirementYear, 'uppercase')
  //         }));
  //       }

  //       // }

  //       // hideLoader();
  //     }
  //   }
  // }



  function getRetirementYear(data) {
    if (data == 'null') {
      // hideLoader();
      alert('No Data Found')

    } else {
      remainingRetirementYear = data.retirementYear;
      // if(remainingRetirementYear < 0){
      //   $('#uiDateOfRetirement').text('');
      //   document.getElementsByName('inputDateForm')[0].reset();;
      //   swal({
      //     title: i18next.t('NSDL_NPP_LAN_110'),
      //     button: i18next.t('NSDL_NPP_LAN_87')
      //   });
      // }else{
      sessionStorage.setItem('remainingRetirementYear', data.retirementYear)
      ////console.log('kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk' + data);
      // $('#idRetirementYear').html(i18next.t('NSDL_NPP_LAN_31', {data}));
      if (data.retirementYear === 1) {
        $('#idRetirementYear').html(i18next.t('NSDL_NPP_LAN_111', {
          value: i18next.format(data.retirementYear, 'uppercase')
        }));

        // //console.log("years should be year")

      } else if (Number(data.retirementYear) < 1) {

        $('#idRetirementYear').html(i18next.t('NSDL_NPP_LAN_112', {
          value: i18next.format(data.retirementYear, 'uppercase')
        }));

        // //console.log("You are already Retaired")

      } else {
        $('#idRetirementYear').html(i18next.t('NSDL_NPP_LAN_31', {
          value: i18next.format(data.retirementYear, 'uppercase')
        }));
      }

      // }

      // hideLoader();
    }
  }
}



// ======================== Date of Retirement ===============================

// $('#idDateOfRetirement').datepicker('remove');
var validateDate = new Date().getDate() + 1
// //console.log("datedate"+date)


// $('#idDateOfRetirement').datepicker({

//   format: "dd/mm/yyyy",
//   // autoclose: true,
//   yearRange: 100,
//   forceParse: true,
//   // minDate: new Date(),
//   setDefaultDate: new Date(),
//   disableDayFn: function (date) {
//     let disableListDate = [new Date().toDateString()];
//     if (disableListDate.includes(date.toDateString())) {
//       return true
//     } else {
//       return false
//     }
//   }
// }).on('change', function () {
//   let retirementDate = new Date($(this).val());

//   var newRetirementDate = moment(retirementDate).format('DD/MM/YYYY');
//   var newDate = moment(retirementDate).date();
//   var newMonth = moment(retirementDate).month() + 1;
//   var newYear = moment(retirementDate).year();


//   let uiRetirementValue = $('#idDateOfRetirement').val();
//   $('#uiDateOfRetirement').text(uiRetirementValue);

//   // var newRetirementDate = newDate + '/' + newMonth + '/' + newYear;
//   var empDobval = $("#idDob").val()
//   var newempDobval = moment(empDobval, 'DD/MM/YYYY');
//   //  document.getElementById('idDob').value;
//   //console.log(newempDobval)
//   // var empDob = new Date(empDobval);

//   var empDob = moment(newempDobval).format('DD/MM/yyyy');

//   //console.log('ddddddddddddddddd' + empDob);

//   var newDate = moment(empDobval).date();
//   // var newMonth = moment(retirementDate).month() + 1;
//   var newYear = moment(empDobval).year();




//   let birthDateObject = new Date(empDob);
//   let newBirthDate = birthDateObject.getDate();
//   let newBirthMonth = Number(birthDateObject.getMonth()) + 1;
//   let newBirthYear = birthDateObject.getFullYear();

//   // var newEmployeeBirthDate = newBirthDate + '/' + newBirthMonth + '/' + newBirthYear;
//   var newEmployeeBirthDate = moment(retirementDate).format('DD/MM/YYYY');

//   ////console.log('Moment mmmmmmmmmmmmmJS Retirement'+ newEmployeeBirthDate);

//   retirementYearPopulation(empDob, newRetirementDate);
//   //formatedDateuiDateOfRetirement
//   ////console.log('Retirement Date input ' + newDate + '/' + newMonth + '/' + newYear);
//   ////console.log('UI Retirement Value ' + uiRetirementValue);


//   showHideToolTip();

// });

function RetirementDatefun() {
  var retirementDate = moment($("#idDateOfRetirement").val(), 'DD/MM/YYYY');
  var newRetirementDate = moment(retirementDate).format('DD/MM/YYYY');
  var newDate = moment(retirementDate).date();
  var newMonth = moment(retirementDate).month() + 1;
  var newYear = moment(retirementDate).year();


  let uiRetirementValue = $('#idDateOfRetirement').val();
  $('#uiDateOfRetirement').text(uiRetirementValue);

  // var newRetirementDate = newDate + '/' + newMonth + '/' + newYear;
  var empDobval = $("#idDob").val()
  var newempDobval = moment(empDobval, 'DD/MM/YYYY');
  //  document.getElementById('idDob').value;
  //console.log(newempDobval)
  // var empDob = new Date(empDobval);

  var empDob = moment(newempDobval).format('DD/MM/yyyy');

  //console.log('ddddddddddddddddd' + empDob);

  var newDate = moment(empDobval).date();
  // var newMonth = moment(retirementDate).month() + 1;
  var newYear = moment(empDobval).year();




  let birthDateObject = new Date(empDob);
  let newBirthDate = birthDateObject.getDate();
  let newBirthMonth = Number(birthDateObject.getMonth()) + 1;
  let newBirthYear = birthDateObject.getFullYear();

  // var newEmployeeBirthDate = newBirthDate + '/' + newBirthMonth + '/' + newBirthYear;
  var newEmployeeBirthDate = moment(retirementDate).format('DD/MM/YYYY');

  ////console.log('Moment mmmmmmmmmmmmmJS Retirement'+ newEmployeeBirthDate);

  retirementYearPopulation(empDob, newRetirementDate);
  // retirementYearPopulation(externalRespons.dateOfBirth, externalRespons.dateOfRetirement);
  //formatedDateuiDateOfRetirement
  ////console.log('Retirement Date input ' + newDate + '/' + newMonth + '/' + newYear);
  ////console.log('UI Retirement Value ' + uiRetirementValue);


  showHideToolTip();
}


// ======================== Date of Joining ===============================


var formatedDate = null;
var dateyearRange = new Date().getFullYear();


function testLoad() {
  var objectDor = document.getElementById('idDateOfRetirement').value;

  $("#idDateOfJoining").on('change', function () {
    let newJoiningDateforminput = $("#idDateOfJoining").val();

    // 
    var reg = /^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((19|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((19|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((19|[2-9]\d)\d{2}))|(29\/02\/((1[6-9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(([1][26]|[2468][048]|[3579][26])00))))$/g;

    // let currentinput = new Date(moment(newrestDateOfRetirement, 'DD/MM/YYYY'));
    // let newcurrentinput = moment(currentinput).format("YYYY")
    // let inputretairmentMinRange = moment(retairmentMinRange).format("YYYY")
    // let inputretairmentMaxRange = moment(retairmentMaxRange).format("YYYY")
    // let regval = reg.test(newrestDateOfRetirement)
    // if (regval === true) {
    //   if (newcurrentinput >= inputretairmentMinRange && newcurrentinput <= inputretairmentMaxRange) {
    //     RetirementDatefun()
    //   }
    let newYear
    let regval = reg.test(newJoiningDateforminput)
    let currentinputnewJoiningDateform = moment(newJoiningDateforminput, 'DD/MM/YYYY');
    let newcurrentinputnewJoiningDateform = moment(currentinputnewJoiningDateform).format("YYYY")
    let newcurrentinputnewJoiningDate = moment(currentinputnewJoiningDateform).format('DD/MM/YYYY')
    let inputretairmentMinRange = moment(validateDtae).format("YYYY")
    if (regval === true) {
      var today = new Date().getTime(),
        idate = newcurrentinputnewJoiningDate.split("/");

      idate = new Date(idate[2], idate[1] - 1, idate[0]).getTime();
      if (newcurrentinputnewJoiningDateform >= inputretairmentMinRange && (idate - today) < 0) {

        let newJoiningDateform = $("#idDateOfJoining").val();
        //console.log(newJoiningDateform)
        let newJoiningDate = new Date(newJoiningDateform);
        let newDate = newJoiningDate.getDate();
        let newMonth = Number(newJoiningDate.getMonth()) + 1;
        let newYear = newJoiningDate.getFullYear();
        // $('#estimatedNpsBalance').show();
        let uiJoiningValue = $('#idDateOfJoining').val();
        $('#uiDateOfJoining').text(uiJoiningValue);
        formatedDate = newDate + '/' + newMonth + '/' + newYear;
        var contibution = document.getElementById('idAnnualContribution').value;

        if (externalRespons.empId === '1' || externalRespons.empId === '2') {
          $('#estimatedNpsBalance').show();
          ////console.log("npsCorpus Cal")
          npsCorpusCal();
        } else {
          //remove text
          // $('#estimatedNpsBalance').html(i18next.t('NSDL_NPP_LAN_130'));

          //text remove
          // $('#idContibutionAmount').html(i18next.t('NSDL_NPP_LAN_131'));
          // //console.log("npsC")
          $('#idTotalContribution').val(externalRespons.totalContribution).trigger('change');
          $('#idAnnualContribution').val(externalRespons.avgYearlyContribution).trigger('change');
          $('#idNpsBalance').val(externalRespons.currentNpsBalance).trigger('change');
        }

        showHideToolTip()


      } else {
        document.getElementById('idDateOfJoining').value = '';
        document.getElementById('idNpsBalance').value = '0';
        $("#idDateOfJoining").val("")
        $("#uiDateOfJoining").text("")
      }

    } else {
      //remove by me
      // $("#idDateOfJoining").val("");
      // swal({
      //   title: i18next.t('NSDL_NPP_LAN_132'),
      //   button: i18next.t('NSDL_NPP_LAN_87')
      // });


    }




  })


//Remove by me
  // $("#idDojIcon").datepicker({
  //   format: "dd/mm/yyyy",
  //   // autoclose: true,
  //   yearRange: 100,
  //   selectYears: 18,
  //   setDefaultDate: true,
  //   minDate: validateDtae,
  //   //maxDate: new Date(objectDor),
  //   maxDate: new Date(),
  //   forceParse: true
  // }).on('change', function () {
  //   let newJoiningDateform = $(this).val()
  //   $("#idDateOfJoining").val(newJoiningDateform);
  //   //console.log(newJoiningDateform)
  //   let newJoiningDate = new Date(newJoiningDateform);
  //   let newDate = newJoiningDate.getDate();
  //   let newMonth = Number(newJoiningDate.getMonth()) + 1;
  //   let newYear = newJoiningDate.getFullYear();
  //   // $('#estimatedNpsBalance').show();
  //   let uiJoiningValue = $('#idDateOfJoining').val();
  //   $('#uiDateOfJoining').text(uiJoiningValue);
  //   formatedDate = newDate + '/' + newMonth + '/' + newYear;
  //   var contibution = document.getElementById('idAnnualContribution').value;

  //   if (employeeId === '1' || employeeId === '2') {
  //     $('#estimatedNpsBalance').show();
  //     ////console.log("npsCorpus Cal")
  //     npsCorpusCal();
  //   } else {
  //     $('#estimatedNpsBalance').html(i18next.t('NSDL_NPP_LAN_130'));

  //     $('#idContibutionAmount').html(i18next.t('NSDL_NPP_LAN_131'));

  //     $('#idTotalContribution').val(0);
  //     $('#idAnnualContribution').val(0);
  //     $('#idNpsBalance').val(0);
  //   }

  //   showHideToolTip();
  // });
}


function onNpsBalance(data) {
  //console.log(data);
  if (data == 'null') {
    alert('Please Select Joining Year')
    window.localStorage.href = '../pages/contribution.html';
  } else {
    var estimatedNpsBalance = (data.currentNPSCorpus).toLocaleString('en-IN', {
      maximumFractionDigits: 0,
      currency: 'INR'
    });
    var newEstimatedNpsBalance = (data.currentNPSCorpus).toLocaleString('en-IN', {
      maximumFractionDigits: 0,
      currency: 'INR'
    });
    $('#idNpsBalance').val(newEstimatedNpsBalance);
    TotalContributionCal(data.currentNPSCorpus);
    if (employeeId == 1 || employeeId == 2) {
      //ADD Message

      $('#estimatedNpsBalance').html(i18next.t('NSDL_NPP_LAN_35', {
        value: i18next.format(estimatedNpsBalance, 'value'),
        value2: i18next.format(employeeData.rateOfInterest, 'value2')
      }));
    } else {
      //ADD Message
      $('#estimatedNpsBalance').html(i18next.t('NSDL_NPP_LAN_35', {
        value: i18next.format(estimatedNpsBalance, 'value'),
        value2: i18next.format(employeeData.rateOfInterest, 'value2')
      }));
    }


  }
}



// Incriment / Decrement
const incriment = (number) => {
  if (isNaN(number)) {
    number = 0;
  }

  var x = parseInt(number) + 1000;
  var stringValue = x.toLocaleString('en-IN', {
    maximumFractionDigits: 0,
    currency: 'INR'
  });
  return stringValue;
}

const decrement = (number) => {
  //console.log('number', number)

  if (isNaN(number)) {
    number = 0;
  }
  var x = parseInt(number) - 1000;
  var stringValue = x.toLocaleString('en-IN', {
    maximumFractionDigits: 0,
    currency: 'INR'
  });
  return stringValue;
  //return number > 1000 ? number - 1000 : number;
}

let plusButton = document.getElementById('plus');
plusButton.addEventListener('click', function () {
  ////console.log('aaaaaaaaaa')
  var contribution = document.getElementById('idAnnualContribution').value;
  var num = parseFloat(contribution.replace(/,/g, ''));
  //var changeableValue = incriment(num);

  // var startDate = document.getElementById('idDateOfJoining').value;
  // var sd = moment(startDate).format('DD/MM/YYYY');
  var startDate = document.getElementById('idDateOfJoining').value;
  // console.log("startDate+" + startDate)
  let kxl = moment(startDate, 'DD/MM/YYYY')
  var sd = moment(kxl).format('DD/MM/YYYY');
  if (sd === 'Invalid date') {
    swal({
      title: i18next.t('NSDL_NPP_LAN_103'),
      button: i18next.t('NSDL_NPP_LAN_87')
    });
  } else {
    document.getElementById('idAnnualContribution').value = incriment(num);
    $('#estimatedNpsBalance').show();
  }


  npsCorpusCal();
})


let minusButton = document.getElementById('minus');
minusButton.addEventListener('click', function () {
  let contribution = document.getElementById('idAnnualContribution').value;
  //var changeValue = decrement(contribution);
  var num = parseFloat(contribution.replace(/,/g, ''));

  var startDate = document.getElementById('idDateOfJoining').value;
  // console.log("startDate+" + startDate)
  let kxl = moment(startDate, 'DD/MM/YYYY')
  var sd = moment(kxl).format('DD/MM/YYYY');

  if (sd == 'Invalid date') {
    swal({
      title: i18next.t('NSDL_NPP_LAN_103'),
      button: i18next.t('NSDL_NPP_LAN_87')
    });
  } else {
    document.getElementById('idAnnualContribution').value = decrement(num);
  }

  npsCorpusCal();
})



let balancePlusButton = document.getElementById('balancePlus');
balancePlusButton.addEventListener('click', function () {
  let contribution = document.getElementById('idNpsBalance').value;

  var num = parseFloat(contribution.replace(/,/g, ''));
  var changeValue = incriment(num);
  var startDate = document.getElementById('idDateOfJoining').value;
  // console.log("startDate+" + startDate)
  let kxl = moment(startDate, 'DD/MM/YYYY')
  var sd = moment(kxl).format('DD/MM/YYYY');
  if (sd === 'Invalid date') {
    swal({
      title: i18next.t('NSDL_NPP_LAN_103'),
      button: i18next.t('NSDL_NPP_LAN_87')
    });
  } else {
    document.getElementById('idNpsBalance').value = changeValue;
    calculateBtnEnable()
  }

  var formatingNpsBlns = (changeValue.toLocaleString('en-IN', {
    maximumFractionDigits: 0,
    style: 'currency',
    currency: 'INR'
  }));

  if (employeeId == 1 || employeeId == 2) {
    //ADD Message
    $('#estimatedNpsBalance').html(i18next.t('NSDL_NPP_LAN_35', {
      value: i18next.format(formatingNpsBlns, 'value'),
      value2: i18next.format(employeeData.rateOfInterest, 'value2')
    }));
  } else {
    //ADD Message
    $('#estimatedNpsBalance').html(i18next.t('NSDL_NPP_LAN_35', {
      value: i18next.format(formatingNpsBlns, 'value'),
      value2: i18next.format(employeeData.rateOfInterest, 'value2')
    }));
  }


  var conNum = parseFloat(changeValue.replace(/,/g, ''));
  //contributionCal(conNum);
  $('#idTotalContribution').val(0);
  $('#idAnnualContribution').val(0);

})

let balanceMinusButton = document.getElementById('balanceMinus');
balanceMinusButton.addEventListener('click', function () {
  let contribution = document.getElementById('idNpsBalance').value;

  var num = parseFloat(contribution.replace(/,/g, ''));
  var changeModifiedValue = decrement(num);
  var startDate = document.getElementById('idDateOfJoining').value;
  // console.log("startDate+" + startDate)
  let kxl = moment(startDate, 'DD/MM/YYYY')
  var sd = moment(kxl).format('DD/MM/YYYY');
  if (sd === 'Invalid date') {
    swal({
      title: i18next.t('NSDL_NPP_LAN_103'),
      button: i18next.t('NSDL_NPP_LAN_87')
    });
  } else {
    document.getElementById('idNpsBalance').value = changeModifiedValue;
    calculateBtnEnable()
  }
  var npsModifyedValue = (changeModifiedValue.toLocaleString('en-IN', {
    maximumFractionDigits: 0,
    style: 'currency',
    currency: 'INR'
  }));

  if (employeeId == 1 || employeeId == 2) {
    //ADD Message
    $('#estimatedNpsBalance').html(i18next.t('NSDL_NPP_LAN_35', {
      value: i18next.format(npsModifyedValue, 'value'),
      value2: i18next.format(employeeData.rateOfInterest, 'value2')
    }));
  } else {
    //ADD Message
    $('#estimatedNpsBalance').html(i18next.t('NSDL_NPP_LAN_35', {
      value: i18next.format(npsModifyedValue, 'value'),
      value2: i18next.format(employeeData.rateOfInterest, 'value2')
    }));
  }

  var conNum = parseFloat(changeModifiedValue.replace(/,/g, ''));
  //contributionCal(conNum);
  $('#idTotalContribution').val(0);
  $('#idAnnualContribution').val(0);
})






function contributionCalculation() {
  var objectDob = document.getElementById('idDob').value;
  var remainingRetirementYearnew = sessionStorage.getItem("remainingRetirementYear");

  // var myDob = new Date(objectDob);
  // var dobDay = myDob.getDate();
  // var dobMonth = Number(myDob.getMonth()) + 1;
  // var dobYear = myDob.getFullYear();
  // var dob = dobDay + '/' + dobMonth + '/' + dobYear;

  var dobYearold = moment(objectDob, 'DD/MM/YYYY');
  var dobYear = moment(dobYearold).format('YYYY');
  // //console.log('onClick Get DOB ' + dob);
  // var dobYear = moment(objectDob).format('DD/MM/YYYY');
  var objectDoj = document.getElementById('idDateOfJoining').value;
  var myDoj = new Date(objectDoj);
  var dojDay = myDoj.getDate();
  var dojMonth = Number(myDoj.getMonth()) + 1;
  var dojYear = myDoj.getFullYear();
  var doj = dojDay + '/' + dojMonth + '/' + dojYear;

  // //console.log('onClick Get DOj ' + doj);

  var objectDor = document.getElementById('idDateOfRetirement').value;
  //console.log(objectDor)
  // var myDor = new Date(objectDor);
  // var dorDay = myDor.getDate();
  // var dorMonth = Number(myDor.getMonth()) + 1;
  // var dorYear = myDor.getFullYear();
  // var dor = dorDay + '/' + dorMonth + '/' + dorYear;
  var dorYearold = moment(objectDor, 'DD/MM/YYYY');
  var dorYear = moment(dorYearold).format('YYYY');
  var isValid = false;

  // if (dob == 'NaN/NaN/NaN') {
  //   swal({
  //       title: i18next.t('NSDL_NPP_LAN_83')
  //     } //Grade
  //   );
  //   isValid = false;
  // } else {
  //   if (doj == 'NaN/NaN/NaN') {
  //     swal({
  //       title: i18next.t('NSDL_NPP_LAN_84'),
  //       button: i18next.t('NSDL_NPP_LAN_87')
  //     });
  //     isValid = false;
  //   } else {
  //     if (dor == 'NaN/NaN/NaN') {
  //       swal({
  //         title: i18next.t('NSDL_NPP_LAN_85'),
  //         button: i18next.t('NSDL_NPP_LAN_87')
  //       });
  //       isValid = false;
  //     } else {
  //       isValid = true;
  //     }
  //   }
  // }

  // var contributionValue = document.getElementById('idAnnualContribution').value;
  // var npsBlanceValue = document.getElementById('idNpsBalance').value;
  // // alert(objectDob)
  // if (objectDob === '') {

  //   swal({
  //     title: i18next.t('NSDL_NPP_LAN_83'),
  //     button: i18next.t('NSDL_NPP_LAN_87')
  //   });
  //   isValid = false;
  // } else if (objectDoj === '') {
  //   swal({
  //     title: i18next.t('NSDL_NPP_LAN_84'),
  //     button: i18next.t('NSDL_NPP_LAN_87')
  //   });
  //   isValid = false;
  // } else if (objectDor === '') {
  //   swal({
  //     title: i18next.t('NSDL_NPP_LAN_85'),
  //     button: i18next.t('NSDL_NPP_LAN_87')
  //   });
  //   isValid = false;
  // } else if (contributionValue <= 0) {
  //   swal({
  //     title: i18next.t('NSDL_NPP_LAN_101'),
  //     button: i18next.t('NSDL_NPP_LAN_87')
  //   });
  //   isValid = false;
  // } else if (npsBlanceValue <= 0) {
  //   swal({
  //     title: i18next.t('NSDL_NPP_LAN_102'),
  //     button: i18next.t('NSDL_NPP_LAN_87')
  //   });
  //   isValid = false;
  // } else {
  //   isValid = true;
  // }








  var contributionValue = document.getElementById('idAnnualContribution').value;
  var npsBlanceValue = document.getElementById('idNpsBalance').value;
  // if(contributionValue == 0){
  //   swal({
  //     title: i18next.t('NSDL_NPP_LAN_101'),
  //     button: i18next.t('NSDL_NPP_LAN_87')
  //   });
  //   isValid = false;
  // }
  // else if(npsBlanceValue == 0){
  //   swal({
  //     title: i18next.t('NSDL_NPP_LAN_102'),
  //     button: i18next.t('NSDL_NPP_LAN_87')
  //   });
  //   isValid = false;
  // }
  // //console.log(isValid)


  var yearlyContribution = document.getElementById('idAnnualContribution').value;
  var npsBalance = document.getElementById('idNpsBalance').value;
  var totalConAmt = document.getElementById('idTotalContribution').value;

  var yearlyContributionNum = parseFloat(yearlyContribution.replace(/,/g, ''));
  var npsBalanceNum = parseFloat(npsBalance.replace(/,/g, ''));
  var totalConAmtNum = parseFloat(totalConAmt.replace(/,/g, ''));

  var currentNpsCorpusObj = {
    "dateOfBirth": objectDob,
    "dateOfJoining": objectDoj,
    "dateOfRetirement": objectDor,
    "yearlyContribution": yearlyContributionNum,
    "npsBalance": npsBalanceNum,
    "retirementYearOnly": dorYear.toString(),
    "birthYearOnly": Number(dobYear),
    "totalContribution": totalConAmtNum,
    "remainingRetirementYear": Number(remainingRetirementYearnew)
  }
  sessionStorage.setItem('currentNpsCorpus', JSON.stringify(currentNpsCorpusObj));
  window.location.href = '../pages/pensionCalculation.html';


}

$(function () {
  $inputFrom = $(".js-input-from").val();
  $inputTo = $(".js-input-to").val();

  $("#slider-range").slider({
    range: true,
    min: 0,
    max: 100,
    values: [20, 70],
    slide: function (event, ui) {
      $("#amount").val(ui.values[0] + " - " + ui.values[1]);
      $('#idAge').val(ui.values[0]);
      $('#idRetireAge').val(ui.values[1]);
    }
  });
});

$('#idAnnualContribution').on('propertychange input', function (e) {

  npsCorpusCal();
})

function npsCorpusCal() {
  var yearlyContribution = document.getElementById('idAnnualContribution').value;
  // console.log("yearlyContribution" + yearlyContribution)
  var startDate = document.getElementById('idDateOfJoining').value;
  // console.log("startDate+" + startDate)
  let kxl = moment(startDate, 'DD/MM/YYYY')
  var sd = moment(kxl).format('DD/MM/YYYY');

  var num = parseFloat(yearlyContribution.replace(/,/g, ''));

  if (isNaN(num)) {
    ////console.log("in")
    //var num = parseFloat(yearlyContribution.replace(/,/g, ''));

  } else {
    ////console.log("out")

    var objBody = {
      "avgYearlyContribution": num,
      "employeeId": employeeId,
      "grade": employeeData.grade,
      "startYear": String(sd)
    }

    if (employeeId != null && employeeData.grade != undefined && sd != 'Invalid date') {
      var objBody = JSON.stringify(objBody);
      // current NPS balance Population
      nppApiRequest('POST', objBody, 'api/calculator/getCurrentNpsCorpusV3', onNpsBalance);


      $('#estimatedNpsBalance').show();
    }
  }

}

$('#idNpsBalance').on('propertychange input', function (e) {
  //contributionCal(this.value);
  $('#idTotalContribution').val(0);
  $('#idAnnualContribution').val(0);
  calculateBtnEnable()
})

function contributionCal() {
  var inputVal = document.getElementById('idNpsBalance').value
  var val = parseFloat(inputVal.replace(/,/g, ''));
  // var startDate = document.getElementById('idDateOfJoining').value;
  // var sd = moment(startDate).format('DD/MM/YYYY');.
  var startDate = document.getElementById('idDateOfJoining').value;
  // console.log("startDate+" + startDate)
  let kxl = moment(startDate, 'DD/MM/YYYY')
  var sd = moment(kxl).format('DD/MM/YYYY');
  var changeObj = {
    "empId": employeeId,
    "grade": employeeData.grade,
    "startYear": String(sd),
    "npsCorPusVal": Number(val)
  }

  ////console.log("yyyyyyyyyyyyyyyyyyyy"+changeObj);
  var StringObj = JSON.stringify(changeObj);
  ////console.log("yyyyyyyyyyyyyyyyyyyy"+StringObj);

  nppApiRequest('POST', StringObj, 'api/calculator/getContrbution', onContributionSuccess);
  ////console.log(this.value);
  showNextBtn()
}

function TotalContributionCal(data) {
  var startDate = document.getElementById('idDateOfJoining').value;
  // console.log("startDate+" + startDate)
  let kxl = moment(startDate, 'DD/MM/YYYY')
  var sd = moment(kxl).format('DD/MM/YYYY');
  var changeObj = {
    "empId": employeeId,
    "grade": employeeData.grade,
    "startYear": String(sd),
    "npsCorPusVal": Number(data)
  }

  ////console.log("yyyyyyyyyyyyyyyyyyyy"+changeObj);
  var StringObj = JSON.stringify(changeObj);
  ////console.log("yyyyyyyyyyyyyyyyyyyy"+StringObj);

  nppApiRequest('POST', StringObj, 'api/calculator/getContrbution', onContributionSuccessNew);
}

function onContributionSuccessNew(data) {
  var totalContibutionAmountWithOutSymbol = data.totalContribution.toLocaleString('en-IN', {
    maximumFractionDigits: 0,
    currency: 'INR',
    // style: 'currency'
  })

  var totalConAmount = data.totalContribution.toLocaleString('en-IN', {
    maximumFractionDigits: 0,
    // style: 'currency',
    currency: 'INR'
  })

  if (employeeId == 1 || employeeId == 2) {
    $('#idTotalContributionStatement').html(i18next.t('NSDL_NPP_LAN_144', {
      value: i18next.format(totalConAmount, 'uppercase')
    }));
  }

  $('#idTotalContribution').val(totalContibutionAmountWithOutSymbol);
}

function onContributionSuccess(data) {
  var ContibutionAmountWithOutSymbol = data.avgYearleContribution.toLocaleString('en-IN', {
    maximumFractionDigits: 0,
    currency: 'INR',
    // style: 'currency'
  })
  $('#idTotalContributionStatement').show();
  var totalContibutionAmountWithOutSymbol = data.totalContribution.toLocaleString('en-IN', {
    maximumFractionDigits: 0,
    currency: 'INR',
    // style: 'currency'
  })
  // calculateBtnDisable()

  var totalConAmount = data.totalContribution.toLocaleString('en-IN', {
    maximumFractionDigits: 0,
    // style: 'currency',
    currency: 'INR'
  })

  if (employeeId == 1 || employeeId == 2) {
    $('#idTotalContributionStatement').html(i18next.t('NSDL_NPP_LAN_144', {
      value: i18next.format(totalConAmount, 'uppercase')
    }));
  } else {
    //text remove
    // $('#idTotalContributionStatement').html(i18next.t('NSDL_NPP_LAN_131'));
  }

  $('#idTotalContribution').val(totalContibutionAmountWithOutSymbol);
  //$('#idAnnualContribution').val(employeeData.contributionAmount);
  $('#idAnnualContribution').val(ContibutionAmountWithOutSymbol);
}

// if (currentNpsCorpus !== null) {
//   //console.log("prasanjit")
//   $('#estimatedNpsBalance').show();
//   document.getElementById("estimatedNpsBalance").style.display = "show";
// }


//Remove by me
// function calculate() {
//   var inputVal = document.getElementById('idNpsBalance').value
//   var val = parseFloat(inputVal.replace(/,/g, ''));
//   // var startDate = document.getElementById('idDateOfJoining').value;
//   // var sd = moment(startDate).format('DD/MM/YYYY');
//   var startDate = document.getElementById('idDateOfJoining').value;
//   // console.log("startDate+" + startDate)
//   let kxl = moment(startDate, 'DD/MM/YYYY')
//   var sd = moment(kxl).format('DD/MM/YYYY');
//   if (Number(val) < 1) {
//     //please input estimate value
//     swal({
//       title: i18next.t('NSDL_NPP_LAN_102'),
//       button: i18next.t('NSDL_NPP_LAN_87')
//     });
//   } else if (sd === 'Invalid date') {
//     //please select date
//     swal({
//       title: i18next.t('NSDL_NPP_LAN_103'),
//       button: i18next.t('NSDL_NPP_LAN_87')
//     });
//   } else {
//     contributionCal();
//   }
// }

function calculateBtnDisable() {
  document.getElementById('calculateBtn').disabled = true;
  $('#calculateBtn').css({
    "background-color": "#cccccc",
    "color": "#666666"
  });

  document.getElementById('nextBtn').disabled = false;
  $('#nextBtn').css({
    "background-color": "#000000",
    "color": "#fff"
  });

}
// calculateBtnDisable();

function calculateBtnEnable() {
  document.getElementById('calculateBtn').disabled = false;
  $('#calculateBtn').css({
    "background-color": "#000000",
    "color": "#fff"
  });

  document.getElementById('nextBtn').disabled = true;
  $('#nextBtn').css({
    "background-color": "#cccccc",
    "color": "#666666"
  });
}
// calculateBtnEnable()

function hideDiv() {
  var selectedDiv = document.getElementById('contribution_dynamicRender');
  selectedDiv.style.display = "none";
}

function showDiv() {
  var selectedDiv = document.getElementById('contribution_dynamicRender');
  selectedDiv.style.display = "block";
}

// function hideNextBtn(){
//   document.getElementById('nextBtn').disabled = true;
//   $('#nextBtn').css({"background-color": "#cccccc","color": "#666666"});
// }
function showNextBtn() {
  document.getElementById('nextBtn').disabled = false;
  $('#nextBtn').css({
    "background-color": "#000000",
    "color": "#fff"
  });
}

// function divClear(){
//   idNpsBalance
// }


//Remove by me
// $('#idDateOfJoining').click(function () {
//   var dovEmpty = $('#idDob').val();
//   if (dovEmpty == "") {
//     $('#idDateOfJoining').val('')
//     swal({
//       title: i18next.t('NSDL_NPP_LAN_136'),
//       button: i18next.t('NSDL_NPP_LAN_87')
//     });
//   }
// })

// $('#idDateOfRetirement').click(function () {
//   var dovEmpty = $('#idDob').val();
//   if (dovEmpty == "") {
//     $('#idDateOfRetirement').val('')
//     swal({
//       title: i18next.t('NSDL_NPP_LAN_136'),
//       button: i18next.t('NSDL_NPP_LAN_87')
//     });
//   }
// })


// $('#idAnnualContribution').value('1000').trigger('change');