


// First Page Redirection
function startPage(){
    window.location.href = 'src/pages/contribution.html';
}


